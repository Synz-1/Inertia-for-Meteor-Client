/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.utils.Utils
 *  meteordevelopment.meteorclient.utils.player.ChatUtils
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1297
 *  net.minecraft.class_1501
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_2561
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1501;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_2561;

public class LlamaDupe2bfr
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> delay;
    private final Setting<Boolean> debug;
    private int timer;

    public LlamaDupe2bfr() {
        super(inertia.inertia, "Llama2b2fr", "Performs the llama dupe for 2b2fr.org");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.delay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).description("The delay between between each consecutive dupe in ticks (2 ticks ~= 1 second (scaled; so for 15 seconds it should be at 30 ticks)")).defaultValue((Object)30)).sliderMin(10).sliderMax(200).build());
        this.debug = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("debug")).description("Sends debug messages to indicate what is happening or if any error occurred")).defaultValue((Object)false)).build());
        this.timer = 0;
    }

    public void onActivate() {
        this.timer = (Integer)this.delay.get() * 10;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        class_1501 llamaEntity;
        if (!Utils.canUpdate() || this.mc.field_1761 == null) {
            return;
        }
        if (this.mc.field_1724.method_5854() instanceof class_1501) {
            this.mc.field_1724.method_29239();
            ChatUtils.sendPlayerMsg((String)".dismount");
            if (((Boolean)this.debug.get()).booleanValue()) {
                ChatUtils.sendMsg((class_2561)class_2561.method_30163((String)"Dismounted"));
            }
        }
        if (this.timer > 0) {
            --this.timer;
            return;
        }
        this.timer = (Integer)this.delay.get() * 10;
        if (((Boolean)this.debug.get()).booleanValue()) {
            ChatUtils.sendMsg((class_2561)class_2561.method_30163((String)("Delay in s: " + this.timer / 20)));
        }
        if ((llamaEntity = this.getNearestLlamaEntity()) == null) {
            ChatUtils.sendMsg((class_2561)class_2561.method_30163((String)"Could not find a llama entity within interaction range... Toggling"));
            this.toggle();
            return;
        }
        class_1269 actionResult = this.mc.field_1761.method_2905((class_1657)this.mc.field_1724, (class_1297)llamaEntity, class_1268.field_5808);
        if (((Boolean)this.debug.get()).booleanValue()) {
            ChatUtils.sendMsg((class_2561)class_2561.method_30163((String)("Interaction status: " + actionResult.toString())));
        }
    }

    private class_1501 getNearestLlamaEntity() {
        return this.mc.field_1687.method_8333((class_1297)this.mc.field_1724, new class_238(this.mc.field_1724.method_24515()).method_1014(this.mc.field_1724.method_55755()), entity -> entity instanceof class_1501).stream().min((entity1, entity2) -> Float.compare(entity1.method_5739((class_1297)this.mc.field_1724), entity2.method_5739((class_1297)this.mc.field_1724))).orElse(null);
    }
}

