/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mio.addon.MioAddon
 *  meteordevelopment.meteorclient.events.entity.LivingEntityMoveEvent
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Send
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.mixininterface.IVec3d
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.utils.misc.input.Input
 *  meteordevelopment.meteorclient.utils.player.PlayerUtils
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1690
 *  net.minecraft.class_1922
 *  net.minecraft.class_2338
 *  net.minecraft.class_2338$class_2339
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 *  net.minecraft.class_2833
 *  net.minecraft.class_304
 *  net.minecraft.class_3532
 *  net.minecraft.class_3726
 *  net.minecraft.class_4970$class_4971
 */
package com.wwe.addon.complements.bow;

import com.wwe.addon.inertia;
import meteordevelopment.meteorclient.events.entity.LivingEntityMoveEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1690;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2833;
import net.minecraft.class_304;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_4970;

public class BowHelper
extends Module {
    private final SettingGroup sgSpeed;
    private final SettingGroup sgFlight;
    private final Setting<Boolean> speed;
    private final SettingGroup warning;
    private final Setting<Double> horizontalSpeed;
    private final Setting<Double> horizontalSpeedInsideBlocks;
    private final Setting<Double> verticalSpeed;
    private final Setting<Double> fallSpeed;
    private final Setting<Boolean> antiKick;
    private final Setting<Integer> delay;
    private int delayLeft;
    private double lastPacketY;
    private boolean sentPacket;
    private boolean insideBlock;

    public BowHelper() {
        super(inertia.inertia, " - Crash - ", "BoatNoClip for bowkiller");
        this.sgSpeed = this.settings.createGroup("Speed");
        this.sgFlight = this.settings.createGroup("Flight");
        this.speed = this.sgSpeed.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("speed")).defaultValue((Object)true)).build());
        this.warning = this.settings.createGroup("Horizontal speeds over 5-6 will rubberband inside blocks.");
        this.horizontalSpeed = this.sgSpeed.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("horizontal-speed")).defaultValue(10.0).min(0.0).sliderMax(50.0).visible(() -> this.speed.get())).build());
        this.horizontalSpeedInsideBlocks = this.sgSpeed.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("horizontal-speed-inside-blocks")).defaultValue(5.0).min(0.0).sliderMax(50.0).visible(() -> this.speed.get())).build());
        this.verticalSpeed = this.sgSpeed.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("vertical-speed")).defaultValue(6.0).min(0.0).sliderMax(20.0).build());
        this.fallSpeed = this.sgFlight.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("fall-speed")).defaultValue(0.0).min(0.0).build());
        this.antiKick = this.sgFlight.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("anti-fly-kick")).defaultValue((Object)true)).build());
        this.delay = this.sgFlight.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).defaultValue((Object)40)).min(1).sliderMax(80).visible(() -> this.antiKick.get())).build());
        this.lastPacketY = Double.MAX_VALUE;
    }

    public void onActivate() {
        this.delayLeft = (Integer)this.delay.get();
        this.sentPacket = false;
        this.lastPacketY = Double.MAX_VALUE;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        class_1297 class_12972;
        if (this.mc.field_1724 != null && (class_12972 = this.mc.field_1724.method_5854()) instanceof class_1690) {
            class_1690 boat = (class_1690)class_12972;
            this.insideBlock = this.isInsideBlock((class_1297)boat);
            if (this.sentPacket) {
                class_2833 packet = class_2833.method_65307((class_1297)boat);
                ((IVec3d)packet.comp_3350()).meteor$setY(this.lastPacketY);
                this.mc.field_1724.field_3944.method_52787((class_2596)packet);
                this.sentPacket = false;
            }
        }
        --this.delayLeft;
    }

    @EventHandler
    private void onEntityMove(LivingEntityMoveEvent event) {
        class_1309 entity = event.entity;
        if (!(entity instanceof class_1690)) {
            return;
        }
        if (entity.method_5642() != this.mc.field_1724) {
            return;
        }
        double velX = entity.method_18798().field_1352;
        double velY = 0.0;
        double velZ = entity.method_18798().field_1350;
        this.insideBlock = this.isInsideBlock((class_1297)entity);
        if (((Boolean)this.speed.get()).booleanValue()) {
            double appliedSpeed = this.insideBlock ? (Double)this.horizontalSpeedInsideBlocks.get() : (Double)this.horizontalSpeed.get();
            class_243 vel = PlayerUtils.getHorizontalVelocity((double)appliedSpeed);
            velX = vel.field_1352;
            velZ = vel.field_1350;
        }
        if (this.mc.field_1755 == null && Input.isPressed((class_304)this.mc.field_1690.field_1903)) {
            velY += (Double)this.verticalSpeed.get() / 20.0;
        }
        velY = this.mc.field_1755 == null && Input.isPressed((class_304)this.mc.field_1690.field_1867) ? (velY -= (Double)this.verticalSpeed.get() / 20.0) : (velY -= (Double)this.fallSpeed.get() / 20.0);
        entity.method_36456(this.mc.field_1724.method_36454());
        ((IVec3d)event.movement).meteor$set(velX, velY, velZ);
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        class_2596 class_25962 = event.packet;
        if (!(class_25962 instanceof class_2833)) {
            return;
        }
        class_2833 packet = (class_2833)class_25962;
        if (!((Boolean)this.antiKick.get()).booleanValue()) {
            return;
        }
        if (!(this.mc.field_1724.method_5854() instanceof class_1690)) {
            return;
        }
        double currentY = packet.comp_3350().field_1351;
        if (this.delayLeft <= 0 && !this.sentPacket && this.shouldFlyDown(currentY) && BowHelper.isOnAir(this.mc.field_1724.method_5854())) {
            ((IVec3d)packet.comp_3350()).meteor$setY(this.lastPacketY - 0.0313);
            this.sentPacket = true;
            this.delayLeft = (Integer)this.delay.get();
        }
        this.lastPacketY = currentY;
    }

    private static boolean isOnAir(class_1297 entity) {
        return entity.method_5770().method_29546(entity.method_5829().method_1014(0.0625).method_1012(0.0, -0.55, 0.0)).allMatch(class_4970.class_4971::method_26215);
    }

    private boolean shouldFlyDown(double currentY) {
        if (currentY >= this.lastPacketY) {
            return true;
        }
        return this.lastPacketY - currentY < 0.0313;
    }

    private boolean isInsideBlock(class_1297 entity) {
        if (entity == null || this.mc.field_1687 == null) {
            return false;
        }
        class_238 box = entity.method_5829().method_1002(0.0, 0.05, 0.0).method_1009(0.5, 0.0, 0.5);
        int minX = class_3532.method_15357((double)box.field_1323);
        int minY = class_3532.method_15357((double)box.field_1322);
        int minZ = class_3532.method_15357((double)box.field_1321);
        int maxX = class_3532.method_15357((double)box.field_1320);
        int maxY = class_3532.method_15357((double)box.field_1325);
        int maxZ = class_3532.method_15357((double)box.field_1324);
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int x = minX; x <= maxX; ++x) {
            for (int y = minY; y <= maxY; ++y) {
                for (int z = minZ; z <= maxZ; ++z) {
                    class_265 shape;
                    pos.method_10103(x, y, z);
                    class_2680 state = this.mc.field_1687.method_8320((class_2338)pos);
                    if (state.method_26215() || (shape = state.method_26194((class_1922)this.mc.field_1687, (class_2338)pos, class_3726.method_16194())).method_1110() || !entity.method_5829().method_994(shape.method_1107().method_996((class_2338)pos))) continue;
                    return true;
                }
            }
        }
        for (class_1297 other : this.mc.field_1687.method_8335(entity, box)) {
            if (other == this.mc.field_1724 || other == entity.method_5854() || other.method_5626(entity) || entity.method_5626(other) || !other.method_5805() || other.method_31481() || !other.method_5829().method_994(box)) continue;
            return true;
        }
        return false;
    }
}

