/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.MeteorClient
 *  net.minecraft.class_243
 */
package com.wwe.addon.complements.mine;

import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_243;

public enum Origin {
    VANILLA("Vanilla"),
    NCP("No Cheat Plus");

    private final String title;

    private Origin(String title) {
        this.title = title;
    }

    public String toString() {
        return this.title;
    }

    public class_243 getOrigin(class_243 pos) {
        if (this == VANILLA) {
            return pos;
        }
        return pos.method_1031(0.0, (double)MeteorClient.mc.field_1724.method_18381(MeteorClient.mc.field_1724.method_18376()), 0.0);
    }
}

