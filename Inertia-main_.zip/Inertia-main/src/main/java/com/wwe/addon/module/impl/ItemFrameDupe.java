/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.utils.Utils
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.InvUtils
 *  meteordevelopment.meteorclient.utils.world.BlockUtils
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1533
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2318
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_2665
 *  net.minecraft.class_2680
 *  net.minecraft.class_2769
 *  net.minecraft.class_636
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_636;

public class ItemFrameDupe
extends AddonModule {
    private static final ArrayList<class_2338> blocks = new ArrayList();
    private final SettingGroup sgGeneral;
    private final Setting<Integer> distance;
    private final Setting<Boolean> backOfPiston;
    private final Setting<Integer> delay;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> rotateItem;
    private final Setting<Boolean> swapBack;
    private final Setting<Integer> breakDelay;
    private final ArrayList<class_2338> positions;
    private int timer;
    private Thread placeThread;
    private int breakDelaytimer;

    public ItemFrameDupe() {
        super(inertia.inertia, "FrameDupe", "Automatically places item frames on pistons (or not) and performs the item frame dupe");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.distance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("distance")).description("The max distance to search for pistons.")).min(1).sliderMin(1).defaultValue((Object)5)).sliderMax(6).max(6).build());
        this.backOfPiston = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("back-of-piston")).description("Whether to place on the front or back of piston")).defaultValue((Object)true)).build());
        this.delay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("delay")).description("The delay between placements and breaking")).defaultValue((Object)1)).sliderMax(10).build());
        this.rotate = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("rotate")).description("Whether or not to rotate when placing.")).defaultValue((Object)true)).build());
        this.rotateItem = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("rotate item")).description("Whether or not to keep rotating the item frame")).defaultValue((Object)true)).build());
        this.swapBack = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("swap-back")).description("Whether or not to swap back to the previous held item after placing.")).defaultValue((Object)true)).build());
        this.breakDelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("item-break-delay")).description("The amount of delay between breaking the item in ticks.")).defaultValue((Object)2)).min(0).sliderMax(60).build());
        this.positions = new ArrayList();
        this.placeThread = null;
    }

    private static List<class_2338> getSphere(class_2338 centerPos, int radius, int height) {
        blocks.clear();
        for (int i = centerPos.method_10263() - radius; i < centerPos.method_10263() + radius; ++i) {
            for (int j = centerPos.method_10264() - height; j < centerPos.method_10264() + height; ++j) {
                for (int k = centerPos.method_10260() - radius; k < centerPos.method_10260() + radius; ++k) {
                    class_2338 pos = new class_2338(i, j, k);
                    if (!centerPos.method_19771((class_2382)pos, (double)radius) || blocks.contains(pos)) continue;
                    blocks.add(pos);
                }
            }
        }
        return blocks;
    }

    public void onActivate() {
        this.timer = (Integer)this.delay.get();
        this.breakDelaytimer = 0;
    }

    public void onDeactivate() {
        super.onDeactivate();
        this.placeThread = null;
        this.breakDelaytimer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!Utils.canUpdate()) {
            return;
        }
        class_636 c = this.mc.field_1761;
        if (this.timer > 0) {
            --this.timer;
            return;
        }
        this.timer = (Integer)this.delay.get();
        FindItemResult itemResult = InvUtils.findInHotbar((class_1792[])new class_1792[]{class_1802.field_8143, class_1802.field_28408});
        if (!itemResult.found()) {
            this.error("No item frames found in hotbar.", new Object[0]);
            this.toggle();
            return;
        }
        for (class_2338 blockPos : ItemFrameDupe.getSphere(this.mc.field_1724.method_24515(), (Integer)this.distance.get(), (Integer)this.distance.get())) {
            if (!(this.mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2665) || !this.shouldPlace(blockPos)) continue;
            this.positions.add(blockPos);
        }
        for (class_2338 blockPos : this.positions) {
            class_2680 blockState = this.mc.field_1687.method_8320(blockPos);
            if (blockState.method_26204() == class_2246.field_10124 || !blockState.method_28498((class_2769)class_2318.field_10927)) continue;
            class_2350 direction = (class_2350)blockState.method_11654((class_2769)class_2318.field_10927);
            if (((Boolean)this.backOfPiston.get()).booleanValue()) {
                direction = direction.method_10153();
            }
            class_2338 placePos = blockPos.method_10093(direction);
            BlockUtils.place((class_2338)placePos, (FindItemResult)itemResult, (boolean)((Boolean)this.rotate.get()), (int)50, (boolean)true, (boolean)true, (boolean)((Boolean)this.swapBack.get()));
            if ((Integer)this.delay.get() == 0) continue;
            break;
        }
        this.placeThread = new Thread(() -> {
            if (this.mc.field_1724.method_37908() == null || this.mc.field_1724.method_6047().method_7909() == class_1802.field_8143) {
                return;
            }
            class_238 box = new class_238(this.mc.field_1724.method_33571().method_1031(-3.0, -3.0, -3.0), this.mc.field_1724.method_33571().method_1031(3.0, 3.0, 3.0));
            if (!this.mc.field_1724.method_37908().method_8390(class_1533.class, box, itemFrameEntity -> true).isEmpty()) {
                class_1533 itemFrame = (class_1533)this.mc.field_1724.method_37908().method_8390(class_1533.class, box, itemFrameEntity -> true).getFirst();
                c.method_2905((class_1657)this.mc.field_1724, (class_1297)itemFrame, class_1268.field_5808);
                if (itemFrame.method_6940().method_7947() > 0) {
                    if (((Boolean)this.rotateItem.get()).booleanValue()) {
                        c.method_2905((class_1657)this.mc.field_1724, (class_1297)itemFrame, class_1268.field_5808);
                    }
                    try {
                        TimeUnit.MILLISECONDS.sleep(600L);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    ++this.breakDelaytimer;
                    if (this.breakDelaytimer > (Integer)this.breakDelay.get()) {
                        c.method_2918((class_1657)this.mc.field_1724, (class_1297)itemFrame);
                        this.breakDelaytimer = 0;
                    }
                    try {
                        TimeUnit.MILLISECONDS.sleep(100L);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        this.placeThread.setName("PB-Thread");
        this.placeThread.start();
    }

    private boolean shouldPlace(class_2338 pistonPos) {
        class_2350 direction = (class_2350)this.mc.field_1687.method_8320(pistonPos).method_11654((class_2769)class_2318.field_10927);
        if (((Boolean)this.backOfPiston.get()).booleanValue()) {
            direction = direction.method_10153();
        }
        class_2338 iFramePos = pistonPos.method_10093(direction);
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            class_1533 itemFrame;
            if (!(entity instanceof class_1533) || !iFramePos.equals((Object)(itemFrame = (class_1533)entity).method_24515())) continue;
            return false;
        }
        return true;
    }
}

