/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.gui.GuiTheme
 *  meteordevelopment.meteorclient.gui.themes.meteor.MeteorGuiTheme
 *  meteordevelopment.meteorclient.renderer.text.TextRenderer
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 */
package com.wwe.addon.utilities;

import java.lang.reflect.Field;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.themes.meteor.MeteorGuiTheme;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class InertiaTheme
extends MeteorGuiTheme {
    private static final SettingColor INERTIA_RED = new SettingColor(148, 0, 0);

    public InertiaTheme() {
        try {
            Field field = GuiTheme.class.getDeclaredField("name");
            field.setAccessible(true);
            field.set((Object)this, "Inertia");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.applyColorSetting("accentColor", INERTIA_RED);
        this.applyColorSetting("checkboxColor", INERTIA_RED);
        this.applyColorSetting("textHighlightColor", new SettingColor(148, 0, 0, 255));
        this.applyColorSetting("backgroundColor", new SettingColor(29, 0, 0, 200));
        this.applyColorSetting("moduleBackground", new SettingColor(180, 7, 7, 255));
        this.applyColorSetting("scrollbarColor", new SettingColor(159, 8, 8, 255));
        this.applyColorSetting("starscriptText", INERTIA_RED);
        this.applyColorSetting("starscriptBraces", INERTIA_RED);
        this.applyColorSetting("starscriptNumbers", INERTIA_RED);
        this.setDefaultForSetting((Setting<SettingColor>)this.accentColor);
        this.setDefaultForSetting((Setting<SettingColor>)this.checkboxColor);
        this.setSliderHandleColors();
        this.applyColorSetting("sliderLeft", new SettingColor(255, 255, 255));
        this.applyScalarSetting("scale", 1.5);
    }

    private void applyColorSetting(String string, SettingColor settingColor) {
        Object object = this.getFieldValue(string);
        if (object == null) {
            return;
        }
        try {
            if (object instanceof Setting) {
                Setting setting = (Setting)object;
                setting.set((Object)settingColor);
                this.setDefaultValue(setting, settingColor);
                return;
            }
            Class<?> clazz = object.getClass();
            Field field = clazz.getDeclaredField("normal");
            Field field2 = clazz.getDeclaredField("hovered");
            Field field3 = clazz.getDeclaredField("pressed");
            field.setAccessible(true);
            field2.setAccessible(true);
            field3.setAccessible(true);
            this.setColorSetting(field.get(object), settingColor);
            this.setColorSetting(field2.get(object), settingColor);
            this.setColorSetting(field3.get(object), settingColor);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void applyScalarSetting(String string, Double d) {
        Object object = this.getFieldValue(string);
        if (object instanceof Setting) {
            Setting setting = (Setting)object;
            setting.set((Object)d);
            this.setDefaultValue(setting, d);
        }
    }

    private Object getFieldValue(String string) {
        try {
            for (Class<?> clazz = ((Object)((Object)this)).getClass(); clazz != null; clazz = clazz.getSuperclass()) {
                try {
                    Field field = clazz.getDeclaredField(string);
                    field.setAccessible(true);
                    return field.get((Object)this);
                }
                catch (NoSuchFieldException noSuchFieldException) {
                    continue;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    private void setColorSetting(Object object, SettingColor settingColor) {
        if (object instanceof Setting) {
            Setting setting = (Setting)object;
            setting.set((Object)settingColor);
            this.setDefaultValue(setting, settingColor);
        }
    }

    public TextRenderer textRenderer() {
        return TextRenderer.get();
    }

    private void setSliderHandleColors() {
        try {
            Field field = this.sliderHandle.getClass().getDeclaredField("normal");
            Field field2 = this.sliderHandle.getClass().getDeclaredField("hovered");
            Field field3 = this.sliderHandle.getClass().getDeclaredField("pressed");
            field.setAccessible(true);
            field2.setAccessible(true);
            field3.setAccessible(true);
            SettingColor settingColor = new SettingColor(255, 255, 255);
            Setting setting = (Setting)field.get(this.sliderHandle);
            Setting setting2 = (Setting)field2.get(this.sliderHandle);
            Setting setting3 = (Setting)field3.get(this.sliderHandle);
            setting.set((Object)settingColor);
            setting2.set((Object)settingColor);
            setting3.set((Object)settingColor);
            this.setDefaultValue(setting, settingColor);
            this.setDefaultValue(setting2, settingColor);
            this.setDefaultValue(setting3, settingColor);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void setDefaultForSetting(Setting<SettingColor> setting) {
        this.setDefaultValue(setting, INERTIA_RED);
    }

    private void setDefaultValue(Object object, Object object2) {
        if (object == null) {
            return;
        }
        try {
            Field field = Setting.class.getDeclaredField("defaultValue");
            field.setAccessible(true);
            field.set(object, object2);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

