/*
 * Decompiled with CFR 0.152.
 */
package com.wwe.addon.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;

public final class PacketMineTargetBodyHelper {
    private static final Map<Object, Object> TARGET_SETTINGS = new WeakHashMap<Object, Object>();

    private PacketMineTargetBodyHelper() {
    }

    public static void tick(Object object) {
        try {
            Object object2 = TARGET_SETTINGS.get(object);
            if (object2 == null && (object2 = PacketMineTargetBodyHelper.createTargetBodySetting(object)) != null) {
                TARGET_SETTINGS.put(object, object2);
            }
            if (!Boolean.TRUE.equals(PacketMineTargetBodyHelper.call(object2, "get", new Object[0]))) {
                return;
            }
            Object object3 = PacketMineTargetBodyHelper.getField(object, "pos");
            if (object3 != null) {
                return;
            }
            Object object4 = PacketMineTargetBodyHelper.getField(object, "mc");
            if (object4 == null) {
                return;
            }
            Object object5 = PacketMineTargetBodyHelper.getField(object4, "field_1687");
            Object object6 = PacketMineTargetBodyHelper.getField(object4, "field_1724");
            if (object5 == null || object6 == null) {
                return;
            }
            double d = PacketMineTargetBodyHelper.getNumberSetting(object, "range", 5.2);
            Object object7 = PacketMineTargetBodyHelper.findClosestPlayer(object5, object6, d);
            if (object7 == null) {
                return;
            }
            Object object8 = PacketMineTargetBodyHelper.call(object7, "method_24515", new Object[0]);
            if (object8 == null) {
                return;
            }
            Object object9 = PacketMineTargetBodyHelper.chooseBodyBlock(object5, object8, object7);
            if (object9 == null) {
                return;
            }
            if (PacketMineTargetBodyHelper.outOfRange(object, object9)) {
                return;
            }
            Class<?> clazz = Class.forName("net.minecraft.class_2350");
            Enum enum_ = Enum.valueOf(clazz.asSubclass(Enum.class), "UP");
            PacketMineTargetBodyHelper.setField(object, "direction", enum_);
            Object object10 = PacketMineTargetBodyHelper.call(object5, "method_8320", object9);
            if (object10 == null) {
                return;
            }
            PacketMineTargetBodyHelper.setField(object, "pos", object9);
            PacketMineTargetBodyHelper.setField(object, "lastState", object10);
            Method method = PacketMineTargetBodyHelper.findMethod(object.getClass(), "startMining", 2);
            if (method == null) {
                return;
            }
            method.setAccessible(true);
            method.invoke(object, object9, PacketMineTargetBodyHelper.getBooleanSetting(object, "rotate", false));
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static Object createTargetBodySetting(Object object) throws Exception {
        Method method = PacketMineTargetBodyHelper.findMethod(object.getClass(), "setting", 3);
        if (method == null) {
            return null;
        }
        method.setAccessible(true);
        Object[] objectArray = new Object[]{"target-body", "Automatically selects a nearby player's body/surround block for PacketMine without a manual hit.", Boolean.FALSE};
        return method.invoke(object, objectArray);
    }

    private static Object findClosestPlayer(Object object, Object object2, double d) throws Exception {
        Object object3 = PacketMineTargetBodyHelper.call(object, "method_18456", new Object[0]);
        if (!(object3 instanceof Iterable)) {
            return null;
        }
        Iterable iterable = (Iterable)object3;
        Object var6_5 = null;
        double d2 = d * d;
        for (Object t : iterable) {
            Double d3;
            Object object4;
            if (t == null || t == object2 || !PacketMineTargetBodyHelper.isPlayer(t) || Boolean.TRUE.equals(object4 = PacketMineTargetBodyHelper.call(t, "method_5765", new Object[0])) || (d3 = PacketMineTargetBodyHelper.distanceSq(object2, t)) == null || !(d3 < d2)) continue;
            d2 = d3;
            var6_5 = t;
        }
        return var6_5;
    }

    private static Object chooseBodyBlock(Object object, Object object2, Object object3) throws Exception {
        int[][] nArrayArray = new int[][]{{1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}, {1, 1, 0}, {-1, 1, 0}, {0, 1, 1}, {0, 1, -1}, {1, -1, 0}, {-1, -1, 0}, {0, -1, 1}, {0, -1, -1}};
        Class<?> clazz = Class.forName("net.minecraft.class_2338");
        Object object4 = null;
        for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
            Class<?>[] classArray;
            if (constructor.getParameterCount() != 3 || (classArray = constructor.getParameterTypes())[0] != Integer.TYPE || classArray[1] != Integer.TYPE || classArray[2] != Integer.TYPE) continue;
            object4 = constructor;
            break;
        }
        if (object4 == null) {
            return null;
        }
        ((Constructor)object4).setAccessible(true);
        int n = PacketMineTargetBodyHelper.intCall(object2, "method_10263");
        int n2 = PacketMineTargetBodyHelper.intCall(object2, "method_10264");
        int n3 = PacketMineTargetBodyHelper.intCall(object2, "method_10260");
        for (Object object5 : (Constructor<?>)nArrayArray) {
            Object t = ((Constructor)object4).newInstance(n + object5[0], n2 + object5[1], n3 + object5[2]);
            if (!PacketMineTargetBodyHelper.isMineable(object, t)) continue;
            return t;
        }
        return null;
    }

    private static boolean isMineable(Object object, Object object2) {
        try {
            Object object3 = PacketMineTargetBodyHelper.call(object, "method_8320", object2);
            if (object3 == null) {
                return false;
            }
            if (Boolean.TRUE.equals(PacketMineTargetBodyHelper.call(object3, "method_26215", new Object[0]))) {
                return false;
            }
            Object object4 = PacketMineTargetBodyHelper.call(object3, "method_26214", null, null);
            return object4 instanceof Number && ((Number)object4).floatValue() > 0.0f;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private static Double distanceSq(Object object, Object object2) {
        try {
            Method method = PacketMineTargetBodyHelper.findCompatibleMethod(object.getClass(), "method_5739", 1);
            if (method != null) {
                method.setAccessible(true);
                Object object3 = method.invoke(object, object2);
                if (object3 instanceof Number) {
                    Number number = (Number)object3;
                    double d = number.doubleValue();
                    return d * d;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private static boolean outOfRange(Object object, Object object2) {
        try {
            Object object3;
            Object object4 = PacketMineTargetBodyHelper.getField(object, "range");
            Object object5 = PacketMineTargetBodyHelper.getField(object, "origin");
            Object object6 = object4 == null ? null : PacketMineTargetBodyHelper.call(object4, "get", new Object[0]);
            Object object7 = object3 = object5 == null ? null : PacketMineTargetBodyHelper.call(object5, "get", new Object[0]);
            if (!(object6 instanceof Number) || object3 == null) {
                return false;
            }
            Class<?> clazz = Class.forName("com.wwe.addon.complements.mine.BlockUtils2");
            for (Method method : clazz.getDeclaredMethods()) {
                if (!method.getName().equals("outOfMiningRange") || method.getParameterCount() != 3) continue;
                method.setAccessible(true);
                Object object8 = method.invoke(null, object2, object3, ((Number)object6).doubleValue());
                return Boolean.TRUE.equals(object8);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private static boolean isPlayer(Object object) {
        try {
            Class<?> clazz = Class.forName("net.minecraft.class_1657");
            return clazz.isInstance(object);
        }
        catch (Throwable throwable) {
            return object.getClass().getName().contains("class_1657");
        }
    }

    private static double getNumberSetting(Object object, String string, double d) {
        try {
            Object object2 = PacketMineTargetBodyHelper.getField(object, string);
            Object object3 = object2 == null ? null : PacketMineTargetBodyHelper.call(object2, "get", new Object[0]);
            return object3 instanceof Number ? ((Number)object3).doubleValue() : d;
        }
        catch (Throwable throwable) {
            return d;
        }
    }

    private static boolean getBooleanSetting(Object object, String string, boolean bl) {
        try {
            Object object2 = PacketMineTargetBodyHelper.getField(object, string);
            Object object3 = object2 == null ? null : PacketMineTargetBodyHelper.call(object2, "get", new Object[0]);
            return object3 instanceof Boolean ? (Boolean)object3 : bl;
        }
        catch (Throwable throwable) {
            return bl;
        }
    }

    private static int intCall(Object object, String string) throws Exception {
        Object object2 = PacketMineTargetBodyHelper.call(object, string, new Object[0]);
        return object2 instanceof Number ? ((Number)object2).intValue() : 0;
    }

    private static Object call(Object object, String string, Object ... objectArray) throws Exception {
        if (object == null) {
            return null;
        }
        Method method = PacketMineTargetBodyHelper.findCompatibleMethod(object.getClass(), string, objectArray.length);
        if (method == null) {
            return null;
        }
        method.setAccessible(true);
        return method.invoke(object, objectArray);
    }

    private static Method findMethod(Class<?> clazz, String string, int n) {
        return PacketMineTargetBodyHelper.findCompatibleMethod(clazz, string, n);
    }

    /*
     * WARNING - void declaration
     */
    private static Method findCompatibleMethod(Class<?> methodArray, String string, int n) {
        void var3_4;
        Method[] object = methodArray;
        while (var3_4 != null) {
            Method[] methodArray2 = var3_4.getDeclaredMethods();
            int n2 = methodArray2.length;
            for (int i = 0; i < n2; ++i) {
                Method method = methodArray2[i];
                if (!method.getName().equals(string) || method.getParameterCount() != n) continue;
                return method;
            }
            Class clazz = var3_4.getSuperclass();
        }
        for (Method method : methodArray.getMethods()) {
            if (!method.getName().equals(string) || method.getParameterCount() != n) continue;
            return method;
        }
        return null;
    }

    private static Object getField(Object object, String string) {
        if (object == null) {
            return null;
        }
        try {
            for (Class<?> clazz = object.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
                try {
                    Field field = clazz.getDeclaredField(string);
                    field.setAccessible(true);
                    return field.get(object);
                }
                catch (NoSuchFieldException noSuchFieldException) {
                    continue;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private static void setField(Object object, String string, Object object2) {
        if (object == null) {
            return;
        }
        try {
            for (Class<?> clazz = object.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
                try {
                    Field field = clazz.getDeclaredField(string);
                    field.setAccessible(true);
                    field.set(object, object2);
                    return;
                }
                catch (NoSuchFieldException noSuchFieldException) {
                    continue;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

