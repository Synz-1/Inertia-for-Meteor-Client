/*
 * Decompiled with CFR 0.152.
 */
package com.wwe.addon.module.impl;

import java.util.function.Predicate;

public final class AutoCrystal$AlwaysTruePredicate
implements Predicate {
    public boolean test(Object object) {
        return true;
    }
}

