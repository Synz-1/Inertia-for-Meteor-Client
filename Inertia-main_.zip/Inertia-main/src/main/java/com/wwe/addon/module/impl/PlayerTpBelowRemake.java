/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.EnumSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.settings.StringSetting$Builder
 *  meteordevelopment.meteorclient.systems.friends.Friends
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1657
 *  net.minecraft.class_1922
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2374
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2680
 *  net.minecraft.class_2828$class_2829
 *  net.minecraft.class_2828$class_2830
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import com.wwe.addon.module.impl.PlayerTp;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2828;

public class PlayerTpBelowRemake
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgTP;
    private final Setting<PlayerTp.TargetMode> targetMode;
    private final Setting<String> specificPlayer;
    private final Setting<Double> range;
    private final Setting<Boolean> ignoreFriends;
    private final Setting<Boolean> stopAtTarget;
    private final Setting<Boolean> disableAtTarget;
    private final Setting<PlayerTp.TpMode> tpMode;
    private final Setting<Integer> vanillaPackets;
    private final Setting<Integer> paperPackets;
    private final Setting<Boolean> goUp;
    private class_1657 target;

    public PlayerTpBelowRemake() {
        super(inertia.inertia, "TpBelow", "-1 lower than your enemy.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgTP = this.settings.createGroup("Teleport");
        this.targetMode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("target-mode")).defaultValue((Object)PlayerTp.TargetMode.Nearest)).build());
        this.specificPlayer = this.sgGeneral.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("specific-player")).defaultValue((Object)"")).visible(() -> this.targetMode.get() == PlayerTp.TargetMode.Specific)).build());
        this.range = this.sgGeneral.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("range")).defaultValue(50.0).min(1.0).max(200.0).build());
        this.ignoreFriends = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("ignore-friends")).defaultValue((Object)true)).build());
        this.stopAtTarget = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("stop-at-target")).defaultValue((Object)true)).build());
        this.disableAtTarget = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("disable-at-target")).defaultValue((Object)false)).build());
        this.tpMode = this.sgTP.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("tp-mode")).defaultValue((Object)PlayerTp.TpMode.Vanilla)).build());
        this.vanillaPackets = this.sgTP.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("vanilla-packets")).defaultValue((Object)4)).min(1).sliderMax(20).visible(() -> this.tpMode.get() == PlayerTp.TpMode.Vanilla)).build());
        this.paperPackets = this.sgTP.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("paper-packets")).defaultValue((Object)5)).min(1).sliderMax(20).visible(() -> this.tpMode.get() == PlayerTp.TpMode.Paper)).build());
        this.goUp = this.sgTP.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("vclip")).defaultValue((Object)true)).build());
        this.target = null;
    }

    public void onActivate() {
        this.target = null;
    }

    public void onDeactivate() {
        if (this.mc.field_1724 != null) {
            this.mc.field_1724.method_18800(0.0, 0.0, 0.0);
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.target == null || !this.target.method_5805()) {
            this.target = this.getTarget();
            return;
        }
        if (this.playerDistanceTo(this.target) <= 0.5) {
            if (((Boolean)this.stopAtTarget.get()).booleanValue()) {
                this.mc.field_1724.method_18800(0.0, 0.0, 0.0);
            }
            if (((Boolean)this.disableAtTarget.get()).booleanValue()) {
                this.toggle();
            }
            return;
        }
        this.doTeleport();
    }

    private void doTeleport() {
        class_243 startPos = new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
        class_243 destPos = new class_243(Math.floor(this.target.method_23317()) + 0.5, this.target.method_23318() - 1.0, Math.floor(this.target.method_23321()) + 0.5);
        if (this.invalid(destPos) && (destPos = this.findNearestValid(destPos)) == null) {
            return;
        }
        class_243[] clip = new class_243[]{startPos, destPos};
        boolean found = false;
        if (this.hasClearPath(startPos, destPos)) {
            found = true;
        } else if (((Boolean)this.goUp.get()).booleanValue()) {
            double maxY = Math.max(startPos.field_1351, destPos.field_1351);
            for (double y = maxY + 1.0; y < maxY + 50.0; y += 1.0) {
                class_243 up1 = new class_243(startPos.field_1352, y, startPos.field_1350);
                class_243 up2 = new class_243(destPos.field_1352, y, destPos.field_1350);
                if (this.invalid(up1) || this.invalid(up2) || !this.hasClearPath(up1, up2)) continue;
                clip[0] = up1;
                clip[1] = up2;
                found = true;
                break;
            }
        }
        if (!found) {
            this.ghostFallback(startPos, destPos);
            return;
        }
        int spoof = this.tpMode.get() == PlayerTp.TpMode.Vanilla ? (Integer)this.vanillaPackets.get() : (Integer)this.paperPackets.get();
        for (int i = 0; i < spoof; ++i) {
            this.sendMove(startPos);
        }
        if (!clip[0].equals((Object)startPos)) {
            this.sendMove(clip[0]);
        }
        if (!clip[1].equals((Object)destPos)) {
            this.sendMove(clip[1]);
        }
        this.sendMove(destPos);
        this.mc.field_1724.method_5814(destPos.field_1352, destPos.field_1351, destPos.field_1350);
        this.mc.field_1724.method_18800(0.0, 0.0, 0.0);
    }

    private void ghostFallback(class_243 startPos, class_243 destPos) {
        double dist = this.playerDistanceTo(this.target);
        double step = dist > 20.0 ? 2.0 : (dist > 5.0 ? 1.0 : 0.5);
        double scanStep = 0.05;
        double vStep = 0.5;
        int maxClimb = dist > 20.0 ? 20 : 10;
        double toX = destPos.field_1352;
        double toY = destPos.field_1351;
        double toZ = destPos.field_1350;
        double[] pos = this.sendPhaseXZ(startPos.field_1352, startPos.field_1351, startPos.field_1350, toX, toZ, step, scanStep, vStep, maxClimb);
        this.sendPhaseY(pos[0], pos[1], pos[2], toX, toY, toZ, step, scanStep);
        this.mc.field_1724.method_5814(toX, toY, toZ);
        this.mc.field_1724.method_18800(0.0, 0.0, 0.0);
    }

    private double[] sendPhaseXZ(double fromX, double fromY, double fromZ, double toX, double toZ, double step, double scanStep, double vStep, int maxClimb) {
        double dx = toX - fromX;
        double dz = toZ - fromZ;
        double distXZ = Math.sqrt(dx * dx + dz * dz);
        if (distXZ < 0.01) {
            return new double[]{fromX, fromY, fromZ};
        }
        double dirX = dx / distXZ;
        double dirZ = dz / distXZ;
        double curX = fromX;
        double curY = fromY;
        double curZ = fromZ;
        double traveled = 0.0;
        while (traveled < distXZ - 0.001) {
            double nz;
            double thisStep = Math.min(step, distXZ - traveled);
            double nx = curX + dirX * thisStep;
            if (!this.isSolid(nx, curY, nz = curZ + dirZ * thisStep)) {
                this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(nx, curY, nz, false, false));
                curX = nx;
                curZ = nz;
                traveled += thisStep;
                continue;
            }
            boolean passed = false;
            for (int climb = 1; climb <= maxClimb; ++climb) {
                double tryY = curY + (double)climb * vStep;
                if (this.isSolid(nx, tryY, nz)) continue;
                for (int c = 1; c <= climb; ++c) {
                    this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(curX, curY + (double)c * vStep, curZ, false, false));
                }
                curY = tryY;
                this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(nx, curY, nz, false, false));
                curX = nx;
                curZ = nz;
                traveled += thisStep;
                passed = true;
                break;
            }
            if (passed) continue;
            double scanX = curX + dirX * scanStep;
            double scanZ = curZ + dirZ * scanStep;
            double scanned = scanStep;
            while (this.isSolid(scanX, curY, scanZ) && traveled + scanned < distXZ) {
                scanX += dirX * scanStep;
                scanZ += dirZ * scanStep;
                scanned += scanStep;
            }
            if (this.isSolid(scanX, curY, scanZ)) break;
            this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(scanX, curY, scanZ, false, false));
            curX = scanX;
            curZ = scanZ;
            traveled += scanned;
        }
        return new double[]{curX, curY, curZ};
    }

    private void sendPhaseY(double fromX, double fromY, double fromZ, double toX, double toY, double toZ, double step, double scanStep) {
        double dy = toY - fromY;
        double distY = Math.abs(dy);
        if (distY < 0.01) {
            this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(toX, toY, toZ, false, false));
            return;
        }
        double dirY = Math.signum(dy);
        double curY = fromY;
        double traveled = 0.0;
        while (traveled < distY - 0.001) {
            double thisStep = Math.min(step, distY - traveled);
            double ny = curY + dirY * thisStep;
            if (!this.isSolid(toX, ny, toZ)) {
                this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(toX, ny, toZ, false, false));
                curY = ny;
                traveled += thisStep;
                continue;
            }
            double scanY = ny;
            double scanned = thisStep;
            while (this.isSolid(toX, scanY, toZ) && traveled + scanned < distY) {
                scanY += dirY * scanStep;
                scanned += scanStep;
            }
            if (this.isSolid(toX, scanY, toZ)) break;
            this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(toX, scanY, toZ, false, false));
            curY = scanY;
            traveled += scanned;
        }
        this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(toX, toY, toZ, false, false));
        this.mc.method_1562().method_52787((class_2596)new class_2828.class_2829(toX, toY, toZ, false, false));
    }

    private void sendMove(class_243 pos) {
        if (this.mc.method_1562() == null) {
            return;
        }
        this.mc.method_1562().method_52787((class_2596)new class_2828.class_2830(pos.field_1352, pos.field_1351, pos.field_1350, this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455(), false, false));
    }

    private boolean invalid(class_243 pos) {
        if (this.mc.field_1687 == null) {
            return true;
        }
        class_2338 bp = class_2338.method_49638((class_2374)pos);
        if (this.mc.field_1687.method_8497(bp.method_10263() >> 4, bp.method_10260() >> 4) == null) {
            return true;
        }
        class_243 playerPos = new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
        class_238 box = this.mc.field_1724.method_5829().method_997(pos.method_1020(playerPos));
        for (class_2338 b : class_2338.method_10097((class_2338)class_2338.method_49637((double)box.field_1323, (double)box.field_1322, (double)box.field_1321), (class_2338)class_2338.method_49637((double)box.field_1320, (double)box.field_1325, (double)box.field_1324))) {
            class_2680 state = this.mc.field_1687.method_8320(b);
            if (state.method_27852(class_2246.field_10164)) {
                return true;
            }
            if (state.method_26220((class_1922)this.mc.field_1687, b).method_1110()) continue;
            return true;
        }
        return false;
    }

    private class_243 findNearestValid(class_243 desired) {
        for (int x = -2; x <= 2; ++x) {
            for (int y = -2; y <= 2; ++y) {
                for (int z = -2; z <= 2; ++z) {
                    class_243 test = desired.method_1031((double)x, (double)y, (double)z);
                    if (this.invalid(test)) continue;
                    return test;
                }
            }
        }
        return null;
    }

    private boolean hasClearPath(class_243 start, class_243 end) {
        double dist = start.method_1022(end);
        int steps = (int)(dist * 2.5);
        for (int i = 0; i <= steps; ++i) {
            if (!this.invalid(start.method_35590(end, (double)i / (double)steps))) continue;
            return false;
        }
        return true;
    }

    private boolean isSolid(double x, double y, double z) {
        if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
            return false;
        }
        class_238 original = this.mc.field_1724.method_5829();
        double w = (original.field_1320 - original.field_1323) / 2.0;
        double h = original.field_1325 - original.field_1322;
        class_238 box = new class_238(x - w, y, z - w, x + w, y + h, z + w);
        return !this.mc.field_1687.method_18026(box);
    }

    private double playerDistanceTo(class_1657 p) {
        if (this.mc.field_1724 == null) {
            return 0.0;
        }
        double dx = p.method_23317() - this.mc.field_1724.method_23317();
        double dy = p.method_23318() - this.mc.field_1724.method_23318();
        double dz = p.method_23321() - this.mc.field_1724.method_23321();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private class_1657 getTarget() {
        if (this.mc.field_1687 == null) {
            return null;
        }
        List players = this.mc.field_1687.method_18456().stream().filter(p -> {
            if (p == this.mc.field_1724 || !p.method_5805()) {
                return false;
            }
            if (((Boolean)this.ignoreFriends.get()).booleanValue() && Friends.get().isFriend((class_1657)p)) {
                return false;
            }
            return this.playerDistanceTo((class_1657)p) <= (Double)this.range.get();
        }).collect(Collectors.toList());
        if (this.targetMode.get() == PlayerTp.TargetMode.Nearest) {
            return players.stream().min(Comparator.comparingDouble(this::playerDistanceTo)).orElse(null);
        }
        if (((String)this.specificPlayer.get()).isEmpty()) {
            return null;
        }
        String name = (String)this.specificPlayer.get();
        return players.stream().filter(p -> p.method_5477().getString().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public String getInfoString() {
        if (this.mc.field_1724 == null || this.target == null) {
            return null;
        }
        return String.format("%s %.1fm", this.target.method_5477().getString(), this.playerDistanceTo(this.target));
    }
}

