/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Send
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.renderer.ShapeMode
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.utils.player.Rotations
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.meteorclient.utils.world.TickRate
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1292
 *  net.minecraft.class_1294
 *  net.minecraft.class_1309
 *  net.minecraft.class_1799
 *  net.minecraft.class_1890
 *  net.minecraft.class_1893
 *  net.minecraft.class_1922
 *  net.minecraft.class_1934
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_2596
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_2868
 *  net.minecraft.class_3486
 *  net.minecraft.class_3532
 *  net.minecraft.class_640
 *  net.minecraft.class_6880
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.complements.mine.BlockUtils2;
import com.wwe.addon.complements.mine.ColorUtils;
import com.wwe.addon.complements.mine.Origin;
import com.wwe.addon.complements.mine.RandUtils;
import com.wwe.addon.inertia;
import com.wwe.addon.module.impl.PacketMineCompatBase;
import com.wwe.addon.module.impl.PacketMineTargetBodyHelper;
import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_640;
import net.minecraft.class_6880;

public class PacketMine
extends PacketMineCompatBase {
    private final Setting<Boolean> strict = this.setting("strict", "For test 2b. might be buggy.", false);
    private final Setting<Double> range = this.setting("range", "How many blocks away you can mine.", 5.2, this.sgGeneral, 0.0, 6.0);
    private final Setting<Origin> origin = this.setting("range-mode", "How to calculate the range.", (Object)Origin.NCP, this.sgGeneral);
    private final Setting<Boolean> rotate = this.setting("rotate", "Whether to rotate when mining.", false);
    private final Setting<Boolean> autoMine = this.setting("auto-remine", "Continues mining the block when it gets replaced.", true);
    private final Setting<Boolean> eatPause = this.setting("pause-while-eating", "Won't swap slots while you are eating, to not interupt it.", true, this.sgGeneral, () -> (Boolean)this.autoMine.get() != false && (Boolean)this.strict.get() == false);
    private final Setting<Integer> maxInstaMineAttempts = this.setting("insta-mine-attempts", "How many times you want to attempt to insta mine in a row without having to remine.", 1, this.sgGeneral, () -> this.autoMine.get());
    private final Setting<Boolean> swing = this.setting("swing", "Makes your hand swing client side when mining.", false);
    private final Setting<Boolean> render = this.setting("render", "Renders the block you are mining.", true);
    private final Setting<ShapeMode> shapeMode = this.setting("shape-mode", "How the shape is being rendered.", (Object)ShapeMode.Both, () -> this.render.get());
    private final Setting<SettingColor> sideColor = this.setting("side-color", "The side color.", 255, 0, 0, 75, this.sgGeneral, () -> this.render.get());
    private final Setting<SettingColor> lineColor = this.setting("line-color", "The line color.", 255, 0, 0, this.sgGeneral, () -> this.render.get());
    private final Setting<Boolean> percColors = this.setting("progress-colors", "Will render red when starting and green when finished with gradient.", false, this.sgGeneral, () -> this.render.get());
    private float progress;
    private volatile boolean hasSwitched;
    private long breakTimeMs;
    private int bestSlot;
    private int amountOfInstaBreaks;
    private class_2680 lastState;
    private class_2338 pos;
    private class_2350 direction;

    public PacketMine() {
        super(inertia.inertia, "AutoMine", "Actual good packet mine. Can be used as auto mine.");
    }

    private void onTick$original(TickEvent.Pre event) {
        boolean wasntFinished;
        if (this.progress == -1.0f || this.pos == null || this.lastState == null) {
            return;
        }
        if (BlockUtils2.outOfMiningRange(this.pos, (Origin)((Object)this.origin.get()), (Double)this.range.get())) {
            this.pos = null;
            this.lastState = null;
            return;
        }
        this.lastState = this.mc.field_1687.method_8320(this.pos);
        this.findBestSlot();
        boolean bl = wasntFinished = this.progress < 1.0f;
        if (!this.lastState.method_26215()) {
            this.progress = (float)((double)this.progress + Math.max(0.0, this.getBreakDelta(this.bestSlot != -1 ? this.bestSlot : this.mc.field_1724.method_31548().method_67532(), this.lastState)) * 20.0 / (double)TickRate.INSTANCE.getTickRate());
        }
        if (this.progress >= 1.0f) {
            if (this.lastState.method_26215()) {
                this.hasSwitched = false;
                return;
            }
            if (!this.hasSwitched && this.amountOfInstaBreaks <= (Integer)this.maxInstaMineAttempts.get()) {
                if (this.canSwitch()) {
                    this.doBreakAndSwitch(this.pos, (Boolean)this.rotate.get());
                    if (wasntFinished) {
                    }
                }
            } else {
                if ((double)TickRate.INSTANCE.getTimeSinceLastTick() > 1.5) {
                    return;
                }
                class_640 playerlistEntry = this.mc.field_1724.field_3944.method_2871(this.mc.field_1724.method_7334().getId());
                if (playerlistEntry != null && (float)(System.currentTimeMillis() - this.breakTimeMs) > (float)class_3532.method_15340((int)playerlistEntry.method_2959(), (int)50, (int)300) * 20.0f / TickRate.INSTANCE.getTickRate()) {
                    if (((Boolean)this.autoMine.get()).booleanValue()) {
                        if (this.amountOfInstaBreaks < (Integer)this.maxInstaMineAttempts.get() && this.canSwitch()) {
                            this.doBreakAndSwitch(this.pos, (Boolean)this.rotate.get());
                        }
                        this.startMining(this.pos, (Boolean)this.rotate.get());
                    } else {
                        this.pos = null;
                        this.lastState = null;
                    }
                }
            }
        }
    }

    private void doBreakAndSwitch(class_2338 pos, boolean rotate) {
        if (rotate) {
            Rotations.rotate((double)Rotations.getYaw((class_2338)pos), (double)Rotations.getPitch((class_2338)pos), (int)50, () -> this.doBreakAndSwitch(pos, false));
            return;
        }
        this.findBestSlot();
        if (this.bestSlot != -1) {
            this.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(this.bestSlot));
        }
        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12973, pos, this.direction));
        RandUtils.swing((Boolean)this.swing.get());
        this.breakTimeMs = System.currentTimeMillis();
        this.hasSwitched = true;
        ++this.amountOfInstaBreaks;
        if (this.bestSlot != -1) {
            this.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(this.mc.field_1724.method_31548().method_67532()));
        }
    }

    @EventHandler
    private void onStartMining(StartBreakingBlockEvent event) {
        class_1934 gamemode;
        class_640 playerlistEntry = this.mc.field_1724.field_3944.method_2871(this.mc.field_1724.method_7334().getId());
        if (playerlistEntry != null && ((gamemode = playerlistEntry.method_2958()) == class_1934.field_9219 || gamemode == class_1934.field_9216)) {
            return;
        }
        class_2680 blockState = this.mc.field_1687.method_8320(event.blockPos);
        if (blockState.method_26214(null, null) <= 0.0f) {
            this.pos = null;
            this.lastState = null;
            return;
        }
        event.cancel();
        if (BlockUtils2.outOfMiningRange(event.blockPos, (Origin)((Object)this.origin.get()), (Double)this.range.get())) {
            this.pos = null;
            return;
        }
        this.direction = event.direction;
        if (event.blockPos.equals((Object)this.pos)) {
            return;
        }
        this.pos = event.blockPos;
        this.lastState = blockState;
        this.startMining(this.pos, (Boolean)this.rotate.get());
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (this.pos == null) {
            return;
        }
        class_2596 class_25962 = event.packet;
        if (class_25962 instanceof class_2846) {
            class_2846 packet = (class_2846)class_25962;
            if (packet.method_12362().equals((Object)this.pos) || this.mc.field_1687.method_8320(this.pos).method_26215()) {
                return;
            }
            event.cancel();
        } else {
            class_25962 = event.packet;
            if (class_25962 instanceof class_2868) {
                class_2868 packet = (class_2868)class_25962;
                if (((Boolean)this.strict.get()).booleanValue() && this.bestSlot != -1 && packet.method_12442() != this.bestSlot && !this.hasSwitched && this.lastState != null && !this.lastState.method_26215()) {
                    if (((Boolean)this.autoMine.get()).booleanValue()) {
                        event.cancel();
                    } else {
                        this.pos = null;
                    }
                }
            }
        }
    }

    private void startMining(class_2338 pos, boolean rotate) {
        if (pos == null) {
            return;
        }
        if (rotate) {
            Rotations.rotate((double)Rotations.getYaw((class_2338)pos), (double)Rotations.getPitch((class_2338)pos), (int)50, () -> this.startMining(pos, false));
            return;
        }
        if (((Boolean)this.strict.get()).booleanValue()) {
            this.findBestSlot();
            if (this.bestSlot != -1) {
                this.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(this.bestSlot));
            }
        }
        this.hasSwitched = false;
        this.amountOfInstaBreaks = 0;
        this.progress = 0.0f;
        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12968, pos, this.direction));
        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12971, pos, this.direction));
        RandUtils.swing((Boolean)this.swing.get());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (this.pos == null || this.lastState == null || this.progress == -1.0f || !((Boolean)this.render.get()).booleanValue()) {
            return;
        }
        float prog = 1.0f - class_3532.method_15363((float)((this.progress > 0.5f ? this.progress - 0.5f : 0.5f - this.progress) * 2.0f), (float)0.0f, (float)1.0f);
        class_265 shape = this.lastState.method_26218((class_1922)this.mc.field_1687, this.pos);
        if (shape.method_1110()) {
            return;
        }
        class_238 original = shape.method_1107();
        class_238 box = original.method_1002(original.method_17939() * (double)prog, original.method_17940() * (double)prog, original.method_17941() * (double)prog);
        double xShrink = original.method_17939() * (double)prog * 0.5;
        double yShrink = original.method_17940() * (double)prog * 0.5;
        double zShrink = original.method_17941() * (double)prog * 0.5;
        Color sideProgressColor = ColorUtils.getColorFromPercent(this.progress).a(((SettingColor)this.sideColor.get()).a);
        Color lineProgressColor = ColorUtils.getColorFromPercent(this.progress).a(((SettingColor)this.lineColor.get()).a);
        event.renderer.box((double)this.pos.method_10263() + box.field_1323 + xShrink, (double)this.pos.method_10264() + box.field_1322 + yShrink, (double)this.pos.method_10260() + box.field_1321 + zShrink, (double)this.pos.method_10263() + box.field_1320 + xShrink, (double)this.pos.method_10264() + box.field_1325 + yShrink, (double)this.pos.method_10260() + box.field_1324 + zShrink, (Boolean)this.percColors.get() != false ? sideProgressColor : (Color)this.sideColor.get(), (Boolean)this.percColors.get() != false ? lineProgressColor : (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
    }

    private boolean canSwitch() {
        if (!((Boolean)this.eatPause.get()).booleanValue() || this.bestSlot == -1) {
            return true;
        }
        return !this.mc.field_1724.method_6115() || this.mc.field_1724.method_6058() == class_1268.field_5810;
    }

    public class_2680 getState(class_2338 pos) {
        if (this.isActive() && this.hasSwitched && this.progress >= 1.0f && pos.equals((Object)this.pos)) {
            return class_2246.field_10124.method_9564();
        }
        return this.mc.field_1687.method_8320(pos);
    }

    public boolean isMineTarget(class_2338 pos) {
        return this.isActive() && pos.equals((Object)this.pos) && this.progress > 0.0f;
    }

    private void findBestSlot() {
        if (this.lastState == null) {
            return;
        }
        this.bestSlot = -1;
        double bestScore = -1.0;
        for (int i = 0; i < 9; ++i) {
            class_1799 itemStack = this.mc.field_1724.method_31548().method_5438(i);
            float score = itemStack.method_7924(this.lastState);
            if (score == 1.0f || !((double)score > bestScore)) continue;
            bestScore = score;
            this.bestSlot = i;
        }
    }

    private double getBreakDelta(int slot, class_2680 state) {
        class_640 playerlistEntry = this.mc.field_1724.field_3944.method_2871(this.mc.field_1724.method_7334().getId());
        if (playerlistEntry != null && playerlistEntry.method_2958() == class_1934.field_9220) {
            return 1.0;
        }
        float hardness = state.method_26214(null, null);
        if (hardness == -1.0f) {
            return 0.0;
        }
        float speed = ((class_1799)this.mc.field_1724.method_31548().method_67533().get(slot)).method_7924(state);
        if (speed > 1.0f) {
            class_1799 tool = this.mc.field_1724.method_31548().method_5438(slot);
            int efficiency = this.getEfficiencyLevel21_5(tool);
            if (efficiency > 0 && !tool.method_7960()) {
                speed += (float)(efficiency * efficiency + 1);
            }
        }
        if (class_1292.method_5576((class_1309)this.mc.field_1724)) {
            speed *= 1.0f + (float)(class_1292.method_5575((class_1309)this.mc.field_1724) + 1) * 0.2f;
        }
        if (this.mc.field_1724.method_6059(class_1294.field_5901)) {
            speed *= (float)(this.mc.field_1724.method_6112(class_1294.field_5901).method_5578() + 1) * 0.3f;
        }
        if (this.mc.field_1724.method_5777(class_3486.field_15517) && !class_1890.method_8200((class_1309)this.mc.field_1724)) {
            speed /= 5.0f;
        }
        if (!this.mc.field_1724.method_24828()) {
            speed /= 5.0f;
        }
        return speed / hardness / (float)(!state.method_29291() || ((class_1799)this.mc.field_1724.method_31548().method_67533().get(slot)).method_7951(state) ? 30 : 100);
    }

    public void onDeactivate() {
        this.pos = null;
        this.lastState = null;
        this.progress = -1.0f;
        this.bestSlot = -1;
        if (this.mc.field_1724 == null) {
            return;
        }
        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(this.mc.field_1724.method_31548().method_67532()));
    }

    private int getEfficiencyLevel21_5(class_1799 class_17992) {
        return class_1890.method_8225((class_6880)this.mc.field_1724.method_56673().method_66874(class_1893.field_9131), (class_1799)class_17992);
    }

    @EventHandler
    private void onTick(TickEvent.Pre pre) {
        PacketMineTargetBodyHelper.tick((Object)this);
        this.onTick$original(pre);
    }
}

