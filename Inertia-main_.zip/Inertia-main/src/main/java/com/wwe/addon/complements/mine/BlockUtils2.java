/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.wwe.addon.complements.mine.AntiCheatHelper
 *  com.wwe.addon.complements.mine.DamageCalcUtils
 *  com.wwe.addon.complements.mine.Statistics
 *  meteordevelopment.meteorclient.MeteorClient
 *  meteordevelopment.meteorclient.utils.Utils
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.Rotations
 *  net.minecraft.class_1268
 *  net.minecraft.class_1269
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1747
 *  net.minecraft.class_1750
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1922
 *  net.minecraft.class_1937
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 *  net.minecraft.class_2848
 *  net.minecraft.class_2848$class_2849
 *  net.minecraft.class_2868
 *  net.minecraft.class_2885
 *  net.minecraft.class_3532
 *  net.minecraft.class_3545
 *  net.minecraft.class_3726
 *  net.minecraft.class_3965
 *  org.jetbrains.annotations.Nullable
 */
package com.wwe.addon.complements.mine;

import com.wwe.addon.complements.mine.AntiCheatHelper;
import com.wwe.addon.complements.mine.DamageCalcUtils;
import com.wwe.addon.complements.mine.Origin;
import com.wwe.addon.complements.mine.PlayerUtils2;
import com.wwe.addon.complements.mine.RandUtils;
import com.wwe.addon.complements.mine.Statistics;
import java.util.HashSet;
import java.util.Set;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

public class BlockUtils2
extends Utils {
    public static boolean placeBlock(FindItemResult result, class_2338 pos, boolean rotate, int rotationPriority, boolean airPlace, boolean ignoreEntity, boolean swing, boolean strictDirections) {
        if (!result.found()) {
            return false;
        }
        if (BlockUtils2.invalidPos(pos)) {
            return false;
        }
        if (!MeteorClient.mc.field_1687.method_8320(pos).method_26207().method_15800()) {
            return false;
        }
        class_1799 itemStack = PlayerUtils2.getStackFromResult(result);
        class_2680 placeState = class_2248.method_9503((class_1792)itemStack.method_7909()).method_9564();
        if (placeState.method_26215()) {
            return false;
        }
        if (!ignoreEntity && !MeteorClient.mc.field_1687.method_8628(placeState, pos, class_3726.method_16194())) {
            return false;
        }
        class_3965 hitResult = BlockUtils2.getPlaceResult(pos, airPlace, strictDirections);
        if (hitResult == null) {
            return false;
        }
        BlockUtils2.justPlace(result, hitResult, swing, rotate, rotationPriority);
        if (placeState.method_26204() == class_2246.field_10540) {
            Statistics.get().pendingObsidian.putIfAbsent(pos, System.currentTimeMillis());
        }
        return true;
    }

    public static void justPlace(FindItemResult item, class_3965 hitResult, boolean swing, boolean rotate, int rotationPriority) {
        boolean sneak;
        if (rotate) {
            Rotations.rotate((double)Rotations.getYaw((class_243)hitResult.method_17784()), (double)Rotations.getPitch((class_243)hitResult.method_17784()), (int)rotationPriority, () -> BlockUtils2.justPlace(item, hitResult, swing, false, 0));
            return;
        }
        class_1268 hand = RandUtils.hand(item);
        boolean notSelected = !item.isOffhand() && MeteorClient.mc.field_1724.method_31548().method_67532() != item.slot();
        boolean bl = sneak = !MeteorClient.mc.field_1724.method_5715() && BlockUtils2.clickableBlock(MeteorClient.mc.field_1687.method_8320(hitResult.method_17777()), hitResult, hand);
        if (sneak) {
            MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)MeteorClient.mc.field_1724, class_2848.class_2849.field_12979));
        }
        if (notSelected) {
            MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(item.slot()));
        }
        MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2885(hand, hitResult, 0));
        RandUtils.swing(swing, hand);
        if (notSelected) {
            MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2868(MeteorClient.mc.field_1724.method_31548().method_67532()));
        }
        if (sneak) {
            MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)MeteorClient.mc.field_1724, class_2848.class_2849.field_12984));
        }
    }

    public static boolean outOfMiningRange(class_2338 pos, Origin origin, double range) {
        double dz;
        double dy;
        if (origin == Origin.VANILLA) {
            double deltaZ;
            double deltaY;
            double deltaX = MeteorClient.mc.field_1724.method_23317() - ((double)pos.method_10263() + 0.5);
            return deltaX * deltaX + (deltaY = MeteorClient.mc.field_1724.method_23318() - ((double)pos.method_10264() + 0.5) + 1.5) * deltaY + (deltaZ = MeteorClient.mc.field_1724.method_23321() - ((double)pos.method_10260() + 0.5)) * deltaZ > range * range;
        }
        class_243 eyesPos = PlayerUtils2.eyePos((class_1657)MeteorClient.mc.field_1724);
        double dx = eyesPos.field_1352 - (double)pos.method_10263() - 0.5;
        return dx * dx + (dy = eyesPos.field_1351 - (double)pos.method_10264() - 0.5) * dy + (dz = eyesPos.field_1350 - (double)pos.method_10260() - 0.5) * dz > range * range;
    }

    public static boolean outOfPlaceRange(class_2338 pos, Origin origin, double range) {
        double dz;
        double dy;
        if (origin == Origin.VANILLA) {
            return MeteorClient.mc.field_1724.method_5649((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5) >= range * range;
        }
        class_243 eyesPos = PlayerUtils2.eyePos((class_1657)MeteorClient.mc.field_1724);
        double dx = eyesPos.field_1352 - (double)pos.method_10263() - 0.5;
        return dx * dx + (dy = eyesPos.field_1351 - (double)pos.method_10264() - 0.5) * dy + (dz = eyesPos.field_1350 - (double)pos.method_10260() - 0.5) * dz > range * range;
    }

    @Nullable
    public static class_3965 getPlaceResult(class_2338 block, boolean airPlace, boolean strictDirections) {
        return BlockUtils2.getPlaceResult(block, airPlace, strictDirections, null, null);
    }

    @Nullable
    public static class_3965 getPlaceResult(class_2338 block, boolean airPlace, boolean strictDirections, @Nullable class_1750 context, @Nullable class_1747 item) {
        class_2338 neighbor = null;
        class_2350 placeSide = null;
        if (strictDirections) {
            class_3545<class_2338, class_2350> pair = BlockUtils2.getStrictNeighbour(block);
            if (pair != null) {
                neighbor = (class_2338)pair.method_15442();
                placeSide = (class_2350)pair.method_15441();
            }
        } else {
            placeSide = BlockUtils2.getClosestDirection(block, true);
            if (placeSide != null) {
                neighbor = block.method_10093(placeSide);
                placeSide = placeSide.method_10153();
            }
        }
        if (neighbor == null || placeSide == null) {
            if (!airPlace) {
                return null;
            }
            neighbor = block;
            placeSide = strictDirections ? BlockUtils2.getStrictSide(block) : BlockUtils2.getClosestDirection(block, false);
            if (placeSide == null) {
                return null;
            }
        }
        class_243 eyesPos = PlayerUtils2.eyePos((class_1657)MeteorClient.mc.field_1724);
        class_243 vec = new class_243(class_3532.method_15350((double)eyesPos.field_1352, (double)neighbor.method_10263(), (double)(neighbor.method_10263() + 1)), class_3532.method_15350((double)eyesPos.field_1351, (double)neighbor.method_10264(), (double)(neighbor.method_10264() + 1)), class_3532.method_15350((double)eyesPos.field_1350, (double)neighbor.method_10260(), (double)(neighbor.method_10260() + 1)));
        return new class_3965(vec, placeSide, neighbor, false);
    }

    public static boolean placeNot(class_2338 pos, double minDamage, class_2680 placeState) {
        class_265 shape = placeState.method_26194((class_1922)MeteorClient.mc.field_1687, pos, class_3726.method_16194());
        return !MeteorClient.mc.field_1687.method_8333(null, shape.method_1110() ? new class_238(pos) : shape.method_1107().method_996(pos), entity -> entity.method_5863() && (minDamage == 0.0 || !(entity instanceof class_1511) || (double)DamageCalcUtils.explosionDamage((class_1309)MeteorClient.mc.field_1724, (class_243)entity.method_19538(), (int)6) < minDamage)).isEmpty();
    }

    public static boolean invalidPos(class_2338 pos) {
        if (pos == null) {
            return true;
        }
        return MeteorClient.mc.field_1687.method_31601(pos.method_10264()) || !MeteorClient.mc.field_1687.method_8621().method_11952(pos);
    }

    public static class_243 getCenterPos(boolean hardSnap) {
        double x = MeteorClient.mc.field_1724.method_23317() - (double)MeteorClient.mc.field_1724.method_31477();
        double z = MeteorClient.mc.field_1724.method_23321() - (double)MeteorClient.mc.field_1724.method_31479();
        if (hardSnap) {
            x = 0.5;
            z = 0.5;
        } else {
            x = class_3532.method_15350((double)x, (double)0.31, (double)0.69);
            z = class_3532.method_15350((double)z, (double)0.31, (double)0.69);
        }
        return new class_243((double)MeteorClient.mc.field_1724.method_31477() + x, MeteorClient.mc.field_1724.method_23318(), (double)MeteorClient.mc.field_1724.method_31479() + z);
    }

    public static void centerPlayer(boolean hardSnap) {
        MeteorClient.mc.field_1724.method_33574(BlockUtils2.getCenterPos(hardSnap));
    }

    public static Set<class_2338> getCity(class_1309 player, boolean down, boolean check) {
        class_238 box = player.method_5829().method_1002(0.01, 0.01, 0.01);
        class_2338 playerBlockPos = player.method_24515();
        HashSet<class_2338> cityBlocks = new HashSet<class_2338>();
        class_2338 minMin = playerBlockPos.method_10080(box.field_1323 - (double)playerBlockPos.method_10263(), 0.0, box.field_1321 - (double)playerBlockPos.method_10260());
        if (!check || MeteorClient.mc.field_1687.method_8320(minMin).method_26204().method_36555() >= 0.0f) {
            cityBlocks.add(minMin.method_10081(class_2350.field_11039.method_10163()));
            cityBlocks.add(minMin.method_10081(class_2350.field_11043.method_10163()));
            if (down) {
                cityBlocks.add(minMin.method_10081(class_2350.field_11033.method_10163()));
            }
        }
        class_2338 minMax = playerBlockPos.method_10080(box.field_1323 - (double)playerBlockPos.method_10263(), 0.0, box.field_1324 - (double)playerBlockPos.method_10260());
        if (!check || MeteorClient.mc.field_1687.method_8320(minMax).method_26204().method_36555() >= 0.0f) {
            cityBlocks.add(minMax.method_10081(class_2350.field_11039.method_10163()));
            cityBlocks.add(minMax.method_10081(class_2350.field_11035.method_10163()));
            if (down) {
                cityBlocks.add(minMax.method_10081(class_2350.field_11033.method_10163()));
            }
        }
        class_2338 maxMin = playerBlockPos.method_10080(box.field_1320 - (double)playerBlockPos.method_10263(), 0.0, box.field_1321 - (double)playerBlockPos.method_10260());
        if (!check || MeteorClient.mc.field_1687.method_8320(maxMin).method_26204().method_36555() >= 0.0f) {
            cityBlocks.add(maxMin.method_10081(class_2350.field_11034.method_10163()));
            cityBlocks.add(maxMin.method_10081(class_2350.field_11043.method_10163()));
            if (down) {
                cityBlocks.add(maxMin.method_10081(class_2350.field_11033.method_10163()));
            }
        }
        class_2338 maxMax = playerBlockPos.method_10080(box.field_1320 - (double)playerBlockPos.method_10263(), 0.0, box.field_1324 - (double)playerBlockPos.method_10260());
        if (!check || MeteorClient.mc.field_1687.method_8320(maxMax).method_26204().method_36555() >= 0.0f) {
            cityBlocks.add(maxMax.method_10081(class_2350.field_11034.method_10163()));
            cityBlocks.add(maxMax.method_10081(class_2350.field_11035.method_10163()));
            if (down) {
                cityBlocks.add(maxMax.method_10081(class_2350.field_11033.method_10163()));
            }
        }
        return cityBlocks;
    }

    @Nullable
    public static class_3545<class_2338, class_2350> getStrictNeighbour(class_2338 pos) {
        class_2338 bestNeighbour = null;
        class_2350 bestDirection = null;
        double bestDistance = 420.0;
        class_243 eyePos = PlayerUtils2.eyePos((class_1657)MeteorClient.mc.field_1724);
        int playerEyeY = (int)Math.floor(eyePos.field_1351);
        for (class_2350 direction : class_2350.values()) {
            double distance;
            class_2338 neighbour = pos.method_10093(direction);
            if (MeteorClient.mc.field_1687.method_8320(neighbour).method_26207().method_15800() && !Statistics.get().pendingObsidian.containsKey(neighbour)) continue;
            class_2350 opposite = direction.method_10153();
            if (!AntiCheatHelper.isInteractableStrict((int)MeteorClient.mc.field_1724.method_31477(), (int)playerEyeY, (int)MeteorClient.mc.field_1724.method_31479(), (class_2338)neighbour, (class_2350)opposite) || !((distance = eyePos.method_1025(BlockUtils2.sideVec(neighbour, opposite))) < bestDistance)) continue;
            bestNeighbour = neighbour;
            bestDirection = opposite;
            bestDistance = distance;
        }
        if (bestNeighbour != null) {
            return new class_3545(bestNeighbour, bestDirection);
        }
        return null;
    }

    @Nullable
    public static class_2350 getStrictSide(class_2338 pos) {
        class_2350 bestDirection = null;
        double bestDistance = 420.0;
        class_243 eyePos = PlayerUtils2.eyePos((class_1657)MeteorClient.mc.field_1724);
        int playerEyeY = (int)Math.floor(eyePos.field_1351);
        for (class_2350 direction : class_2350.values()) {
            if (!AntiCheatHelper.isInteractableStrict((int)MeteorClient.mc.field_1724.method_31477(), (int)playerEyeY, (int)MeteorClient.mc.field_1724.method_31479(), (class_2338)pos, (class_2350)direction)) continue;
            if (direction == class_2350.field_11033) {
                return direction;
            }
            double distance = eyePos.method_1025(BlockUtils2.sideVec(pos, direction));
            if (!(distance < bestDistance)) continue;
            bestDirection = direction;
            bestDistance = distance;
        }
        return bestDirection;
    }

    public static class_243 sideVec(class_2338 pos, class_2350 direction) {
        return class_243.method_24953((class_2382)pos).method_1031((double)direction.method_10148() * 0.5, (double)direction.method_10164() * 0.5, (double)direction.method_10165() * 0.5);
    }

    public static class_2350 getClosestDirection(class_2338 pos, boolean withSupport) {
        class_2350 bestDirection = null;
        double bestDistance = 69.0;
        for (class_2350 direction : class_2350.values()) {
            class_2338 neighbour = pos.method_10093(direction);
            if (withSupport && MeteorClient.mc.field_1687.method_8320(neighbour).method_26207().method_15800() && !Statistics.get().pendingObsidian.containsKey(neighbour)) continue;
            if (direction == class_2350.field_11033) {
                return direction;
            }
            double distance = PlayerUtils2.eyePos((class_1657)MeteorClient.mc.field_1724).method_1022(BlockUtils2.sideVec(pos, direction));
            if (!(distance < bestDistance)) continue;
            bestDistance = distance;
            bestDirection = direction;
        }
        return bestDirection;
    }

    public static boolean noSupport(class_2338 pos) {
        for (class_2350 side : class_2350.values()) {
            class_2338 neighbor = pos.method_10093(side);
            if (MeteorClient.mc.field_1687.method_8320(neighbor).method_26207().method_15800()) continue;
            return false;
        }
        return true;
    }

    public static boolean clickableBlock(class_2680 state, class_3965 hit, class_1268 hand) {
        return state.method_26174((class_1937)MeteorClient.mc.field_1687, (class_1657)MeteorClient.mc.field_1724, hand, hit) != class_1269.field_5811;
    }
}

