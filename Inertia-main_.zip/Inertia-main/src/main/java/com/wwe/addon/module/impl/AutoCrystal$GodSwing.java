/*
 * Decompiled with CFR 0.152.
 */
package com.wwe.addon.module.impl;

public enum AutoCrystal$GodSwing {
    None,
    Normal,
    Strict;

}

