/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Streams
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.renderer.ShapeMode
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.ColorSetting$Builder
 *  meteordevelopment.meteorclient.settings.EnumSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1297
 *  net.minecraft.class_2338$class_2339
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2829
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 */
package com.wwe.addon.module.impl;

import com.google.common.collect.Streams;
import com.wwe.addon.complements.click.TPUtils;
import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.util.ArrayList;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3959;

public class ClickTp
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRender;
    private final Setting<Mode> mode;
    private final Setting<Integer> maxDistance;
    private final Setting<Boolean> onlyIfSneaking;
    private final Setting<Boolean> preventWrongMoves;
    private final Setting<Boolean> showBlock;
    private final Setting<SettingColor> blockColor;
    private final Setting<SettingColor> wrongBlockColor;
    private final Setting<Boolean> showTrail;
    private final Setting<SettingColor> trailColor;
    private final Setting<Boolean> showSteps;
    private final Setting<SettingColor> stepColor;
    private final Setting<Integer> renderTime;
    private boolean cancel;
    private long lastTP;
    private final ArrayList<class_243> positions;
    private final class_2338.class_2339 blockPos;
    private boolean wrongMove;

    public ClickTp() {
        super(inertia.inertia, "ClickTp", "Teleports you to the block you click on.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("render");
        this.mode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("mode")).description("The mode of the teleportation.")).defaultValue((Object)Mode.Paper)).build());
        this.maxDistance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("max-distance")).description("The maximum distance you can teleport.")).defaultValue((Object)100)).min(0).sliderRange(3, 200).build());
        this.onlyIfSneaking = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("only-if-sneaking")).description("Only teleport if you are sneaking.")).defaultValue((Object)true)).build());
        this.preventWrongMoves = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("prevent-wrong-moves")).description("Tries to prevent teleports that would rollback.")).defaultValue((Object)true)).visible(() -> this.mode.get() != Mode.Pathfinder)).build());
        this.showBlock = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-block")).description("Shows the trail of your teleportation.")).defaultValue((Object)true)).build());
        this.blockColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("block-color")).description("The color of the block highlight.")).defaultValue(new SettingColor(0, 255, 255, 255)).visible(() -> this.showBlock.get())).build());
        this.wrongBlockColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("wrong-block-color")).description("The color of the block highlight if the move is wrong.")).defaultValue(new SettingColor(255, 0, 0, 255)).visible(() -> (Boolean)this.showBlock.get() != false && this.preventWrongMoves.isVisible() && (Boolean)this.preventWrongMoves.get() != false)).build());
        this.showTrail = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-trail")).description("Shows the trail of your teleportation.")).defaultValue((Object)true)).build());
        this.trailColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("trail-color")).description("The color of the block highlight.")).defaultValue(new SettingColor(255, 255, 255, 255)).visible(() -> this.showTrail.get())).build());
        this.showSteps = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-steps")).description("Shows the trail of your teleportation.")).defaultValue((Object)true)).build());
        this.stepColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("box-color")).description("The color of the block highlight.")).defaultValue(new SettingColor(255, 156, 0, 96)).visible(() -> this.showSteps.get())).build());
        this.renderTime = this.sgRender.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("trail-render-time")).description("The time in seconds the trail is rendered.")).defaultValue((Object)3)).sliderRange(0, 10).build());
        this.positions = new ArrayList();
        this.blockPos = new class_2338.class_2339();
        this.wrongMove = true;
    }

    public void onActivate() {
        this.cancel = false;
        this.lastTP = 0L;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.mc.field_1690.field_1832.method_1434() || !((Boolean)this.onlyIfSneaking.get()).booleanValue()) {
            class_3959 context = new class_3959(this.mc.field_1724.method_33571(), this.mc.field_1724.method_33571().method_1019(this.mc.field_1724.method_5720().method_1021((double)((Integer)this.maxDistance.get()).intValue())), class_3959.class_3960.field_17558, class_3959.class_242.field_1347, (class_1297)this.mc.field_1724);
            this.blockPos.method_10101((class_2382)this.mc.field_1687.method_17742(context).method_17777());
            class_238 box = this.mc.field_1724.method_5829().method_997(this.mc.field_1724.method_19538().method_22882()).method_989(0.0, 1.0, 0.0);
            while (!Streams.stream((Iterable)this.mc.field_1687.method_20812((class_1297)this.mc.field_1724, box.method_997(class_243.method_24955((class_2382)this.blockPos)))).toList().isEmpty()) {
                this.blockPos.method_10101((class_2382)this.blockPos.method_10084());
            }
            class_243 tpPos = class_243.method_24955((class_2382)this.blockPos).method_1031(0.0, 1.0, 0.0);
            class_243 tpVec = tpPos.method_1020(this.mc.field_1724.method_19538());
            this.wrongMove = false;
            if (this.mode.get() == Mode.Paper) {
                this.wrongMove = this.mc.field_1724.method_19538().method_1025(tpPos) > 40000.0 || TPUtils.isWrongMove(this.mc.field_1724.method_19538(), tpPos);
            } else if (this.mode.get() == Mode.Straight) {
                class_243 tempPos = this.mc.field_1724.method_19538();
                int i = 10;
                while ((double)i < tpVec.method_1033()) {
                    class_243 tempPos2 = tempPos.method_1019(tpVec.method_1029().method_1021(10.0));
                    if (!TPUtils.isTPValid(tempPos, tempPos2)) {
                        this.wrongMove = true;
                        break;
                    }
                    i += 10;
                }
            }
            if (this.mode.get() != Mode.Pathfinder && ((Boolean)this.preventWrongMoves.get()).booleanValue() && this.wrongMove) {
                return;
            }
            if (this.mc.field_1690.field_1904.method_1434() && !this.cancel) {
                this.positions.clear();
                this.positions.add(this.mc.field_1724.method_19538());
                switch (((Mode)((Object)this.mode.get())).ordinal()) {
                    case 0: {
                        TPUtils.PaperTP(tpPos);
                        this.positions.add(tpPos);
                        break;
                    }
                    case 1: {
                        int i = 10;
                        while ((double)i < tpVec.method_1033()) {
                            class_243 vec = this.mc.field_1724.method_19538().method_1019(tpVec.method_1029().method_1021((double)i));
                            this.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(vec.field_1352, vec.field_1351, vec.field_1350, true, this.mc.field_1724.field_5976));
                            this.positions.add(vec);
                            i += 10;
                        }
                        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(tpPos.field_1352, tpPos.field_1351, tpPos.field_1350, true, this.mc.field_1724.field_5976));
                        this.positions.add(tpPos);
                        break;
                    }
                    case 2: {
                        ArrayList<class_243> steps = TPUtils.findTPPath(this.mc.field_1724.method_19538(), tpPos, 20, 0.0, 9.0);
                        if (steps == null) break;
                        this.positions.addAll(steps);
                        for (class_243 vec : steps) {
                            this.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(vec.field_1352, vec.field_1351, vec.field_1350, true, this.mc.field_1724.field_5976));
                        }
                        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(tpPos.field_1352, tpPos.field_1351, tpPos.field_1350, true, this.mc.field_1724.field_5976));
                    }
                }
                this.mc.field_1724.method_30634(tpPos.field_1352, tpPos.field_1351, tpPos.field_1350);
                this.mc.field_1724.method_18800(0.0, 0.0, 0.0);
                this.cancel = true;
                this.lastTP = System.currentTimeMillis();
            }
        }
        if (!this.mc.field_1690.field_1904.method_1434()) {
            this.cancel = false;
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if ((this.mc.field_1690.field_1832.method_1434() || !((Boolean)this.onlyIfSneaking.get()).booleanValue()) && ((Boolean)this.showBlock.get()).booleanValue()) {
            Color color = this.mode.get() != Mode.Pathfinder && this.wrongMove && (Boolean)this.preventWrongMoves.get() != false ? (Color)this.wrongBlockColor.get() : (Color)this.blockColor.get();
            double x1 = this.blockPos.method_10263();
            double x2 = this.blockPos.method_10263() + 1;
            double y = this.blockPos.method_10264() + 1;
            double z1 = this.blockPos.method_10260();
            double z2 = this.blockPos.method_10260() + 1;
            event.renderer.line(x1, y, z1, x2, y, z1, color);
            event.renderer.line(x2, y, z1, x2, y, z2, color);
            event.renderer.line(x2, y, z2, x1, y, z2, color);
            event.renderer.line(x1, y, z2, x1, y, z1, color);
        }
        if (this.lastTP + (long)((Integer)this.renderTime.get() * 1000) < System.currentTimeMillis()) {
            return;
        }
        if (((Boolean)this.showTrail.get()).booleanValue()) {
            for (int i = 0; i < this.positions.size() - 1; ++i) {
                class_243 p1 = this.positions.get(i);
                class_243 p2 = this.positions.get(i + 1);
                event.renderer.line(p1.field_1352, p1.field_1351, p1.field_1350, p2.field_1352, p2.field_1351, p2.field_1350, (Color)this.trailColor.get());
            }
        }
        if (((Boolean)this.showSteps.get()).booleanValue()) {
            for (class_243 vec : this.positions) {
                event.renderer.box(vec.field_1352 - 0.375, vec.field_1351, vec.field_1350 - 0.375, vec.field_1352 + 0.375, vec.field_1351 + 2.0, vec.field_1350 + 0.375, (Color)this.stepColor.get(), (Color)this.stepColor.get(), ShapeMode.Sides, 0);
            }
        }
    }

    public static enum Mode {
        Paper,
        Straight,
        Pathfinder;

    }
}

