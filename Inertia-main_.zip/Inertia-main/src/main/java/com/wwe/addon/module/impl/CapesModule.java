/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.settings.EnumSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.orbit.EventHandler
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.orbit.EventHandler;

public class CapesModule
extends AddonModule {
    public static String capeed;
    private final SettingGroup sgGeneral1;
    public final Setting<Mode> modee;

    public CapesModule() {
        super(inertia.inertia, "capes", "Just pick any cape (you need to rejoin)");
        this.sgGeneral1 = this.settings.getDefaultGroup();
        this.modee = this.sgGeneral1.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("mode")).description("Decide from packet or client sided rotation.")).defaultValue((Object)Mode.Aetheric)).build());
    }

    @EventHandler
    public void onActivate() {
        Mode selectedMode = (Mode)((Object)this.modee.get());
        switch (selectedMode.ordinal()) {
            case 0: {
                capeed = "aetheric";
                break;
            }
            case 1: {
                capeed = "avo";
                break;
            }
            case 2: {
                capeed = "anime1";
                break;
            }
            case 3: {
                capeed = "anime2";
                break;
            }
            case 4: {
                capeed = "anime3";
                break;
            }
            case 5: {
                capeed = "anime4";
                break;
            }
            case 8: {
                capeed = "feather";
                break;
            }
            case 10: {
                capeed = "hacker";
                break;
            }
            case 9: {
                capeed = "vapev";
                break;
            }
            case 11: {
                capeed = "anarchy";
                break;
            }
            case 6: {
                capeed = "clow";
                break;
            }
            case 7: {
                capeed = "dev";
                break;
            }
            case 12: {
                capeed = "2011";
                break;
            }
            case 13: {
                capeed = "2012";
                break;
            }
            case 14: {
                capeed = "2013";
                break;
            }
            case 15: {
                capeed = "2015";
                break;
            }
            case 16: {
                capeed = "2016";
                break;
            }
            default: {
                capeed = "anime2";
            }
        }
    }

    @EventHandler
    public void onDeactivate() {
        capeed = null;
    }

    public static enum Mode {
        Aetheric("Aetheric"),
        Avo("AVO"),
        Anime1("Anime1"),
        Anime2("Anime2"),
        Anime3("Anime3"),
        Anime4("Anime4"),
        Clown("Clown"),
        Developer("DEV"),
        Feather("Feather"),
        VapeV4("VapeV4"),
        hacker("Hacker"),
        Anarchy("Anarchy"),
        Minecon2011("2011"),
        Minecon2012("2012"),
        Minecon2013("2013"),
        Minecon2015("2015"),
        Minecon2016("2016");

        private final String title;

        private Mode(String title) {
            this.title = title;
        }

        public String toString() {
            return this.title;
        }
    }
}

