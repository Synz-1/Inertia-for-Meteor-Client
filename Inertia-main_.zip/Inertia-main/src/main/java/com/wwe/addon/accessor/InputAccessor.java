/*
 * Decompiled with CFR 0.152.
 */
package com.wwe.addon.accessor;

public interface InputAccessor {
    default public float getMovementForward() {
        return 0.0f;
    }

    default public void setMovementForward(float value) {
    }

    default public float getMovementSideways() {
        return 0.0f;
    }

    default public void setMovementSideways(float value) {
    }
}

