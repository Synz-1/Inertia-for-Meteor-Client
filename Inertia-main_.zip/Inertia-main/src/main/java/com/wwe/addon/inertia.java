/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.addons.MeteorAddon
 *  meteordevelopment.meteorclient.gui.GuiTheme
 *  meteordevelopment.meteorclient.gui.GuiThemes
 *  meteordevelopment.meteorclient.systems.modules.Category
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.systems.modules.Modules
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1935
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.wwe.addon;

import com.wwe.addon.module.impl.AnchorTP;
import com.wwe.addon.module.impl.ArrowPopp;
import com.wwe.addon.module.impl.AutoCrystal;
import com.wwe.addon.module.impl.AutoLogin;
import com.wwe.addon.module.impl.AutoPilot;
import com.wwe.addon.module.impl.AutoVclip;
import com.wwe.addon.module.impl.BlockIn;
import com.wwe.addon.module.impl.BowPopp;
import com.wwe.addon.module.impl.CapesModule;
import com.wwe.addon.module.impl.ClickTp;
import com.wwe.addon.module.impl.Detector;
import com.wwe.addon.module.impl.DonkeyRider;
import com.wwe.addon.module.impl.FeetPlace;
import com.wwe.addon.module.impl.HitBoxDesync;
import com.wwe.addon.module.impl.ItemFrameDupe;
import com.wwe.addon.module.impl.LlamaDupe2bfr;
import com.wwe.addon.module.impl.NoSwing;
import com.wwe.addon.module.impl.PacketMine;
import com.wwe.addon.module.impl.PacketPlace;
import com.wwe.addon.module.impl.PlayerTp;
import com.wwe.addon.module.impl.PlayerTpBelowRemake;
import com.wwe.addon.utilities.InertiaTheme;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class inertia
extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger(inertia.class);
    public static final Category inertia = new Category("inertia", new class_1799((class_1935)class_1802.field_27063));
    public static Color WWE_COLOR = new SettingColor(90, 0, 150, 255);

    public void onInitialize() {
        GuiThemes.add((GuiTheme)new InertiaTheme());
        LOG.info("Analyzing W for Meteor");
        LOG.info("Starting");
        Modules.get().add((Module)new AnchorTP());
        Modules.get().add((Module)new ArrowPopp());
        Modules.get().add((Module)new AutoCrystal());
        Modules.get().add((Module)new AutoLogin());
        Modules.get().add((Module)new AutoPilot());
        Modules.get().add((Module)new AutoVclip());
        Modules.get().add((Module)new BlockIn());
        Modules.get().add((Module)new BowPopp());
        Modules.get().add((Module)new CapesModule());
        Modules.get().add((Module)new ClickTp());
        Modules.get().add((Module)new Detector());
        Modules.get().add((Module)new DonkeyRider());
        Modules.get().add((Module)new FeetPlace());
        Modules.get().add((Module)new HitBoxDesync());
        Modules.get().add((Module)new ItemFrameDupe());
        Modules.get().add((Module)new LlamaDupe2bfr());
        Modules.get().add((Module)new NoSwing());
        Modules.get().add((Module)new PacketMine());
        Modules.get().add((Module)new PacketPlace());
        Modules.get().add((Module)new PlayerTp());
        Modules.get().add((Module)new PlayerTpBelowRemake());
    }

    public void onRegisterCategories() {
        Modules.registerCategory((Category)inertia);
    }

    public String getPackage() {
        return "com.wwe.addon";
    }
}

