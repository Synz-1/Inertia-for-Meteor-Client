package com.wwe.addon.complements.mine; public enum SwitchMode { NONE, SILENT, AUTO }
