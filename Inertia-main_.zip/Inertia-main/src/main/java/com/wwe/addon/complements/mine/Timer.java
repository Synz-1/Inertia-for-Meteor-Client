package com.wwe.addon.complements.mine;
public class Timer { private long time=System.currentTimeMillis(); public void reset(){time=System.currentTimeMillis();} public long millisPassed(){return System.currentTimeMillis()-time;} public boolean passedMillis(long ms){return millisPassed()>=ms;} public void setMs(long ms){time=System.currentTimeMillis()-ms;} }
