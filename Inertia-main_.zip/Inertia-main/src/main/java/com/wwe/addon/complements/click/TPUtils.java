/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.MeteorClient
 *  net.minecraft.class_10185
 *  net.minecraft.class_1297
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_265
 *  net.minecraft.class_2828$class_2829
 *  net.minecraft.class_2828$class_5911
 *  net.minecraft.class_2851
 */
package com.wwe.addon.complements.click;

import com.wwe.addon.complements.click.ServerUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_10185;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2828;
import net.minecraft.class_2851;

public class TPUtils {
    public static final double movedWronglyThreshold = 0.0625;

    public static void PaperTP(class_243 startPos, class_243 pos) {
        if (false) {
            class_10185 lastInput = MeteorClient.mc.field_1724.method_71091();
            class_10185 input = new class_10185(lastInput.comp_3159(), lastInput.comp_3160(), lastInput.comp_3161(), lastInput.comp_3162(), lastInput.comp_3163(), false, lastInput.comp_3165());
            MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2851(input));
        }
        double distance = startPos.method_1022(pos);
        int packetsRequired = (int)Math.ceil(Math.abs(distance / 10.0));
        for (int packetNumber = 0; packetNumber < packetsRequired - 1; ++packetNumber) {
            MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true, MeteorClient.mc.field_1724.field_5976));
        }
        MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, true, MeteorClient.mc.field_1724.field_5976));
    }

    public static void PaperTP(class_243 pos) {
        TPUtils.PaperTP(MeteorClient.mc.field_1724.method_19538(), pos);
    }

    public static class_2338 Vec3d2BlockPos(class_243 pos) {
        return new class_2338((int)Math.floor(pos.field_1352), (int)Math.floor(pos.field_1351), (int)Math.floor(pos.field_1350));
    }

    public static ArrayList<class_243> findTPPath(class_243 pos, double maxDistance) {
        return TPUtils.findTPPath(MeteorClient.mc.field_1724.method_19538(), pos, 10, maxDistance, 8.0);
    }

    public static ArrayList<class_243> findTPPath(class_243 startPos, class_243 newPos, int maxSteps, double maxDistance, double accuracy) {
        double maxSquaredDistance = maxDistance * maxDistance;
        ArrayList directions = new ArrayList(Arrays.stream(class_2350.values()).toList());
        directions.sort((d1, d2) -> {
            double d1Dist = newPos.method_1022(startPos.method_43206(d1, 10.0));
            double d2Dist = newPos.method_1022(startPos.method_43206(d2, 10.0));
            return Double.compare(d1Dist, d2Dist);
        });
        ArrayList<class_243> positions = new ArrayList<class_243>();
        for (int h = 0; h < maxSteps; ++h) {
            class_243 potentialPos;
            double closestPosSquaredDistance = positions.isEmpty() ? 2.147483647E9 : ((class_243)positions.getLast()).method_1025(newPos) + 100.0;
            class_243 currentPos = positions.isEmpty() ? startPos : (class_243)positions.getLast();
            double currentPosDistance = currentPos.method_1022(newPos);
            class_243 roundCurrentPos = new class_243(Math.floor(currentPos.field_1352) + 0.5, Math.floor(currentPos.field_1351), Math.floor(currentPos.field_1350) + 0.5);
            class_243 closestPos = null;
            if (currentPos.method_1025(newPos) <= 100.0) {
                potentialPos = newPos;
            } else {
                potentialPos = currentPos.method_1019(newPos.method_1020(currentPos).method_1029().method_1021(10.0));
                if (positions.contains(potentialPos)) {
                    return null;
                }
            }
            if (TPUtils.isTPValid(currentPos, potentialPos)) {
                positions.add(potentialPos);
                if (!(potentialPos.method_1025(newPos) <= maxSquaredDistance)) continue;
                return positions;
            }
            block1: for (int i = 10; i >= -10; --i) {
                int maxJ;
                for (int j = maxJ = (int)Math.sqrt(100 - i * i); j >= -maxJ; --j) {
                    int maxK;
                    for (int k = maxK = (int)Math.sqrt(100 - i * i - j * j); k >= -maxK; --k) {
                        potentialPos = roundCurrentPos.method_43206((class_2350)directions.get(0), (double)i).method_43206((class_2350)directions.get(1), (double)j).method_43206((class_2350)directions.get(2), (double)k);
                        double potentialPosSquaredDistance = potentialPos.method_1025(newPos);
                        if (!(potentialPosSquaredDistance < closestPosSquaredDistance) || !TPUtils.isTPValid(currentPos, potentialPos)) continue;
                        if (potentialPosSquaredDistance <= maxSquaredDistance) {
                            positions.add(potentialPos);
                            return positions;
                        }
                        closestPos = potentialPos;
                        closestPosSquaredDistance = potentialPosSquaredDistance;
                        if (currentPosDistance - Math.sqrt(closestPosSquaredDistance) > accuracy) break block1;
                    }
                }
            }
            if (closestPos != null && !positions.contains(closestPos) && !(closestPosSquaredDistance > 10.0 * Math.pow(maxSteps - h, 2.0 + maxDistance))) {
                positions.add(closestPos);
                continue;
            }
            return null;
        }
        return positions;
    }

    public static boolean isObstructed(class_243 pos) {
        class_238 box = MeteorClient.mc.field_1724.method_5829().method_997(MeteorClient.mc.field_1724.method_19538().method_22882()).method_997(pos);
        Iterator iterator = MeteorClient.mc.field_1687.method_20812((class_1297)MeteorClient.mc.field_1724, box = box.method_1009(-1.0E-4, -1.0E-4, -1.0E-4)).iterator();
        if (iterator.hasNext()) {
            class_265 v = (class_265)iterator.next();
            return true;
        }
        return false;
    }

    public static boolean isTPValid(class_243 startPos, class_243 endPos) {
        return startPos.method_1025(endPos) < 100.0000000000001 && !TPUtils.isObstructed(endPos) && !TPUtils.isWrongMove(startPos, endPos);
    }

    public static boolean isWrongMove(class_243 startPos, class_243 endPos) {
        return ServerUtils.getSquaredMovementDelta(startPos, endPos) > 0.0625;
    }
}

