package com.wwe.addon.complements.mine; public enum SwapMode { OLD, NEW }
