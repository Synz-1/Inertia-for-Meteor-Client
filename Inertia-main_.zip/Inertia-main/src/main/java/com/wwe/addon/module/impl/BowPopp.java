/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Send
 *  meteordevelopment.meteorclient.events.world.TickEvent$Post
 *  meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.EntityTypeListSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.ItemListSetting
 *  meteordevelopment.meteorclient.settings.ItemListSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.friends.Friends
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.systems.modules.Modules
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1657
 *  net.minecraft.class_1753
 *  net.minecraft.class_1771
 *  net.minecraft.class_1776
 *  net.minecraft.class_1779
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_1803
 *  net.minecraft.class_1823
 *  net.minecraft.class_1828
 *  net.minecraft.class_1835
 *  net.minecraft.class_1922
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2374
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2829
 *  net.minecraft.class_2828$class_5911
 *  net.minecraft.class_2833
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_2886
 *  net.minecraft.class_746
 *  net.minecraft.class_9239
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.complements.bow.BowHelper;
import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1803;
import net.minecraft.class_1823;
import net.minecraft.class_1828;
import net.minecraft.class_1835;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2833;
import net.minecraft.class_2846;
import net.minecraft.class_2886;
import net.minecraft.class_746;
import net.minecraft.class_9239;

public class BowPopp
extends AddonModule {
    private boolean paction = false;
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final SettingGroup sgTargeting = this.settings.createGroup("Targeting");
    private final ItemListSetting projectileItems = (ItemListSetting)this.sgGeneral.add((Setting)((ItemListSetting.Builder)((ItemListSetting.Builder)new ItemListSetting.Builder().name("projectile-items")).description("Which items to apply extra velocity to.")).defaultValue(new class_1792[]{class_1802.field_8634, class_1802.field_8436, class_1802.field_8150, class_1802.field_8287, class_1802.field_8543, class_1802.field_8803, class_1802.field_49098, class_1802.field_8102, class_1802.field_8547}).filter(item -> item == class_1802.field_8634 || item == class_1802.field_8436 || item == class_1802.field_8150 || item == class_1802.field_8287 || item == class_1802.field_8543 || item == class_1802.field_8803 || item == class_1802.field_49098 || item == class_1802.field_8102 || item == class_1802.field_8547).build());
    private final Setting<Integer> interactAmount = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("interact-amount")).defaultValue((Object)1)).min(0).sliderMax(15).build());
    private final Setting<Integer> prePackets = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("# spam packets")).defaultValue((Object)5)).min(0).sliderMax(100).build());
    private final Setting<Double> teleportHeight = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("teleport-height")).description("Teleport you up to this high for increased velocity for projectiles.")).defaultValue(60.0).min(5.0).sliderMax(130.0).build());
    private final Setting<Double> maxDistance = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("max-distance")).description("Teleport you up to this far to targets.")).defaultValue(80.0).min(5.0).sliderMax(120.0).build());
    private final Setting<Double> targetoffset = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("Above target offset")).description("Offset you this much above the target.")).defaultValue(0.01).min(0.0).sliderMax(10.0).build());
    private final Setting<Double> offsethorizontal = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("Horizontal Offset")).description("Offset you this much from the start position.")).defaultValue(0.05).min(0.0).sliderMax(0.99).build());
    private final Setting<Double> offsetY = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("Y Offset")).description("Offset you this much from the start position.")).defaultValue(0.001).min(0.0).sliderMax(0.99).build());
    private final Setting<Boolean> skipCollisionCheck = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("BoatNoclip skip collision check")).description("If BoatNoclip is on and you are in a boat skip collision checks for blocks.")).defaultValue((Object)true)).build());
    private final Setting<Set<class_1299<?>>> entities = this.sgTargeting.add((Setting)((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("entities")).description("Entities to target.")).onlyAttackable().defaultValue(new class_1299[]{class_1299.field_6097}).build());
    public final Setting<Boolean> friends = this.sgTargeting.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("Attack Friends")).defaultValue((Object)false)).build());
    private final SettingGroup sgArrowFire = this.settings.createGroup("Arrow Fire");
    private final Setting<Boolean> arrowFire = this.sgArrowFire.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("Bow Machinegun")).description("Automatically fires arrows while holding bow.")).defaultValue((Object)true)).build());
    private final Setting<Integer> chargeTicks = this.sgArrowFire.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("charge-ticks")).description("Ticks to charge bow before firing.")).defaultValue((Object)4)).min(4).sliderRange(4, 60).visible(() -> this.arrowFire.get())).build());
    private boolean isChargingBow = false;
    private int bowChargeTimer = 0;
    private boolean wasHoldingBow = false;
    private class_1297 target = null;

    public BowPopp() {
        super(inertia.inertia, "BowPopp", "Teleport arrow at an absurd speed.");
    }

    private class_1297 findClosestTarget() {
        class_1297 closest = null;
        double closestDist = Double.MAX_VALUE;
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            double dist;
            if (!this.isValidListTarget(entity) || ((Boolean)this.friends.get()).booleanValue() && entity instanceof class_1657 && Friends.get().isFriend((class_1657)entity) || !((dist = entity.method_5858((class_1297)this.mc.field_1724)) < closestDist)) continue;
            closestDist = dist;
            closest = entity;
        }
        return closest;
    }

    private boolean isValidListTarget(class_1297 entity) {
        return ((Set)this.entities.get()).contains(entity.method_5864()) && entity.method_5805() && entity.method_5732() && !entity.method_5655() && entity != this.mc.field_1724;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        boolean holdingBow;
        this.target = this.findClosestTarget();
        if (!((Boolean)this.arrowFire.get()).booleanValue() || this.mc.field_1724 == null || this.mc.field_1761 == null) {
            return;
        }
        boolean bl = holdingBow = this.mc.field_1724.method_6047().method_7909() instanceof class_1753 || this.mc.field_1724.method_6079().method_7909() instanceof class_1753;
        if (holdingBow && !this.wasHoldingBow) {
            this.bowChargeTimer = 0;
        }
        if (this.isChargingBow && holdingBow) {
            ++this.bowChargeTimer;
            if (this.bowChargeTimer >= (Integer)this.chargeTicks.get()) {
                this.fireArrowTick();
                this.bowChargeTimer = 0;
            }
        } else {
            this.bowChargeTimer = 0;
        }
        this.wasHoldingBow = holdingBow;
    }

    private void fireArrowTick() {
        this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12974, class_2338.field_10980, class_2350.field_11033, this.mc.field_1724.method_31548().method_67532()));
    }

    @EventHandler(priority=200)
    private void onPacketSend(PacketEvent.Send event) {
        class_2596 stack;
        class_2886 packet;
        if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.method_1562() == null) {
            return;
        }
        class_2596 class_25962 = event.packet;
        if (class_25962 instanceof class_2886) {
            packet = (class_2886)class_25962;
            stack = packet.method_12551() == class_1268.field_5808 ? this.mc.field_1724.method_6047() : this.mc.field_1724.method_6079();
            class_1792 item = stack.method_7909();
            if (this.isValidProjectile(item)) {
                this.interact(packet.method_12551());
            } else if (item instanceof class_1753 && ((List)this.projectileItems.get()).contains(class_1802.field_8102)) {
                this.isChargingBow = true;
            }
        }
        if ((stack = event.packet) instanceof class_2846) {
            packet = (class_2846)stack;
            if (!this.paction) {
                if (packet.method_12363() != class_2846.class_2847.field_12974) {
                    return;
                }
                class_1792 item = this.mc.field_1724.method_6047().method_7909();
                class_1792 item2 = this.mc.field_1724.method_6079().method_7909();
                if (!this.isAction(item) && !this.isAction(item2)) {
                    return;
                }
                this.isChargingBow = false;
                event.cancel();
                this.action(packet.method_12363());
            }
        }
    }

    private boolean isValidProjectile(class_1792 item) {
        return item instanceof class_1776 && ((List)this.projectileItems.get()).contains(class_1802.field_8634) || item instanceof class_1828 && ((List)this.projectileItems.get()).contains(class_1802.field_8436) || item instanceof class_1803 && ((List)this.projectileItems.get()).contains(class_1802.field_8150) || item instanceof class_1779 && ((List)this.projectileItems.get()).contains(class_1802.field_8287) || item instanceof class_1823 && ((List)this.projectileItems.get()).contains(class_1802.field_8543) || item instanceof class_9239 && ((List)this.projectileItems.get()).contains(class_1802.field_49098) || item instanceof class_1771 && ((List)this.projectileItems.get()).contains(class_1802.field_8803);
    }

    public boolean isAction(class_1792 item) {
        return item instanceof class_1753 && ((List)this.projectileItems.get()).contains(class_1802.field_8102) || item instanceof class_1835 && ((List)this.projectileItems.get()).contains(class_1802.field_8547);
    }

    private boolean isValidTarget(class_1297 entity) {
        class_746 playerentity = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        return entity.method_5805() && (double)playerentity.method_5739(entity) <= (Double)this.maxDistance.get();
    }

    public void interact(class_1268 hand) {
        class_243 homeOffset;
        class_243 shotPos;
        class_243 aboveTarget;
        if (this.target == null || !this.isValidTarget(this.target)) {
            return;
        }
        class_746 entity = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_243 home = entity.method_19538();
        if (this.mc.field_1724.method_5858(this.target) > (Double)this.maxDistance.get() * (Double)this.maxDistance.get()) {
            return;
        }
        class_238 box = this.target.method_5829();
        double x = box.method_1005().field_1352;
        double y = box.field_1325;
        double z = box.method_1005().field_1350;
        class_243 topPos = new class_243(x, y, z);
        class_243 aboveHome = home.method_1031(0.0, ((Double)this.teleportHeight.get()).doubleValue(), 0.0);
        if (!this.validatePath(aboveHome, aboveTarget = topPos.method_1031(0.0, ((Double)this.teleportHeight.get()).doubleValue(), 0.0), shotPos = topPos.method_1031(0.0, ((Double)this.targetoffset.get()).doubleValue(), 0.0), aboveTarget, aboveHome, homeOffset = this.getOffset(home))) {
            if (this.chatFeedback) {
                this.error("One of the teleports are blocked.", new Object[0]);
            }
            return;
        }
        if (!this.hasClearPath(aboveHome, aboveTarget) && this.chatFeedback) {
            this.error("Vertical path blocked between clip positions.", new Object[0]);
        }
        for (int i = 0; i < (Integer)this.prePackets.get(); ++i) {
            if (entity == this.mc.field_1724) {
                this.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true, this.mc.field_1724.field_5976));
                continue;
            }
            this.mc.field_1724.field_3944.method_52787((class_2596)class_2833.method_65307((class_1297)entity));
        }
        this.moveTo((class_1297)entity, aboveHome);
        this.moveTo((class_1297)entity, aboveTarget);
        this.moveTo((class_1297)entity, shotPos);
        float yaw = this.mc.field_1724.method_36454();
        for (int i = 0; i < (Integer)this.interactAmount.get(); ++i) {
            this.mc.field_1724.field_3944.method_52787((class_2596)new class_2886(hand, 0, yaw, 90.0f));
        }
        this.moveTo((class_1297)entity, aboveTarget);
        this.moveTo((class_1297)entity, aboveHome);
        this.moveTo((class_1297)entity, home);
        this.moveTo((class_1297)entity, homeOffset);
        entity.method_33574(homeOffset);
    }

    public void action(class_2846.class_2847 action) {
        class_243 homeOffset;
        class_243 shotPos;
        class_243 aboveTarget;
        if (this.target == null || !this.isValidTarget(this.target)) {
            return;
        }
        class_746 entity = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_243 home = entity.method_19538();
        if (this.mc.field_1724.method_5858(this.target) > (Double)this.maxDistance.get() * (Double)this.maxDistance.get()) {
            return;
        }
        class_238 box = this.target.method_5829();
        double x = box.method_1005().field_1352;
        double y = box.field_1325;
        double z = box.method_1005().field_1350;
        class_243 topPos = new class_243(x, y, z);
        class_243 aboveHome = home.method_1031(0.0, ((Double)this.teleportHeight.get()).doubleValue(), 0.0);
        if (!this.validatePath(aboveHome, aboveTarget = topPos.method_1031(0.0, ((Double)this.teleportHeight.get()).doubleValue(), 0.0), shotPos = topPos.method_1031(0.0, ((Double)this.targetoffset.get()).doubleValue(), 0.0), aboveTarget, aboveHome, homeOffset = this.getOffset(home))) {
            if (this.chatFeedback) {
                this.error("One of the teleports are blocked.", new Object[0]);
            }
            return;
        }
        for (int i = 0; i < (Integer)this.prePackets.get(); ++i) {
            if (entity == this.mc.field_1724) {
                this.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true, this.mc.field_1724.field_5976));
                continue;
            }
            this.mc.field_1724.field_3944.method_52787((class_2596)class_2833.method_65307((class_1297)entity));
        }
        this.moveTo((class_1297)entity, aboveHome);
        this.moveTo((class_1297)entity, aboveTarget);
        this.moveTo((class_1297)entity, shotPos);
        this.paction = true;
        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(action, class_2338.field_10980, class_2350.field_11033, 0));
        this.paction = false;
        this.moveTo((class_1297)entity, aboveTarget);
        this.moveTo((class_1297)entity, aboveHome);
        this.moveTo((class_1297)entity, home);
        this.moveTo((class_1297)entity, homeOffset);
    }

    private void moveTo(class_1297 entity, class_243 pos) {
        if (entity == this.mc.field_1724) {
            class_2828.class_2829 packet = new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, false, false);
            ((IPlayerMoveC2SPacket)packet).meteor$setTag(1337);
            this.mc.field_1724.field_3944.method_52787((class_2596)packet);
        } else {
            this.mc.field_1724.field_3944.method_52787((class_2596)new class_2833(pos, entity.method_36454(), entity.method_36455(), false));
        }
        entity.method_33574(pos);
    }

    private boolean invalid(class_243 pos) {
        if (this.mc.field_1687 == null) {
            return true;
        }
        if (this.mc.field_1687.method_22350(class_2338.method_49638((class_2374)pos)) == null) {
            return true;
        }
        class_746 entity = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_238 targetBox = entity.method_5829().method_989(pos.field_1352 - entity.method_23317(), pos.field_1351 - entity.method_23318(), pos.field_1350 - entity.method_23321());
        Module boatNoclip = Modules.get().get(BowHelper.class);
        if (((Boolean)this.skipCollisionCheck.get()).booleanValue() && entity != this.mc.field_1724 && boatNoclip != null && boatNoclip.isActive()) {
            for (class_2338 bp : class_2338.method_10097((class_2338)class_2338.method_49637((double)targetBox.field_1323, (double)targetBox.field_1322, (double)targetBox.field_1321), (class_2338)class_2338.method_49637((double)targetBox.field_1320, (double)targetBox.field_1325, (double)targetBox.field_1324))) {
                state = this.mc.field_1687.method_8320(bp);
                if (!state.method_27852(class_2246.field_10164)) continue;
                return true;
            }
        } else {
            for (class_2338 bp : class_2338.method_10097((class_2338)class_2338.method_49637((double)targetBox.field_1323, (double)targetBox.field_1322, (double)targetBox.field_1321), (class_2338)class_2338.method_49637((double)targetBox.field_1320, (double)targetBox.field_1325, (double)targetBox.field_1324))) {
                state = this.mc.field_1687.method_8320(bp);
                if (!state.method_27852(class_2246.field_10164) && state.method_26220((class_1922)this.mc.field_1687, bp).method_1110()) continue;
                return true;
            }
        }
        for (class_1297 e : this.mc.field_1687.method_8335((class_1297)entity, targetBox)) {
            if (!e.method_30948()) continue;
            return true;
        }
        return false;
    }

    private boolean validatePath(class_243 ... positions) {
        for (class_243 pos : positions) {
            if (!this.invalid(pos)) continue;
            return false;
        }
        return true;
    }

    private boolean hasClearPath(class_243 start, class_243 end) {
        if (this.invalid(start) || this.invalid(end)) {
            return false;
        }
        int steps = Math.max(10, (int)(start.method_1022(end) * 2.5));
        for (int i = 1; i < steps; ++i) {
            double t = (double)i / (double)steps;
            class_243 sample = start.method_35590(end, t);
            if (!this.invalid(sample)) continue;
            return false;
        }
        return true;
    }

    private class_243 getOffset(class_243 base) {
        double dx = (Double)this.offsethorizontal.get();
        double dy = (Double)this.offsetY.get();
        class_243[] shuffledOffsets = new class_243[]{base.method_1031(dx, dy, 0.0), base.method_1031(-dx, dy, 0.0), base.method_1031(0.0, dy, dx), base.method_1031(0.0, dy, -dx), base.method_1031(dx, dy, dx), base.method_1031(-dx, dy, -dx), base.method_1031(-dx, dy, dx), base.method_1031(dx, dy, -dx)};
        Collections.shuffle(Arrays.asList(shuffledOffsets));
        for (class_243 pos : shuffledOffsets) {
            if (this.invalid(pos)) continue;
            return pos;
        }
        class_243 noHorizontal = base.method_1031(0.0, dy, 0.0);
        if (!this.invalid(noHorizontal)) {
            return noHorizontal;
        }
        return base;
    }
}

