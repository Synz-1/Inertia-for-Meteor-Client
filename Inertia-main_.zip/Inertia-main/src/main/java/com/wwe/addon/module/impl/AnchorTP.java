/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Receive
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket
 *  meteordevelopment.meteorclient.renderer.ShapeMode
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.ColorSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.EntityTypeListSetting$Builder
 *  meteordevelopment.meteorclient.settings.EnumSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.KeybindSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.friends.Friends
 *  meteordevelopment.meteorclient.utils.entity.DamageUtils
 *  meteordevelopment.meteorclient.utils.misc.Keybind
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.InvUtils
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1309
 *  net.minecraft.class_1321
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_1802
 *  net.minecraft.class_1922
 *  net.minecraft.class_1934
 *  net.minecraft.class_1937
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2350$class_2351
 *  net.minecraft.class_2374
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 *  net.minecraft.class_2708
 *  net.minecraft.class_2769
 *  net.minecraft.class_2828$class_2829
 *  net.minecraft.class_2828$class_5911
 *  net.minecraft.class_2879
 *  net.minecraft.class_2885
 *  net.minecraft.class_3726
 *  net.minecraft.class_3965
 *  net.minecraft.class_4969
 *  net.minecraft.class_640
 *  net.minecraft.class_746
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.UUID;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.entity.DamageUtils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2708;
import net.minecraft.class_2769;
import net.minecraft.class_2828;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_640;
import net.minecraft.class_746;

public class AnchorTP
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgTargets;
    private final SettingGroup sgRender;
    private static final long manualCooldown = 1L;
    private final Setting<Double> range;
    private final Setting<Double> maxStep;
    private final Setting<Integer> attackDelay;
    private final Setting<Boolean> padding;
    private final Setting<Boolean> pauseOnEat;
    private final Setting<Boolean> autoRefill;
    private final Setting<AttackMode> attackMode;
    private final Setting<Keybind> manualAttackKey;
    private long lastManualAttack;
    private final Setting<Set<class_1299<?>>> entities;
    private final Setting<SortPriority> sortPriority;
    private final Setting<Boolean> ignoreFriends;
    private final Setting<Boolean> ignoreBots;
    private final Setting<Boolean> ignoreCreative;
    private final Setting<Double> minDamage;
    private final Setting<Double> maxSelfDamage;
    private final Setting<Boolean> renderTarget;
    private final Setting<SettingColor> targetColor;
    private final Setting<Boolean> renderPath;
    private final Setting<SettingColor> pathColor;
    private final Setting<SwingMode> swingMode;
    private static final double HORIZONTAL_OFFSET = 0.0;
    private static final double Y_OFFSET = 0.0;
    private static final int PACKET_COOLDOWN = 0;
    private static final boolean IGNORE_NAMED = true;
    private static final boolean IGNORE_TAMED = true;
    private static final boolean RETURN_POS = true;
    private static final boolean S08_RETURN = true;
    private SmartTPCore core;
    private class_243 originalPos;
    private boolean pendingS08Return;
    private int tickCounter;
    private final List<class_243> renderPathNodes;
    private int delayTimer;
    private class_1297 currentTarget;
    private int packetsThisTick;
    private long lastPacketTime;
    private final Map<UUID, class_243> lastPosMap;
    private final Map<UUID, class_243> lastVelMap;

    public AnchorTP() {
        super(inertia.inertia, "Anchor", "FastPlace and Long Range.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgTargets = this.settings.createGroup("Targets");
        this.sgRender = this.settings.createGroup("Render");
        this.range = this.sgGeneral.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("range")).defaultValue(500.0).min(0.0).sliderMax(500.0).build());
        this.maxStep = this.sgGeneral.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("max-step")).defaultValue(200.0).min(1.0).sliderMax(200.0).build());
        this.attackDelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("attack-delay")).defaultValue((Object)0)).min(0).sliderMax(20).build());
        this.padding = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("padding-packets")).defaultValue((Object)true)).build());
        this.pauseOnEat = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("pause-on-eat")).defaultValue((Object)true)).build());
        this.autoRefill = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-refill")).defaultValue((Object)true)).build());
        this.attackMode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("attack-mode")).defaultValue((Object)AttackMode.Automatic)).build());
        this.manualAttackKey = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)new KeybindSetting.Builder().name("manual-key")).defaultValue((Object)Keybind.none())).visible(() -> this.attackMode.get() == AttackMode.ManualKeybind)).build());
        this.lastManualAttack = 0L;
        this.entities = this.sgTargets.add((Setting)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("entities")).defaultValue(new class_1299[]{class_1299.field_6097}).build());
        this.sortPriority = this.sgTargets.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("priority")).defaultValue((Object)SortPriority.Closest)).build());
        this.ignoreFriends = this.sgTargets.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("ignore-friends")).defaultValue((Object)false)).build());
        this.ignoreBots = this.sgTargets.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("ignore-bots")).defaultValue((Object)true)).build());
        this.ignoreCreative = this.sgTargets.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("ignore-creative")).defaultValue((Object)true)).build());
        this.minDamage = this.sgTargets.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("min-damage")).defaultValue(4.0).min(0.0).sliderMax(36.0).build());
        this.maxSelfDamage = this.sgTargets.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("max-self-damage")).defaultValue(36.0).min(0.0).sliderMax(36.0).build());
        this.renderTarget = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("render-target")).defaultValue((Object)true)).build());
        this.targetColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("target-color")).defaultValue(new SettingColor(150, 0, 0, 255)).visible(() -> this.renderTarget.get())).build());
        this.renderPath = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("render-path")).defaultValue((Object)false)).build());
        this.pathColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("path-color")).defaultValue(new SettingColor(0, 150, 0, 255)).visible(() -> this.renderPath.get())).build());
        this.swingMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("swing-mode")).defaultValue((Object)SwingMode.Client)).build());
        this.originalPos = null;
        this.pendingS08Return = false;
        this.tickCounter = 0;
        this.renderPathNodes = new ArrayList<class_243>();
        this.delayTimer = 0;
        this.currentTarget = null;
        this.packetsThisTick = 0;
        this.lastPacketTime = 0L;
        this.lastPosMap = new HashMap<UUID, class_243>();
        this.lastVelMap = new HashMap<UUID, class_243>();
    }

    public void onActivate() {
        if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
            this.core = new SmartTPCore((class_1937)this.mc.field_1687, (class_1657)this.mc.field_1724);
            this.originalPos = null;
            this.pendingS08Return = false;
            this.tickCounter = 0;
        }
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        if (event.packet instanceof class_2708 && this.core != null) {
            this.core.desyncPos = null;
            if (this.originalPos != null && this.tickCounter < 40) {
                this.pendingS08Return = true;
            }
        }
    }

    @EventHandler
    public void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        ++this.tickCounter;
        this.packetsThisTick = 0;
        if (this.pendingS08Return) {
            this.pendingS08Return = false;
            class_243 current = new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
            if (this.originalPos != null && current.method_1022(this.originalPos) > 3.0) {
                this.core.updatePathfinding(current, this.originalPos, (Double)this.maxStep.get());
                List<class_243> emergency = this.core.getEfficientPath((Double)this.maxStep.get());
                if (emergency != null && !emergency.isEmpty()) {
                    for (class_243 p : emergency) {
                        this.sendTPPacket(p);
                    }
                    this.sendTPPacket(this.originalPos);
                    this.mc.field_1724.method_30634(this.originalPos.field_1352, this.originalPos.field_1351, this.originalPos.field_1350);
                    this.originalPos = null;
                }
            }
            return;
        }
        this.currentTarget = this.findTarget();
        if (this.currentTarget == null) {
            return;
        }
        if (((Boolean)this.pauseOnEat.get()).booleanValue() && this.mc.field_1724.method_6115()) {
            return;
        }
        if (this.delayTimer > 0) {
            --this.delayTimer;
            return;
        }
        if (this.attackMode.get() == AttackMode.ManualKeybind) {
            if (!((Keybind)this.manualAttackKey.get()).isPressed()) {
                return;
            }
            long now = System.currentTimeMillis();
            if (now - this.lastManualAttack < 1L) {
                return;
            }
            this.lastManualAttack = now;
        }
        FindItemResult anchor = InvUtils.find((class_1792[])new class_1792[]{class_1802.field_23141});
        FindItemResult glowstone = InvUtils.find((class_1792[])new class_1792[]{class_1802.field_8801});
        if (!anchor.found() || !glowstone.found()) {
            this.delayTimer = 40;
            return;
        }
        int aSlot = this.getSlot(anchor, 6);
        int gSlot = this.getSlot(glowstone, 7);
        if (aSlot == -1 || gSlot == -1) {
            return;
        }
        AttackPos info = this.findBestPos(this.currentTarget);
        if (info == null) {
            return;
        }
        this.executeTPAuraAttack(info, aSlot, gSlot);
        this.delayTimer = (Integer)this.attackDelay.get();
    }

    private void sendBlock(class_3965 hit) {
        this.mc.field_1724.field_3944.method_52787((class_2596)new class_2885(class_1268.field_5808, hit, 0));
        this.doSwing(class_1268.field_5808);
    }

    private void doSwing(class_1268 hand) {
        switch (1.$SwitchMap$com$wwe$addon$modules$AnchorTP$SwingMode[((SwingMode)((Object)this.swingMode.get())).ordinal()]) {
            case 1: {
                this.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(hand));
                break;
            }
            case 2: {
                this.mc.field_1724.method_6104(hand);
                break;
            }
        }
    }

    private class_1297 findTarget() {
        ArrayList<class_1297> candidates = new ArrayList<class_1297>();
        for (class_1297 e2 : this.mc.field_1687.method_18112()) {
            class_1321 t;
            class_1657 p;
            if (e2 == this.mc.field_1724 || !e2.method_5805() || !(e2 instanceof class_1309) || !((Set)this.entities.get()).contains(e2.method_5864()) || (double)e2.method_5739((class_1297)this.mc.field_1724) > (Double)this.range.get()) continue;
            if (((Boolean)this.ignoreFriends.get()).booleanValue() && e2 instanceof class_1657) {
                p = (class_1657)e2;
                if (Friends.get().isFriend(p)) continue;
            }
            if (e2.method_16914() || e2 instanceof class_1321 && (t = (class_1321)e2).method_6181()) continue;
            if (e2 instanceof class_1657) {
                p = (class_1657)e2;
                if (((Boolean)this.ignoreCreative.get()).booleanValue() && this.getGameMode(p) == class_1934.field_9220 || ((Boolean)this.ignoreBots.get()).booleanValue() && this.isBot(p) || !Friends.get().shouldAttack(p)) continue;
            }
            candidates.add(e2);
        }
        if (candidates.isEmpty()) {
            return null;
        }
        switch (((SortPriority)((Object)this.sortPriority.get())).ordinal()) {
            case 0: {
                candidates.sort(Comparator.comparingDouble(e -> e.method_5739((class_1297)this.mc.field_1724)));
                break;
            }
            case 1: {
                candidates.sort(Comparator.comparingDouble(e -> e.method_5739((class_1297)this.mc.field_1724)).reversed());
                break;
            }
            case 2: {
                candidates.sort(Comparator.comparingDouble(e -> ((class_1309)e).method_6032()));
                break;
            }
            case 3: {
                candidates.sort(Comparator.comparingDouble(e -> ((class_1309)e).method_6032()).reversed());
            }
        }
        return (class_1297)candidates.get(0);
    }

    private class_1934 getGameMode(class_1657 p) {
        class_640 entry = this.mc.method_1562().method_2871(p.method_5667());
        return entry == null ? class_1934.field_9215 : entry.method_2958();
    }

    private boolean isBot(class_1657 player) {
        if (this.mc.method_1562() == null) {
            return false;
        }
        return this.mc.method_1562().method_2871(player.method_5667()) == null;
    }

    private AttackPos findBestPos(class_1297 target) {
        class_243 future = this.predictFuturePos(target, 4);
        class_243 head = new class_243(future.field_1352, future.field_1351 + (double)target.method_18381(target.method_18376()), future.field_1350);
        class_2338 headPos = class_2338.method_49638((class_2374)head);
        class_2338[] candidates = new class_2338[]{headPos.method_10095(), headPos.method_10072(), headPos.method_10078(), headPos.method_10067(), headPos.method_10084(), headPos.method_10074()};
        ArrayList<AttackPos> list = new ArrayList<AttackPos>();
        for (class_2338 pos : candidates) {
            class_243 tpSpot;
            if (!this.checkPlace(pos) || (tpSpot = this.findSmartTpSpot(pos)) == null) continue;
            class_243 explosionOrigin = class_243.method_24953((class_2382)pos);
            float targetDmg = DamageUtils.anchorDamage((class_1309)((class_1309)target), (class_243)explosionOrigin);
            float selfDmg = DamageUtils.anchorDamage((class_1309)this.mc.field_1724, (class_243)explosionOrigin);
            if ((double)targetDmg < (Double)this.minDamage.get() || (double)selfDmg > (Double)this.maxSelfDamage.get()) continue;
            double score = head.method_1025(tpSpot);
            list.add(new AttackPos(pos, tpSpot, score));
        }
        if (list.isEmpty()) {
            return null;
        }
        list.sort(Comparator.comparingDouble(a -> a.score));
        return (AttackPos)list.get(0);
    }

    private boolean checkPlace(class_2338 pos) {
        if (!this.mc.field_1687.method_24794(pos)) {
            return false;
        }
        class_2680 state = this.mc.field_1687.method_8320(pos);
        if (!state.method_45474()) {
            return false;
        }
        return this.mc.field_1687.method_8628(class_2246.field_23152.method_9564(), pos, class_3726.method_16194());
    }

    private int getSlot(FindItemResult res, int pref) {
        if (res.isHotbar()) {
            return res.slot();
        }
        if (((Boolean)this.autoRefill.get()).booleanValue() && res.found()) {
            InvUtils.move().from(res.slot()).toHotbar(pref);
            return pref;
        }
        return -1;
    }

    private void executeTPAuraAttack(AttackPos info, int aSlot, int gSlot) {
        class_746 baseEntity = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_243 startPos = new class_243(baseEntity.method_23317(), baseEntity.method_23318(), baseEntity.method_23321());
        class_243 targetStandPos = this.getTp5BlocksAway(info.pos, (class_1297)this.mc.field_1724);
        if (this.invalid(targetStandPos) && (targetStandPos = this.findNearestPos(targetStandPos)) == null) {
            return;
        }
        this.originalPos = startPos;
        this.tickCounter = 0;
        this.core.updatePathfinding(startPos, targetStandPos, (Double)this.maxStep.get());
        List<class_243> path = this.core.getEfficientPath((Double)this.maxStep.get());
        if (path == null || path.isEmpty()) {
            return;
        }
        this.renderPathNodes.clear();
        this.renderPathNodes.addAll(path);
        if (((Boolean)this.padding.get()).booleanValue()) {
            for (int i = 0; i < 2; ++i) {
                this.mc.method_1562().method_52787((class_2596)new class_2828.class_5911(this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
            }
        }
        for (class_243 class_2432 : path) {
            this.sendTPPacket(class_2432);
            this.core.desyncPos = class_2432;
        }
        if (this.handleExistingAnchor(info.pos, gSlot, aSlot)) {
            return;
        }
        InvUtils.swap((int)aSlot, (boolean)true);
        this.placePacket(info.pos);
        InvUtils.swap((int)gSlot, (boolean)true);
        this.interactPacket(info.pos, class_2350.field_11036);
        InvUtils.swap((int)aSlot, (boolean)true);
        this.interactPacket(info.pos, class_2350.field_11036);
        InvUtils.swapBack();
        ArrayList<class_243> reverse = new ArrayList<class_243>(path);
        Collections.reverse(reverse);
        for (class_243 p : reverse) {
            this.sendTPPacket(p);
        }
        this.sendTPPacket(startPos);
        this.mc.field_1724.method_30634(startPos.field_1352, startPos.field_1351, startPos.field_1350);
        class_243 class_2433 = this.getOffset(startPos);
        this.sendTPPacket(class_2433);
        this.mc.field_1724.method_30634(class_2433.field_1352, class_2433.field_1351, class_2433.field_1350);
    }

    private void sendTPPacket(class_243 p) {
        if (p == null || this.mc.method_1562() == null || this.mc.field_1724 == null) {
            return;
        }
        class_2828.class_2829 packet = new class_2828.class_2829(p.field_1352, p.field_1351, p.field_1350, false, this.mc.field_1724.field_5976);
        ((IPlayerMoveC2SPacket)packet).meteor$setTag(1337);
        this.sendPacketSafe((class_2596<?>)packet);
    }

    private class_243 getOffset(class_243 base) {
        double dx = 0.0;
        double dy = 0.0;
        class_243[] offsets = new class_243[]{base.method_1031(dx, dy, 0.0), base.method_1031(-dx, dy, 0.0), base.method_1031(0.0, dy, dx), base.method_1031(0.0, dy, -dx), base.method_1031(dx, dy, dx), base.method_1031(-dx, dy, -dx), base.method_1031(-dx, dy, dx), base.method_1031(dx, dy, -dx)};
        List<class_243> list = Arrays.asList(offsets);
        Collections.shuffle(list);
        for (class_243 p : list) {
            if (this.invalid(p)) continue;
            return p;
        }
        return base.method_1031(0.0, dy, 0.0);
    }

    private boolean invalid(class_243 pos) {
        if (this.mc.field_1687 == null) {
            return true;
        }
        class_2338 bp = class_2338.method_49638((class_2374)pos);
        if (this.mc.field_1687.method_8497(bp.method_10263() >> 4, bp.method_10260() >> 4) == null) {
            return true;
        }
        class_746 entity = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_243 entityPos = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        class_238 box = entity.method_5829().method_997(pos.method_1020(entityPos));
        for (class_2338 b : class_2338.method_10097((class_2338)class_2338.method_49637((double)box.field_1323, (double)box.field_1322, (double)box.field_1321), (class_2338)class_2338.method_49637((double)box.field_1320, (double)box.field_1325, (double)box.field_1324))) {
            class_2680 state = this.mc.field_1687.method_8320(b);
            if (state.method_27852(class_2246.field_10164)) {
                return true;
            }
            if (state.method_26220((class_1922)this.mc.field_1687, b).method_1110()) continue;
            return true;
        }
        return false;
    }

    private class_243 predictFuturePos(class_1297 target, int ticksAhead) {
        UUID id = target.method_5667();
        class_243 current = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        class_243 lastPos = this.lastPosMap.get(id);
        if (lastPos == null) {
            this.lastPosMap.put(id, current);
            this.lastVelMap.put(id, class_243.field_1353);
            return current;
        }
        class_243 vel = current.method_1020(lastPos);
        class_243 smoothVel = vel.method_1021(0.3).method_1019(this.lastVelMap.getOrDefault(id, class_243.field_1353).method_1021(0.7));
        double maxSpeed = 0.9;
        if (smoothVel.method_1033() > maxSpeed) {
            smoothVel = smoothVel.method_1029().method_1021(maxSpeed);
        }
        this.lastPosMap.put(id, current);
        this.lastVelMap.put(id, smoothVel);
        return current.method_1019(smoothVel.method_1021((double)ticksAhead));
    }

    private class_243 getTp5BlocksAway(class_2338 anchor, class_1297 player) {
        class_243 alt;
        class_243 anchorCenter = anchor.method_46558();
        class_243 playerPos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
        class_243 future = this.currentTarget != null ? this.predictFuturePos(this.currentTarget, 4) : playerPos;
        class_243 dir = new class_243(future.field_1352 - anchorCenter.field_1352, 0.0, future.field_1350 - anchorCenter.field_1350).method_1029();
        class_243 desired = anchorCenter.method_1019(dir.method_1021(5.0));
        if (this.invalid(desired) && (alt = this.findNearestPos(desired)) != null) {
            return alt;
        }
        return desired;
    }

    private class_243 findNearestPos(class_243 desired) {
        for (int x = -2; x <= 2; ++x) {
            for (int y = -2; y <= 2; ++y) {
                for (int z = -2; z <= 2; ++z) {
                    class_243 test = desired.method_1031((double)x, (double)y, (double)z);
                    if (this.invalid(test)) continue;
                    return test;
                }
            }
        }
        return null;
    }

    private boolean handleExistingAnchor(class_2338 pos, int gSlot, int aSlot) {
        class_2680 state = this.mc.field_1687.method_8320(pos);
        if (!state.method_27852(class_2246.field_23152)) {
            return false;
        }
        int charges = (Integer)state.method_11654((class_2769)class_4969.field_23153);
        if (charges < 4) {
            InvUtils.swap((int)gSlot, (boolean)true);
            this.interactPacket(pos, class_2350.field_11036);
            InvUtils.swapBack();
            return true;
        }
        InvUtils.swap((int)aSlot, (boolean)true);
        this.interactPacket(pos, class_2350.field_11036);
        InvUtils.swapBack();
        return true;
    }

    private void placePacket(class_2338 p) {
        this.sendPacketSafe((class_2596<?>)new class_2885(class_1268.field_5808, new class_3965(p.method_46558(), class_2350.field_11036, p, false), 0));
        this.sendPacketSafe((class_2596<?>)new class_2879(class_1268.field_5808));
    }

    private void interactPacket(class_2338 p, class_2350 d) {
        this.sendPacketSafe((class_2596<?>)new class_2885(class_1268.field_5808, new class_3965(p.method_46558(), d, p, false), 0));
        this.sendPacketSafe((class_2596<?>)new class_2879(class_1268.field_5808));
    }

    private void sendPacketSafe(class_2596<?> packet) {
        long now = System.currentTimeMillis();
        long cd = 0L;
        if (this.packetsThisTick >= 20) {
            return;
        }
        if (now - this.lastPacketTime < cd) {
            return;
        }
        this.lastPacketTime = now;
        ++this.packetsThisTick;
        this.mc.method_1562().method_52787(packet);
    }

    private class_243 findSmartTpSpot(class_2338 anchorPos) {
        class_2338[] tests;
        for (class_2338 p : tests = new class_2338[]{anchorPos.method_10076(2), anchorPos.method_10077(2), anchorPos.method_10089(2), anchorPos.method_10088(2), anchorPos.method_10076(1), anchorPos.method_10077(1), anchorPos.method_10089(1), anchorPos.method_10088(1), anchorPos.method_10086(2), anchorPos.method_10087(2), anchorPos.method_10086(1), anchorPos.method_10087(1)}) {
            class_243 v = p.method_46558();
            if (this.invalid(v)) continue;
            return v;
        }
        return null;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (((Boolean)this.renderTarget.get()).booleanValue() && this.currentTarget != null) {
            event.renderer.box(this.currentTarget.method_5829(), (Color)this.targetColor.get(), (Color)this.targetColor.get(), ShapeMode.Lines, 0);
        }
        if (((Boolean)this.renderPath.get()).booleanValue() && !this.renderPathNodes.isEmpty()) {
            for (int i = 0; i < this.renderPathNodes.size() - 1; ++i) {
                class_243 n1 = this.renderPathNodes.get(i);
                class_243 n2 = this.renderPathNodes.get(i + 1);
                event.renderer.line(n1.field_1352, n1.field_1351 + 1.0, n1.field_1350, n2.field_1352, n2.field_1351 + 1.0, n2.field_1350, (Color)this.pathColor.get());
                event.renderer.box(new class_238(n1.field_1352 - 0.2, n1.field_1351, n1.field_1350 - 0.2, n1.field_1352 + 0.2, n1.field_1351 + 2.0, n1.field_1350 + 0.2), (Color)this.pathColor.get(), (Color)this.pathColor.get(), ShapeMode.Lines, 0);
            }
        }
    }

    private static enum AttackMode {
        Automatic,
        ManualKeybind;


        private AttackMode() {
        }
    }

    private static enum SortPriority {
        Closest,
        Farthest,
        LowestHealth,
        HighestHealth;


        private SortPriority() {
        }
    }

    private static enum SwingMode {
        Packet,
        Client,
        None;


        private SwingMode() {
        }
    }

    private static class SmartTPCore {
        private final class_1937 world;
        private final class_1657 player;
        private final CollisionHelper collisionHelper;
        private final AStarPathFinder pathFinder;
        public class_243 desyncPos = null;
        private volatile List<class_243> currentPath = new ArrayList<class_243>();

        public SmartTPCore(class_1937 world, class_1657 player) {
            this.world = world;
            this.player = player;
            this.collisionHelper = new CollisionHelper(world);
            this.pathFinder = new AStarPathFinder(world, this.collisionHelper);
        }

        public void updatePathfinding(class_243 start, class_243 target, double maxStep) {
            List<class_243> path = this.pathFinder.findPath(start, target, maxStep);
            if (path != null) {
                this.currentPath = path;
            }
        }

        public List<class_243> getEfficientPath(double maxStep) {
            return this.chunkPath(this.currentPath, maxStep);
        }

        private List<class_243> chunkPath(List<class_243> input, double maxStep) {
            if (input == null || input.isEmpty()) {
                return new ArrayList<class_243>();
            }
            ArrayList<class_243> raw = new ArrayList<class_243>(input);
            ArrayList<class_243> corners = new ArrayList<class_243>();
            corners.add((class_243)raw.get(0));
            for (int i = 1; i < raw.size() - 1; ++i) {
                class_243 d2;
                class_243 prev = (class_243)raw.get(i - 1);
                class_243 curr = (class_243)raw.get(i);
                class_243 next = (class_243)raw.get(i + 1);
                class_243 d1 = curr.method_1020(prev).method_1029();
                if (!(d1.method_1025(d2 = next.method_1020(curr).method_1029()) > 0.01)) continue;
                corners.add(curr);
            }
            corners.add((class_243)raw.get(raw.size() - 1));
            ArrayList<class_243> finalPath = new ArrayList<class_243>();
            finalPath.add((class_243)corners.get(0));
            int i = 0;
            while (i < corners.size() - 1) {
                class_243 p2;
                class_243 p1;
                int furthest = i + 1;
                int j = i + 1;
                while (j < corners.size() && !((p1 = (class_243)corners.get(i)).method_1022(p2 = (class_243)corners.get(j)) > maxStep - 0.05) && this.collisionHelper.canSweep(p1, p2)) {
                    furthest = j++;
                }
                finalPath.add((class_243)corners.get(furthest));
                i = furthest;
            }
            return finalPath;
        }

        public double getFloorHeightAt(class_243 pos) {
            return this.collisionHelper.getFloorHeight(class_2338.method_49638((class_2374)pos));
        }
    }

    private static class AttackPos {
        class_2338 pos;
        class_243 tpPos;
        double score;

        public AttackPos(class_2338 p, class_243 tp, double s) {
            this.pos = p;
            this.tpPos = tp;
            this.score = s;
        }
    }

    private static final class CollisionHelper {
        private final class_1937 world;
        private static final double FAT_WIDTH = 0.85;
        private static final double PLAYER_HEIGHT = 1.8;

        public CollisionHelper(class_1937 world) {
            this.world = world;
        }

        public boolean isPassable(class_2338 pos) {
            class_2680 state = this.world.method_8320(pos);
            return state.method_26220((class_1922)this.world, pos).method_1110();
        }

        public boolean canSweep(class_243 start, class_243 end) {
            double dist = start.method_1022(end);
            if (dist < 0.001) {
                return true;
            }
            int steps = (int)Math.ceil(dist / 0.05);
            class_243 dir = end.method_1020(start).method_1021(1.0 / (double)steps);
            class_243 current = start;
            for (int i = 1; i <= steps; ++i) {
                if (this.isSafe(current = current.method_1019(dir))) continue;
                return false;
            }
            return true;
        }

        public boolean isSafe(class_243 pos) {
            return this.isSafeBox(pos.field_1352, pos.field_1351, pos.field_1350);
        }

        private boolean isSafeBox(double x, double y, double z) {
            class_238 box = new class_238(x - 0.425, y + 0.01, z - 0.425, x + 0.425, y + 1.8, z + 0.425);
            return this.world.method_8335(null, box).isEmpty() && this.world.method_8587(null, box);
        }

        public double getFloorHeight(class_2338 pos) {
            class_2680 state = this.world.method_8320(pos);
            class_265 shape = state.method_26220((class_1922)this.world, pos);
            if (shape.method_1110()) {
                return 0.0;
            }
            return shape.method_1105(class_2350.class_2351.field_11052);
        }
    }

    private static final class AStarPathFinder {
        private final class_1937 world;
        private final CollisionHelper collision;
        private static final int MAX_ITER = 15000;
        private static final long TIMEOUT_MS = 150L;

        public AStarPathFinder(class_1937 world, CollisionHelper collision) {
            this.world = world;
            this.collision = collision;
        }

        public List<class_243> findPath(class_243 startVec, class_243 endVec, double maxStep) {
            class_2338 start = class_2338.method_49638((class_2374)startVec);
            class_2338 end = class_2338.method_49638((class_2374)endVec);
            if (this.collision.canSweep(startVec, endVec)) {
                return new ArrayList<class_243>(List.of(startVec, endVec));
            }
            class_243 vclip = this.tryVClip(startVec, endVec);
            if (vclip != null) {
                class_243 upEnd = new class_243(endVec.field_1352, vclip.field_1351, endVec.field_1350);
                ArrayList<class_243> path = new ArrayList<class_243>();
                path.add(startVec);
                path.add(vclip);
                path.add(upEnd);
                path.add(endVec);
                return path;
            }
            PriorityQueue<Node> open = new PriorityQueue<Node>(Comparator.comparingDouble(n -> n.f));
            HashMap<class_2338, Node> visited = new HashMap<class_2338, Node>();
            Node startNode = new Node(start, null, 0.0, this.heuristic(start, end));
            open.add(startNode);
            visited.put(start, startNode);
            long startTime = System.currentTimeMillis();
            int iterations = 0;
            Node goal = null;
            while (!open.isEmpty() && ++iterations <= 15000 && System.currentTimeMillis() - startTime <= 150L) {
                Node current = open.poll();
                if (current.pos.equals((Object)end)) {
                    goal = current;
                    break;
                }
                for (int dx = -1; dx <= 1; ++dx) {
                    for (int dy = -1; dy <= 1; ++dy) {
                        for (int dz = -1; dz <= 1; ++dz) {
                            class_2338 nextPos;
                            if (dx == 0 && dy == 0 && dz == 0 || !this.collision.isPassable(nextPos = current.pos.method_10069(dx, dy, dz))) continue;
                            double moveCost = Math.sqrt(dx * dx + dy * dy + dz * dz);
                            double newG = current.g + moveCost;
                            Node neighbor = visited.getOrDefault(nextPos, new Node(nextPos));
                            if (!(newG < neighbor.g)) continue;
                            neighbor.parent = current;
                            neighbor.g = newG;
                            neighbor.f = newG + this.heuristic(nextPos, end);
                            if (visited.containsKey(nextPos)) continue;
                            visited.put(nextPos, neighbor);
                            open.add(neighbor);
                        }
                    }
                }
            }
            if (goal == null) {
                return null;
            }
            List<class_2338> gridPath = this.reconstruct(goal);
            return this.smooth(gridPath, startVec, endVec);
        }

        private double heuristic(class_2338 a, class_2338 b) {
            return Math.sqrt(a.method_10262((class_2382)b));
        }

        private List<class_2338> reconstruct(Node goal) {
            ArrayList<class_2338> path = new ArrayList<class_2338>();
            Node curr = goal;
            while (curr != null) {
                path.add(curr.pos);
                curr = curr.parent;
            }
            Collections.reverse(path);
            return path;
        }

        private List<class_243> smooth(List<class_2338> grid, class_243 start, class_243 end) {
            ArrayList<class_243> result = new ArrayList<class_243>();
            result.add(start);
            class_243 last = start;
            for (int i = 1; i < grid.size(); ++i) {
                class_243 curr = grid.get(i).method_46558().method_1031(0.0, 0.1, 0.0);
                if (this.collision.canSweep(last, curr)) continue;
                class_243 prev = grid.get(i - 1).method_46558().method_1031(0.0, 0.1, 0.0);
                result.add(prev);
                last = prev;
            }
            result.add(end);
            return result;
        }

        private class_243 tryVClip(class_243 start, class_243 end) {
            double base;
            double maxY = Math.max(start.field_1351, end.field_1351);
            for (double y = base = maxY + 1.0; y < base + 50.0; y += 1.0) {
                class_243 upStart = new class_243(start.field_1352, y, start.field_1350);
                class_243 upEnd = new class_243(end.field_1352, y, end.field_1350);
                if (!this.isSpaceEmpty(upStart) || !this.isSpaceEmpty(upEnd) || !this.collision.canSweep(upStart, upEnd)) continue;
                return upStart;
            }
            return null;
        }

        private boolean isSpaceEmpty(class_243 pos) {
            class_238 box = new class_238(pos.field_1352 - 0.3, pos.field_1351, pos.field_1350 - 0.3, pos.field_1352 + 0.3, pos.field_1351 + 1.8, pos.field_1350 + 0.3);
            return this.world.method_8587(null, box) && this.world.method_8335(null, box).isEmpty();
        }

        private static class Node {
            class_2338 pos;
            Node parent;
            double g = Double.MAX_VALUE;
            double f = Double.MAX_VALUE;

            Node(class_2338 pos) {
                this.pos = pos;
            }

            Node(class_2338 pos, Node parent, double g, double f) {
                this.pos = pos;
                this.parent = parent;
                this.g = g;
                this.f = f;
            }
        }
    }
}

