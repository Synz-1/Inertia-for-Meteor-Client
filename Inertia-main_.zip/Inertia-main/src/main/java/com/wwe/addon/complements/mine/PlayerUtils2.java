/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.wwe.addon.complements.mine.UtilsPlus
 *  it.unimi.dsi.fastutil.objects.Object2BooleanArrayMap
 *  it.unimi.dsi.fastutil.objects.Object2BooleanMap
 *  meteordevelopment.meteorclient.MeteorClient
 *  meteordevelopment.meteorclient.events.world.TickEvent$Post
 *  meteordevelopment.meteorclient.systems.friends.Friends
 *  meteordevelopment.meteorclient.utils.Utils
 *  meteordevelopment.meteorclient.utils.entity.EntityUtils
 *  meteordevelopment.meteorclient.utils.entity.SortPriority
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1747
 *  net.minecraft.class_1750
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1934
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2680
 *  net.minecraft.class_640
 *  org.jetbrains.annotations.Nullable
 *  venomhack.mixinInterface.IBlockItem
 */
package com.wwe.addon.complements.mine;

import com.wwe.addon.complements.mine.UtilsPlus;
import it.unimi.dsi.fastutil.objects.Object2BooleanArrayMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_640;
import org.jetbrains.annotations.Nullable;
import meteordevelopment.meteorclient.mixininterface.IBlockItem;

private static final class PlayerUtils2 {
    private static final Object2BooleanArrayMap<class_2338> collisions = new Object2BooleanArrayMap();

    public static void init() {
        MeteorClient.EVENT_BUS.subscribe(PlayerUtils2.class);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        collisions.clear();
    }

    public static class_1934 getGameMode(class_1657 player) {
        class_640 playerListEntry = MeteorClient.mc.method_1562().method_2871(player.method_5667());
        if (playerListEntry == null) {
            return class_1934.field_9219;
        }
        return playerListEntry.method_2958();
    }

    public static class_243 predictPos(class_1657 player, int ticks, int antiStepOffset) {
        boolean hasStepped = false;
        class_243 pos = player.method_19538();
        class_243 v = UtilsPlus.smartVelocity((class_1297)player);
        class_243 nextPos = pos;
        if (UtilsPlus.isSurrounded((class_1309)player, (boolean)true, (boolean)true) && v.field_1351 <= 0.0) {
            return pos;
        }
        for (int i = 0; i <= ticks; ++i) {
            class_2338 newPos = new class_2338(nextPos.method_1019(v));
            if (!(PlayerUtils2.collisionCheck(newPos) || Math.ceil(player.method_18381(player.method_18376())) != 1.0 && PlayerUtils2.collisionCheck(newPos.method_10084()))) {
                nextPos = nextPos.method_1019(v);
                continue;
            }
            if (antiStepOffset >= 1 && !hasStepped && PlayerUtils2.collisionCheck(newPos) && !PlayerUtils2.collisionCheck(newPos.method_10084()) && !PlayerUtils2.collisionCheck(newPos.method_10086(2))) {
                nextPos = nextPos.method_1019(v).method_1031(0.0, 1.0, 0.0);
                hasStepped = true;
                continue;
            }
            if (antiStepOffset < 2 || hasStepped || !PlayerUtils2.collisionCheck(newPos.method_10084()) || PlayerUtils2.collisionCheck(newPos.method_10086(2)) || PlayerUtils2.collisionCheck(newPos.method_10086(3))) continue;
            nextPos = nextPos.method_1019(v).method_1031(0.0, 2.0, 0.0);
            hasStepped = true;
        }
        return nextPos;
    }

    public static class_238 predictBox(class_1657 player, int ticks, int antiStepOffset) {
        class_243 nextPos = PlayerUtils2.predictPos(player, ticks, antiStepOffset);
        class_238 oldBox = player.method_5829();
        double dx = oldBox.method_17939() * 0.5;
        double dy = oldBox.method_17940();
        double dz = oldBox.method_17941() * 0.5;
        return new class_238(nextPos.field_1352 - dx, nextPos.field_1351, nextPos.field_1350 - dz, nextPos.field_1352 + dx, nextPos.field_1351 + dy, nextPos.field_1350 + dz);
    }

    private static boolean collisionCheck(class_2338 pos) {
        if (collisions.containsKey((Object)pos)) {
            return collisions.getBoolean((Object)pos);
        }
        boolean collides = MeteorClient.mc.field_1687.method_8320((class_2338)pos).method_26204().field_23159;
        collisions.put((Object)pos, collides);
        return collides;
    }

    public static class_243 eyePos(class_1657 player) {
        return player.method_19538().method_1031(0.0, (double)player.method_18381(player.method_18376()), 0.0);
    }

    public static boolean canPlace(class_1750 context, class_1747 blockItem) {
        if (!context.method_7716()) {
            return false;
        }
        class_1750 itemPlacementContext = blockItem.method_16356(context);
        if (itemPlacementContext == null) {
            return false;
        }
        class_2680 blockState = ((IBlockItem)blockItem).getThePlacementState(itemPlacementContext);
        if (blockState == null) {
            return false;
        }
        return ((IBlockItem)blockItem).canBePlaced(itemPlacementContext, blockState);
    }

    public static void collectTargets(List<class_1657> targets, @Nullable List<class_1657> friends, int targetRange, int maxTargets, boolean ignoreNakeds, boolean onlyHoled, boolean ignoreTerrain, SortPriority sortPriority) {
        ArrayList<class_1309> livings = new ArrayList<class_1309>();
        PlayerUtils2.collectTargets(livings, friends, targetRange, maxTargets, ignoreNakeds, onlyHoled, ignoreTerrain, sortPriority, Utils.asO2BMap((Object[])new class_1299[]{class_1299.field_6097}));
        targets.clear();
        for (class_1309 living : livings) {
            targets.add((class_1657)living);
        }
    }

    public static void collectTargets(List<class_1309> targets, @Nullable List<class_1657> friends, int targetRange, int maxTargets, boolean ignoreNakeds, boolean onlyHoled, boolean ignoreTerrain, SortPriority sortPriority, Object2BooleanMap<class_1299<?>> entities) {
        targets.clear();
        if (friends != null) {
            friends.clear();
        }
        for (class_1297 entity : MeteorClient.mc.field_1687.method_18112()) {
            class_1309 living;
            if (!(entity instanceof class_1309) || (living = (class_1309)entity).method_29504() || entity == MeteorClient.mc.field_1724 || MeteorClient.mc.field_1724.method_5739(entity) > (float)targetRange) continue;
            if (entity instanceof class_1657) {
                class_1657 player = (class_1657)entity;
                if (EntityUtils.getGameMode((class_1657)player) == class_1934.field_9220) continue;
                if (Friends.get().shouldAttack(player)) {
                    if (!entities.getBoolean((Object)class_1299.field_6097) || ignoreNakeds && UtilsPlus.isNaked((class_1657)player) || onlyHoled && !UtilsPlus.isSurrounded((class_1309)player, (boolean)true, (boolean)ignoreTerrain)) continue;
                    targets.add((class_1309)player);
                    continue;
                }
                if (friends == null) continue;
                friends.add(player);
                continue;
            }
            if (!entities.getBoolean((Object)entity.method_5864())) continue;
            targets.add(living);
        }
        targets.sort((e1, e2) -> UtilsPlus.sort((class_1297)e1, (class_1297)e2, (SortPriority)sortPriority));
        while (targets.size() > maxTargets) {
            targets.remove(targets.size() - 1);
        }
    }

    public static class_1799 getStackFromResult(FindItemResult result) {
        if (MeteorClient.mc.field_1724 == null || MeteorClient.mc.field_1724.method_29504()) {
            return class_1802.field_8162.method_7854();
        }
        return result.isOffhand() ? MeteorClient.mc.field_1724.method_6079() : MeteorClient.mc.field_1724.method_31548().method_5438(result.slot());
    }

    public static class_1792 getItemFromResult(FindItemResult result) {
        return PlayerUtils2.getStackFromResult(result).method_7909();
    }
}

