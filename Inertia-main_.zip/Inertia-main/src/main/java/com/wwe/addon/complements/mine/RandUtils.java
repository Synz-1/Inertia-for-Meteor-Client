/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  meteordevelopment.meteorclient.MeteorClient
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.Rotations
 *  net.minecraft.class_1268
 *  net.minecraft.class_1703
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1799
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2813
 *  net.minecraft.class_2879
 */
package com.wwe.addon.complements.mine;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.Rotations;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2879;

public class RandUtils {
    public static int countEmptySlots() {
        int emptySlots = 0;
        for (int i = 0; i < 36; ++i) {
            class_1799 stack = MeteorClient.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960()) continue;
            ++emptySlots;
        }
        return emptySlots;
    }

    public static class_2350 direction(class_2382 vec3i) {
        return class_2350.method_16365((int)vec3i.method_10263(), (int)vec3i.method_10264(), (int)vec3i.method_10260());
    }

    public static void rotate(class_2338 blockPos, Runnable callback) {
        RandUtils.rotate(class_243.method_24953((class_2382)blockPos), callback);
    }

    public static void rotate(class_243 vec3d, Runnable callback) {
        Rotations.rotate((double)Rotations.getYaw((class_243)vec3d), (double)Rotations.getPitch((class_243)vec3d), (Runnable)callback);
    }

    public static class_1268 hand(FindItemResult result) {
        return result.getHand() == null ? class_1268.field_5808 : result.getHand();
    }

    public static void swing(boolean clientSide) {
        RandUtils.swing(clientSide, class_1268.field_5808);
    }

    public static void swing(boolean clientSide, class_1268 hand) {
        if (clientSide) {
            MeteorClient.mc.field_1724.method_6104(hand);
            return;
        }
        MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2879(hand));
    }

    public static int bounds(double value) {
        if (value == 0.0) {
            return 0;
        }
        if (value < 0.0) {
            return -1;
        }
        return 1;
    }

    public static double horizontalDistance(class_243 vec1, class_243 vec2) {
        double dx = vec1.field_1352 - vec2.field_1352;
        double dz = vec1.field_1350 - vec2.field_1350;
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static double durabilityPercentage(class_1799 stack) {
        return 100.0 * (double)(stack.method_7936() - stack.method_7919()) / (double)stack.method_7936();
    }

    public static void clickSlotPacket(int fromIndex, int toIndex, class_1713 type) {
        class_1703 sh = MeteorClient.mc.field_1724.field_7512;
        class_1735 slot = sh.method_7611(fromIndex);
        Int2ObjectArrayMap stack = new Int2ObjectArrayMap();
        stack.put(fromIndex, (Object)slot.method_7677());
        MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2813(sh.field_7763, sh.method_37421(), slot.field_7874, toIndex, type, sh.method_7611(fromIndex).method_7677(), (Int2ObjectMap)stack));
    }
}

