/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.entity.EntityAddedEvent
 *  meteordevelopment.meteorclient.events.entity.EntityRemovedEvent
 *  meteordevelopment.meteorclient.events.game.GameLeftEvent
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Receive
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.settings.StringListSetting$Builder
 *  meteordevelopment.meteorclient.settings.StringSetting$Builder
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2703
 *  net.minecraft.class_2703$class_2705
 *  net.minecraft.class_640
 *  net.minecraft.class_7828
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.events.entity.EntityRemovedEvent;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2703;
import net.minecraft.class_640;
import net.minecraft.class_7828;

public class Detector
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final Setting<String> webhookUrl;
    private final Setting<List<String>> ignoredPlayers;
    private final Setting<List<String>> trackedPlayers;
    private final Setting<Boolean> notifySelfDisconnect;
    private final ExecutorService executor;
    private final Map<UUID, String> knownPlayers;

    public Detector() {
        super(inertia.inertia, "Detector", "Detects render inputs/outputs and Discord disconnections.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.webhookUrl = this.sgGeneral.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("webhook-url")).description("Discord Webhook URL.")).defaultValue((Object)"")).build());
        this.ignoredPlayers = this.sgGeneral.add((Setting)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)new StringListSetting.Builder().name("ignored-players")).description("List of names to ignore for the range detector.")).defaultValue(List.of("Friend1", "AltAcc2"))).build());
        this.trackedPlayers = this.sgGeneral.add((Setting)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)new StringListSetting.Builder().name("tracked-players")).description("Players to track global disconnection (TAB).")).defaultValue(List.of("AccountObjective", "AltGlobal"))).build());
        this.notifySelfDisconnect = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("notify-self-disconnect")).description("Alert if your account disconnects.")).defaultValue((Object)true)).build());
        this.executor = Executors.newSingleThreadExecutor();
        this.knownPlayers = new ConcurrentHashMap<UUID, String>();
    }

    @EventHandler
    private void onEntityAdded(EntityAddedEvent event) {
        class_1297 class_12972 = event.entity;
        if (class_12972 instanceof class_1657) {
            class_1657 player = (class_1657)class_12972;
            if (player == this.mc.field_1724) {
                return;
            }
            String name = player.method_5477().getString();
            if (this.isIgnored(name)) {
                return;
            }
            String msg = String.format("\u26a0\ufe0f **Player Entered Rank**\n\ud83d\udc64 **Name:** %s\n\ud83d\udccd **Position:** X: %.1f, Y: %.1f, Z: %.1f", name, player.method_23317(), player.method_23318(), player.method_23321());
            this.sendDiscordWebhook(false, "Range Alert", msg, 5763719);
        }
    }

    @EventHandler
    private void onEntityRemoved(EntityRemovedEvent event) {
        class_1297 class_12972 = event.entity;
        if (class_12972 instanceof class_1657) {
            class_1657 player = (class_1657)class_12972;
            if (player == this.mc.field_1724) {
                return;
            }
            String name = player.method_5477().getString();
            if (this.isIgnored(name)) {
                return;
            }
            String msg = String.format("\ud83d\udeaa **Player Out of Range**\n\ud83d\udc64 **Name:** %s", name);
            this.sendDiscordWebhook(false, "Range Alert", msg, 15158332);
        }
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        class_2703 packet;
        if (this.mc.method_1562() == null) {
            return;
        }
        Object object = event.packet;
        if (object instanceof class_2703) {
            packet = (class_2703)object;
            object = packet.method_46329().iterator();
            while (object.hasNext()) {
                class_2703.class_2705 entry = (class_2703.class_2705)object.next();
                if (entry.comp_1107() == null || entry.comp_1107().name() == null) continue;
                this.knownPlayers.put(entry.comp_1106(), entry.comp_1107().name());
            }
        }
        if ((object = event.packet) instanceof class_7828) {
            packet = (class_7828)object;
            for (UUID profileId : packet.comp_1105()) {
                class_640 entry;
                String name = this.knownPlayers.remove(profileId);
                if (name == null && (entry = this.mc.method_1562().method_2871(profileId)) != null && entry.method_2966() != null) {
                    name = entry.method_2966().name();
                }
                if (name == null || name.isBlank() || this.mc.field_1724 != null && name.equalsIgnoreCase(this.mc.field_1724.method_5477().getString()) || !this.isTracked(name)) continue;
                String msg = String.format("\ud83d\udea8 **DISCONNECTION DETECTED (GLOBAL)**\n\ud83d\udc64 **Player:** %s\n\ud83c\udf10 It has left the server.", name);
                this.sendDiscordWebhook(false, "Account Tracking", msg, 15105570);
            }
        }
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        this.knownPlayers.clear();
        if (!((Boolean)this.notifySelfDisconnect.get()).booleanValue()) {
            return;
        }
        String myName = this.mc.field_1724 != null ? this.mc.field_1724.method_5477().getString() : "Account / Alt";
        String msg = String.format("\ud83d\uded1 **ACCOUNT DISCONNECTED**\n\ud83d\udc64 **Account:** %s\n\u26a0\ufe0f The session has ended.", myName);
        this.sendDiscordWebhook(true, "Account Disconnection", msg, 0xFF0000);
    }

    private boolean isIgnored(String name) {
        return ((List)this.ignoredPlayers.get()).stream().anyMatch(ignored -> ignored.equalsIgnoreCase(name));
    }

    private boolean isTracked(String name) {
        return ((List)this.trackedPlayers.get()).stream().anyMatch(tracked -> tracked.equalsIgnoreCase(name));
    }

    private void sendDiscordWebhook(boolean sync, String title, String content, int color) {
        String rawUrl = (String)this.webhookUrl.get();
        if (rawUrl == null || rawUrl.isBlank()) {
            return;
        }
        String urlStr = rawUrl.trim().replaceAll("^\"|\"$", "");
        Runnable task = () -> {
            try {
                URL url = new URI(urlStr).toURL();
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");
                conn.setDoOutput(true);
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);
                String safeContent = content.replace("\n", "\\n").replace("\"", "\\\"");
                String safeTitle = title.replace("\"", "\\\"");
                String jsonPayload = String.format("{\"embeds\": [{\"title\": \"%s\", \"description\": \"%s\", \"color\": %d}]}", safeTitle, safeContent, color);
                try (OutputStream os = conn.getOutputStream();){
                    byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }
                int responseCode = conn.getResponseCode();
                if (responseCode >= 200 && responseCode < 300) {
                    System.out.println("[Detector] Webhook sent successfully (HTTP " + responseCode + ")");
                } else {
                    System.out.println("[Detector] Error HTTP Discord: " + responseCode);
                }
                conn.disconnect();
            }
            catch (Exception e) {
                System.err.println("[Detector] Error sending Webhook:");
                e.printStackTrace();
            }
        };
        if (sync) {
            task.run();
        } else {
            this.executor.submit(task);
        }
    }
}

