/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.renderer.ShapeMode
 *  meteordevelopment.meteorclient.settings.BlockListSetting$Builder
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.ColorSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.EnumSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.InvUtils
 *  meteordevelopment.meteorclient.utils.player.PlayerUtils
 *  meteordevelopment.meteorclient.utils.player.Rotations
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.meteorclient.utils.world.BlockUtils
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1792
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2350$class_2353
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2879
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2879;

public class FeetPlace
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgSelfTrap;
    private final SettingGroup sgExtend;
    private final SettingGroup sgProtect;
    private final SettingGroup sgRender;
    private final Setting<List<class_2248>> blocks;
    private final Setting<Boolean> center;
    private final Setting<Boolean> onlyOnGround;
    private final Setting<Boolean> airPlace;
    private final Setting<Boolean> swing;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> placeBelow;
    private final Setting<SelfTrapMode> selfTrapMode;
    private final Setting<Boolean> selfTrapHead;
    private final Setting<Boolean> extend;
    private final Setting<Boolean> extendDouble;
    private final Setting<Boolean> protect;
    private final Setting<Double> protectRange;
    private final Setting<Boolean> protectRotate;
    private final Setting<Boolean> render;
    private final Setting<ShapeMode> shapeMode;
    private final Setting<SettingColor> sideColor;
    private final Setting<SettingColor> lineColor;
    private final List<class_2338> placePoses;
    private final Map<class_2338, Long> renderPlaced;
    private final Set<class_2338> renderSkipped;
    private long lastTimeOfCrystalNearHead;
    private long lastTimeOfCrystalNearFeet;
    private long lastTimeOfExtendThreat;
    private class_2338 lastExtendThreatOffset;
    private boolean lastExtendThreatIsMine;
    private long lastAttackTime;
    private static final double PROTECT_CRYSTAL_RANGE = 3.0;

    public FeetPlace() {
        super(inertia.inertia, "FeetPlace", "Instantly surrounds you with obsidian to prevent crystal damage.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgSelfTrap = this.settings.createGroup("Self Trap");
        this.sgExtend = this.settings.createGroup("Extend");
        this.sgProtect = this.settings.createGroup("Protect");
        this.sgRender = this.settings.createGroup("Render");
        this.blocks = this.sgGeneral.add((Setting)((BlockListSetting.Builder)((BlockListSetting.Builder)new BlockListSetting.Builder().name("blocks")).description("Blocks to use for surround.")).defaultValue(new class_2248[]{class_2246.field_10540, class_2246.field_22423, class_2246.field_10443}).filter(b -> b.method_9520() >= 600.0f && b != class_2246.field_9987).build());
        this.center = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("center")).description("Centers you on the block.")).defaultValue((Object)true)).build());
        this.onlyOnGround = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("only-on-ground")).description("Only places when you are on the ground.")).defaultValue((Object)false)).build());
        this.airPlace = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("air-place")).description("Allows placing blocks without a supporting block.")).defaultValue((Object)true)).build());
        this.swing = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("swing")).description("Swings your hand when placing.")).defaultValue((Object)true)).build());
        this.rotate = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("rotate")).description("Rotates to each block position when placing.")).defaultValue((Object)true)).build());
        this.placeBelow = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("place-below")).description("Places obsidian below your feet if replaceable.")).defaultValue((Object)true)).build());
        this.selfTrapMode = this.sgSelfTrap.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("mode")).description("When to build double high around you.")).defaultValue((Object)SelfTrapMode.Smart)).build());
        this.selfTrapHead = this.sgSelfTrap.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("head")).description("Places a block above your head to prevent face-placing.")).defaultValue((Object)true)).build());
        this.extend = this.sgExtend.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("extend")).description("Places extra blocks toward crystal threats.")).defaultValue((Object)true)).build());
        this.extendDouble = this.sgExtend.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("double")).description("Double layer extend when threat is from your own mining.")).defaultValue((Object)false)).visible(() -> this.extend.get())).build());
        this.protect = this.sgProtect.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("protect")).description("Breaks nearby crystals to prevent surround break.")).defaultValue((Object)true)).build());
        this.protectRange = this.sgProtect.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("range")).description("Range to scan for crystals.")).defaultValue(3.0).min(1.0).max(6.0).visible(() -> this.protect.get())).build());
        this.protectRotate = this.sgProtect.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("rotate")).description("Rotates to crystals when protecting.")).defaultValue((Object)false)).visible(() -> this.protect.get())).build());
        this.render = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("render")).description("Renders blocks where surround will be placed.")).defaultValue((Object)true)).build());
        this.shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("shape-mode")).description("How the shapes are rendered.")).defaultValue((Object)ShapeMode.Both)).visible(() -> this.render.get())).build());
        this.sideColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("side-color")).description("The side color.")).defaultValue(new SettingColor(255, 0, 0, 50)).visible(() -> (Boolean)this.render.get() != false && ((ShapeMode)this.shapeMode.get()).sides())).build());
        this.lineColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("line-color")).description("The line color.")).defaultValue(new SettingColor(255, 0, 0)).visible(() -> (Boolean)this.render.get() != false && ((ShapeMode)this.shapeMode.get()).lines())).build());
        this.placePoses = new ArrayList<class_2338>();
        this.renderPlaced = new HashMap<class_2338, Long>();
        this.renderSkipped = new HashSet<class_2338>();
    }

    public void onActivate() {
        this.placePoses.clear();
        this.renderPlaced.clear();
        this.renderSkipped.clear();
        this.lastExtendThreatOffset = null;
        this.lastExtendThreatIsMine = false;
        this.lastTimeOfCrystalNearHead = 0L;
        this.lastTimeOfCrystalNearFeet = 0L;
        this.lastTimeOfExtendThreat = 0L;
        this.lastAttackTime = 0L;
    }

    public void onDeactivate() {
        this.placePoses.clear();
        this.renderPlaced.clear();
        this.renderSkipped.clear();
    }

    public List<class_2338> getPlacePositions() {
        return this.placePoses;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (((Boolean)this.onlyOnGround.get()).booleanValue() && !this.mc.field_1724.method_24828()) {
            return;
        }
        FindItemResult block = InvUtils.findInHotbar(itemStack -> ((List)this.blocks.get()).contains(class_2248.method_9503((class_1792)itemStack.method_7909())));
        if (!block.found()) {
            return;
        }
        if (((Boolean)this.center.get()).booleanValue()) {
            PlayerUtils.centerPlayer();
        }
        this.placePoses.clear();
        ArrayList<class_2338> feetBlocks = new ArrayList<class_2338>();
        ArrayList<class_2338> selfTrapBlocks = new ArrayList<class_2338>();
        ArrayList<class_2338> extendBlocks = new ArrayList<class_2338>();
        if (this.isCrawling()) {
            this.tickCrawling(feetBlocks, extendBlocks);
        } else {
            this.tickStanding(feetBlocks, selfTrapBlocks, extendBlocks);
        }
        this.placePoses.addAll(feetBlocks);
        this.placePoses.addAll(selfTrapBlocks);
        this.placePoses.addAll(extendBlocks);
        this.renderSkipped.clear();
        for (class_2338 pos : this.placePoses) {
            if (this.canPlace(pos)) continue;
            this.renderSkipped.add(pos);
        }
        if (((Boolean)this.protect.get()).booleanValue()) {
            this.protectSurround();
        }
        long now = System.currentTimeMillis();
        for (class_2338 pos : this.placePoses) {
            if (!this.canPlace(pos) || !BlockUtils.place((class_2338)pos, (FindItemResult)block, (boolean)((Boolean)this.rotate.get()), (int)100, (boolean)((Boolean)this.swing.get()), (boolean)true)) continue;
            this.renderPlaced.put(pos, now);
        }
    }

    private void tickStanding(List<class_2338> feetBlocks, List<class_2338> selfTrapBlocks, List<class_2338> extendBlocks) {
        class_2338 headPos;
        class_238 headCheckBox;
        class_1511 closestCrystal;
        class_238 bb = this.mc.field_1724.method_5829().method_1002(0.01, 0.1, 0.01);
        int feetY = this.mc.field_1724.method_24515().method_10264();
        int minX = (int)Math.floor(bb.field_1323);
        int maxX = (int)Math.floor(bb.field_1320);
        int minZ = (int)Math.floor(bb.field_1321);
        int maxZ = (int)Math.floor(bb.field_1324);
        List<class_2338> feetPositions = this.getFeetPositions(feetY, minX, maxX, minZ, maxZ);
        boolean threatFromAbove = false;
        boolean threatFromBelow = false;
        if (this.selfTrapMode.get() != SelfTrapMode.None || ((Boolean)this.extend.get()).booleanValue()) {
            class_238 feetBox;
            class_238 headBox = this.expandBox(this.mc.field_1724.method_5829(), 1.5, 0.5, 1.5).method_989(0.0, 1.0, 0.0);
            if (this.intersectsCrystal(headBox)) {
                threatFromAbove = true;
                this.lastTimeOfCrystalNearHead = System.currentTimeMillis();
            }
            if (this.intersectsCrystal(feetBox = this.expandBox(this.mc.field_1724.method_5829(), 1.5, 0.0, 1.5).method_989(0.0, -1.0, 0.0))) {
                threatFromBelow = true;
                this.lastTimeOfCrystalNearFeet = System.currentTimeMillis();
            }
        }
        boolean extendThreatDetected = false;
        if (((Boolean)this.extend.get()).booleanValue() && (closestCrystal = this.findClosestCrystalFromEye(headCheckBox = this.expandBox(this.mc.field_1724.method_5829(), 1.5, 0.5, 1.5).method_989(0.0, 1.0, 0.0))) != null) {
            this.lastExtendThreatOffset = closestCrystal.method_24515().method_10059((class_2382)this.mc.field_1724.method_24515());
            this.lastTimeOfExtendThreat = System.currentTimeMillis();
            this.lastExtendThreatIsMine = false;
            extendThreatDetected = true;
        }
        for (int x = minX; x <= maxX; ++x) {
            for (int z = minZ; z <= maxZ; ++z) {
                class_2338 belowPos;
                class_2338 feetPos = new class_2338(x, feetY, z);
                for (int offsetX = -1; offsetX <= 1; ++offsetX) {
                    for (int offsetZ = -1; offsetZ <= 1; ++offsetZ) {
                        if (Math.abs(offsetX) + Math.abs(offsetZ) != 1) continue;
                        class_2338 adjacentPos = feetPos.method_10069(offsetX, 0, offsetZ);
                        feetBlocks.add(adjacentPos);
                        if (this.selfTrapMode.get() == SelfTrapMode.None) continue;
                        this.checkSelfTrap(selfTrapBlocks, adjacentPos, threatFromAbove, threatFromBelow);
                    }
                }
                if (!((Boolean)this.placeBelow.get()).booleanValue() || !this.canPlace(belowPos = feetPos.method_10074())) continue;
                feetBlocks.add(belowPos);
            }
        }
        if (((Boolean)this.extend.get()).booleanValue()) {
            boolean shouldExtend;
            boolean bl = shouldExtend = extendThreatDetected && System.currentTimeMillis() - this.lastTimeOfExtendThreat < 1000L;
            if (shouldExtend && this.lastExtendThreatOffset != null) {
                for (class_2338 basePos : feetPositions) {
                    this.placeExtendBlocks(extendBlocks, basePos, this.lastExtendThreatOffset);
                    if (!this.lastExtendThreatIsMine || !((Boolean)this.extendDouble.get()).booleanValue()) continue;
                    this.placeDoubleBlocks(extendBlocks, basePos, this.lastExtendThreatOffset);
                }
            }
        }
        if (((Boolean)this.selfTrapHead.get()).booleanValue() && this.canPlace(headPos = this.mc.field_1724.method_24515().method_10086(2))) {
            selfTrapBlocks.add(headPos);
        }
    }

    private void tickCrawling(List<class_2338> feetBlocks, List<class_2338> extendBlocks) {
        boolean shouldExtend;
        class_238 detectionBox;
        class_1511 closestCrystal;
        class_238 bb = this.mc.field_1724.method_5829().method_1002(0.01, 0.0, 0.01);
        int currentY = this.mc.field_1724.method_24515().method_10264();
        int minX = (int)Math.floor(bb.field_1323);
        int maxX = (int)Math.floor(bb.field_1320);
        int minZ = (int)Math.floor(bb.field_1321);
        int maxZ = (int)Math.floor(bb.field_1324);
        List<class_2338> feetPositions = this.getFeetPositions(currentY, minX, maxX, minZ, maxZ);
        boolean extendThreatDetected = false;
        if (((Boolean)this.extend.get()).booleanValue() && (closestCrystal = this.findClosestCrystal(detectionBox = this.expandBox(this.mc.field_1724.method_5829(), 2.0, 1.0, 2.0))) != null) {
            this.lastExtendThreatOffset = closestCrystal.method_24515().method_10059((class_2382)this.mc.field_1724.method_24515());
            this.lastTimeOfExtendThreat = System.currentTimeMillis();
            this.lastExtendThreatIsMine = false;
            extendThreatDetected = true;
        }
        class_2338[] criticalOffsets = new class_2338[]{new class_2338(0, 1, 0), new class_2338(0, -1, 0), new class_2338(1, 0, 0), new class_2338(-1, 0, 0), new class_2338(0, 0, 1), new class_2338(0, 0, -1)};
        for (int x = minX; x <= maxX; ++x) {
            for (int z = minZ; z <= maxZ; ++z) {
                class_2338 playerPos = new class_2338(x, currentY, z);
                for (class_2338 offset : criticalOffsets) {
                    class_2338 targetPos = playerPos.method_10069(offset.method_10263(), offset.method_10264(), offset.method_10260());
                    if (!this.canPlace(targetPos)) continue;
                    feetBlocks.add(targetPos);
                }
            }
        }
        boolean bl = shouldExtend = (Boolean)this.extend.get() != false && extendThreatDetected && System.currentTimeMillis() - this.lastTimeOfExtendThreat < 1000L;
        if (shouldExtend && this.lastExtendThreatOffset != null) {
            for (class_2338 basePos : feetPositions) {
                this.placeExtendBlocks(extendBlocks, basePos, this.lastExtendThreatOffset);
                if (!this.lastExtendThreatIsMine || !((Boolean)this.extendDouble.get()).booleanValue()) continue;
                this.placeDoubleBlocks(extendBlocks, basePos, this.lastExtendThreatOffset);
            }
        }
    }

    private void checkSelfTrap(List<class_2338> selfTrapList, class_2338 adjacentPos, boolean threatFromAbove, boolean threatFromBelow) {
        boolean shouldBuildDown;
        class_2338 above;
        boolean shouldBuildUp;
        long now = System.currentTimeMillis();
        boolean bl = shouldBuildUp = this.selfTrapMode.get() == SelfTrapMode.Always || this.selfTrapMode.get() == SelfTrapMode.Smart && threatFromAbove && now - this.lastTimeOfCrystalNearHead < 1000L;
        if (shouldBuildUp && this.canPlace(above = adjacentPos.method_10084())) {
            selfTrapList.add(above);
        }
        boolean bl2 = shouldBuildDown = this.selfTrapMode.get() == SelfTrapMode.Always || this.selfTrapMode.get() == SelfTrapMode.Smart && threatFromBelow && now - this.lastTimeOfCrystalNearFeet < 1000L;
        if (shouldBuildDown) {
            class_2338 feetFloor;
            class_2338 below = adjacentPos.method_10074();
            if (this.canPlace(below)) {
                selfTrapList.add(below);
            }
            if (this.canPlace(feetFloor = this.mc.field_1724.method_24515().method_10087(2))) {
                selfTrapList.add(feetFloor);
            }
        }
    }

    private void placeExtendBlocks(List<class_2338> out, class_2338 feetPos, class_2338 crystalOffset) {
        boolean isCardinal;
        if (crystalOffset == null) {
            return;
        }
        int normDx = Integer.signum(crystalOffset.method_10263());
        int normDz = Integer.signum(crystalOffset.method_10260());
        boolean isDiagonal = normDx != 0 && normDz != 0;
        boolean bl = isCardinal = normDx != 0 != (normDz != 0);
        if (isDiagonal) {
            this.addIfPlaceable(out, feetPos.method_10069(normDx, 0, normDz));
            this.addIfPlaceable(out, feetPos.method_10069(normDx * 2, 0, 0));
            this.addIfPlaceable(out, feetPos.method_10069(0, 0, normDz * 2));
        } else if (isCardinal) {
            class_2338 straight;
            class_2338 diag2;
            class_2338 diag1;
            if (normDx != 0) {
                diag1 = feetPos.method_10069(normDx, 0, 1);
                diag2 = feetPos.method_10069(normDx, 0, -1);
                straight = feetPos.method_10069(normDx * 2, 0, 0);
            } else {
                diag1 = feetPos.method_10069(1, 0, normDz);
                diag2 = feetPos.method_10069(-1, 0, normDz);
                straight = feetPos.method_10069(0, 0, normDz * 2);
            }
            this.addIfPlaceable(out, diag1);
            this.addIfPlaceable(out, diag2);
            this.addIfPlaceable(out, straight);
        }
    }

    private void placeDoubleBlocks(List<class_2338> out, class_2338 feetPos, class_2338 mineOffset) {
        if (mineOffset == null) {
            return;
        }
        class_2338 breakingPos = feetPos.method_10069(mineOffset.method_10263(), mineOffset.method_10264(), mineOffset.method_10260());
        if (this.canPlace(breakingPos.method_10084())) {
            out.add(breakingPos.method_10084());
        }
        this.addIfPlaceable(out, breakingPos.method_10095());
        this.addIfPlaceable(out, breakingPos.method_10072());
        this.addIfPlaceable(out, breakingPos.method_10078());
        this.addIfPlaceable(out, breakingPos.method_10067());
    }

    private void addIfPlaceable(List<class_2338> out, class_2338 pos) {
        if (this.canPlace(pos) && this.isCrystalBlock(pos.method_10074())) {
            out.add(pos);
        }
    }

    private boolean isCrystalBlock(class_2338 pos) {
        return this.mc.field_1687.method_8320(pos).method_27852(class_2246.field_10540) || this.mc.field_1687.method_8320(pos).method_27852(class_2246.field_9987);
    }

    private void protectSurround() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (System.currentTimeMillis() - this.lastAttackTime < 50L) {
            return;
        }
        class_243 eye = this.mc.field_1724.method_33571();
        double rangeSq = 9.0;
        class_1511 best = null;
        double bestDistSq = Double.POSITIVE_INFINITY;
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            class_238 box;
            class_243 closest;
            double dSq;
            class_1511 crystal;
            if (!(entity instanceof class_1511) || !(crystal = (class_1511)entity).method_5805() || crystal.method_31481() || (dSq = eye.method_1025(closest = this.closestPointOnBox(eye, box = crystal.method_5829()))) > rangeSq || !(dSq < bestDistSq)) continue;
            bestDistSq = dSq;
            best = crystal;
        }
        if (best == null) {
            return;
        }
        class_1511 target = best;
        if (((Boolean)this.protectRotate.get()).booleanValue()) {
            Rotations.rotate((double)Rotations.getPitch(target), (double)Rotations.getYaw(target), () -> this.attackCrystal(target));
        } else {
            this.attackCrystal(target);
        }
    }

    private void attackCrystal(class_1511 crystal) {
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
            return;
        }
        this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, (class_1297)crystal);
        this.mc.field_1724.method_6104(class_1268.field_5808);
        this.mc.method_1562().method_52787((class_2596)new class_2879(class_1268.field_5808));
        this.lastAttackTime = System.currentTimeMillis();
    }

    private class_1511 findClosestCrystal(class_238 box) {
        class_1511 closest = null;
        double closestDistSq = Double.MAX_VALUE;
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            double distSq;
            class_1511 crystal;
            if (!(entity instanceof class_1511) || !box.method_994((crystal = (class_1511)entity).method_5829()) || !((distSq = crystal.method_5707(this.mc.field_1724.method_19538())) < closestDistSq)) continue;
            closestDistSq = distSq;
            closest = crystal;
        }
        return closest;
    }

    private class_1511 findClosestCrystalFromEye(class_238 box) {
        class_1511 closest = null;
        double closestDistSq = Double.MAX_VALUE;
        class_243 eye = this.mc.field_1724.method_33571();
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            double distSq;
            class_1511 crystal;
            if (!(entity instanceof class_1511) || !box.method_994((crystal = (class_1511)entity).method_5829()) || !((distSq = crystal.method_5707(eye)) < closestDistSq)) continue;
            closestDistSq = distSq;
            closest = crystal;
        }
        return closest;
    }

    private boolean intersectsCrystal(class_238 box) {
        for (class_1297 entity : this.mc.field_1687.method_18112()) {
            class_1511 crystal;
            if (!(entity instanceof class_1511) || !box.method_994((crystal = (class_1511)entity).method_5829())) continue;
            return true;
        }
        return false;
    }

    private boolean canPlace(class_2338 pos) {
        if (!this.mc.field_1687.method_8320(pos).method_45474()) {
            return false;
        }
        if (((Boolean)this.airPlace.get()).booleanValue()) {
            return true;
        }
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            if (this.mc.field_1687.method_8320(pos.method_10093(direction)).method_45474()) continue;
            return true;
        }
        return false;
    }

    private boolean isCrawling() {
        if (this.mc.field_1724 == null) {
            return false;
        }
        double height = this.mc.field_1724.method_5829().field_1325 - this.mc.field_1724.method_5829().field_1322;
        return height < 1.0;
    }

    private List<class_2338> getFeetPositions(int feetY, int minX, int maxX, int minZ, int maxZ) {
        ArrayList<class_2338> positions = new ArrayList<class_2338>();
        for (int x = minX; x <= maxX; ++x) {
            for (int z = minZ; z <= maxZ; ++z) {
                positions.add(new class_2338(x, feetY, z));
            }
        }
        return positions;
    }

    private class_238 expandBox(class_238 box, double x, double y, double z) {
        return new class_238(box.field_1323 - x, box.field_1322 - y, box.field_1321 - z, box.field_1320 + x, box.field_1325 + y, box.field_1324 + z);
    }

    private class_243 closestPointOnBox(class_243 point, class_238 box) {
        double cx = Math.max(box.field_1323, Math.min(point.field_1352, box.field_1320));
        double cy = Math.max(box.field_1322, Math.min(point.field_1351, box.field_1325));
        double cz = Math.max(box.field_1321, Math.min(point.field_1350, box.field_1324));
        return new class_243(cx, cy, cz);
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!((Boolean)this.render.get()).booleanValue() || this.mc.field_1724 == null) {
            return;
        }
        long now = System.currentTimeMillis();
        for (Map.Entry<class_2338, Long> entry : this.renderPlaced.entrySet()) {
            long elapsed = now - entry.getValue();
            if (elapsed > 1000L) continue;
            event.renderer.box(entry.getKey(), (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
        }
        for (class_2338 pos : this.renderSkipped) {
            SettingColor skippedSide = new SettingColor(((SettingColor)this.sideColor.get()).r, ((SettingColor)this.sideColor.get()).g, ((SettingColor)this.sideColor.get()).b, 25);
            SettingColor skippedLine = new SettingColor(((SettingColor)this.lineColor.get()).r, ((SettingColor)this.lineColor.get()).g, ((SettingColor)this.lineColor.get()).b, 80);
            event.renderer.box(pos, (Color)skippedSide, (Color)skippedLine, (ShapeMode)this.shapeMode.get(), 0);
        }
    }

    private static enum SelfTrapMode {
        None,
        Smart,
        Always;


        private SelfTrapMode() {
        }
    }
}

