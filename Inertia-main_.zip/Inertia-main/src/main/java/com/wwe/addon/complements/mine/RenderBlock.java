package com.wwe.addon.complements.mine;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

public class RenderBlock {
    public final class_2338 pos;
    public int ticks;
    public final float damage;
    public final float selfDamage;
    public RenderBlock(net.minecraft.class_2338 pos, int ticks, float damage, float selfDamage, Object ignored){this.pos=pos;this.ticks=ticks;this.damage=damage;this.selfDamage=selfDamage;}
    public static void complexRender(Render3DEvent event,double x,double y,double z,SettingColor side,SettingColor line,ShapeMode shape,boolean fade,float ticks,int renderTime,int beforeFadeDelay,boolean ignored,RenderShape renderShape,double width,double height,double yOffset,double weirdOffset,boolean shrink){ }
    public void complexRender(Render3DEvent event,SettingColor side,SettingColor line,ShapeMode shape,boolean fade,int beforeFadeDelay,boolean ignored,RenderShape renderShape,double width,double height,double yOffset,double weirdOffset,boolean shrink){ }
}
