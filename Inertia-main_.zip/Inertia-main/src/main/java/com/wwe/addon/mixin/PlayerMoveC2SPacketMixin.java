/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2828
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package com.wwe.addon.mixin;

import java.lang.reflect.Field;
import java.util.Arrays;
import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_2828.class})
public class PlayerMoveC2SPacketMixin {
    @Inject(method={"<init>(DDDFFZZZZ)V"}, at={@At(value="RETURN")})
    private void onFullPacketInit(double x, double y, double z, float yaw, float pitch, boolean onGround, boolean horizontalCollision, boolean verticalCollision, boolean jumping, CallbackInfo ci) {
        try {
            Field xField = class_2828.class.getDeclaredField("x");
            Arrays.stream(class_2828.class.getDeclaredFields()).filter(f -> f.getName().equals("x")).findFirst().ifPresent(f -> {
                try {
                    f.setAccessible(true);
                    f.setDouble(this, x);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            });
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

