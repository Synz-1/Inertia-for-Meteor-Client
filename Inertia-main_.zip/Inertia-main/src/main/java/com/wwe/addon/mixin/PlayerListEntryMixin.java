/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  meteordevelopment.meteorclient.MeteorClient
 *  meteordevelopment.meteorclient.systems.modules.Modules
 *  meteordevelopment.meteorclient.systems.modules.misc.NameProtect
 *  net.minecraft.class_1068
 *  net.minecraft.class_156
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_640
 *  net.minecraft.class_8685
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package com.wwe.addon.mixin;

import com.mojang.authlib.GameProfile;
import com.wwe.addon.module.impl.CapesModule;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Objects;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.NameProtect;
import net.minecraft.class_1068;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_640.class})
public abstract class PlayerListEntryMixin {
    @Unique
    private boolean loadedCapeTexture;
    public String name;
    public String cape;
    @Unique
    private class_2960 customCapeTexture;

    @Inject(method={"<init>(Lcom/mojang/authlib/GameProfile;Z)V"}, at={@At(value="TAIL")})
    private void initHook(GameProfile profile, boolean secureChatEnforced, CallbackInfo ci) {
        this.getTexture(profile);
    }

    @Inject(method={"getSkinTextures"}, at={@At(value="TAIL")}, cancellable=true)
    private void getCapeTexture(CallbackInfoReturnable<class_8685> cir) {
        if (this.customCapeTexture != null) {
            class_8685 prev = (class_8685)cir.getReturnValue();
            class_8685 newTextures = new class_8685(prev.comp_1626(), prev.comp_1911(), this.customCapeTexture, this.customCapeTexture, prev.comp_1629(), prev.comp_1630());
            cir.setReturnValue((Object)newTextures);
        }
    }

    @Unique
    private void getTexture(GameProfile profile) {
        if (this.loadedCapeTexture) {
            return;
        }
        this.loadedCapeTexture = true;
        class_156.method_18349().execute(() -> {
            try {
                String inputLine;
                URL capesList = new URL("https://raw.githubusercontent.com/Gllody/nhcapes/refs/heads/main/capeBase.txt");
                BufferedReader in = new BufferedReader(new InputStreamReader(capesList.openStream()));
                while ((inputLine = in.readLine()) != null) {
                    String colune = inputLine.trim();
                    this.name = colune.split(":")[0];
                    this.cape = colune.split(":")[1];
                    if (Objects.equals(profile.getName(), this.name)) {
                        this.customCapeTexture = class_2960.method_60655((String)"meteorcapes", (String)("textures/capes/" + this.cape + ".png"));
                        return;
                    }
                    Modules modules = Modules.get();
                    if (CapesModule.capeed == null) {
                        return;
                    }
                    this.name = MeteorClient.mc.method_1548().method_1676();
                    this.cape = CapesModule.capeed;
                    if (!Objects.equals(profile.getName(), this.name)) continue;
                    this.customCapeTexture = class_2960.method_60655((String)"meteorcapes", (String)("textures/capes/" + this.cape + ".png"));
                    return;
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
        });
    }

    @Shadow
    public abstract GameProfile method_2966();

    @Inject(method={"getSkinTextures"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetTexture(CallbackInfoReturnable<class_8685> info) {
        if (this.method_2966().getName().equals(class_310.method_1551().method_1548().method_1676()) && ((NameProtect)Modules.get().get(NameProtect.class)).skinProtect()) {
            info.setReturnValue((Object)class_1068.method_52854((GameProfile)this.method_2966()));
        }
    }
}

