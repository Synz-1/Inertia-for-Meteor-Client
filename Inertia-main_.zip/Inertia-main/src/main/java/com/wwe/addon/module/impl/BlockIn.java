/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.InvUtils
 *  meteordevelopment.meteorclient.utils.player.PlayerUtils
 *  meteordevelopment.meteorclient.utils.world.BlockUtils
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1313
 *  net.minecraft.class_1747
 *  net.minecraft.class_1799
 *  net.minecraft.class_1922
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2338$class_2339
 *  net.minecraft.class_2346
 *  net.minecraft.class_243
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1313;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;

public class BlockIn
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> multiPlace;
    private final Setting<Boolean> center;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> turnOff;
    private final Setting<Boolean> onlyOnGround;
    private final class_2338.class_2339 bp;
    private boolean return_;
    private double sY;

    public BlockIn() {
        super(inertia.inertia, "BlockIn", "Block yourself in using any block.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.multiPlace = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("multi-place")).description("Whether to place all blocks in a single tick")).defaultValue((Object)false)).build());
        this.center = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("center")).description("Whether to center to avoid obstructing placement")).defaultValue((Object)true)).build());
        this.rotate = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("rotate")).description("Whether to rotate towards block placements.")).defaultValue((Object)true)).build());
        this.turnOff = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("turn-off")).description("Whether to turn off after finished placing.")).defaultValue((Object)true)).build());
        this.onlyOnGround = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("only-on-ground")).description("Only places when you are standing on blocks (not in midair).")).defaultValue((Object)true)).build());
        this.bp = new class_2338.class_2339();
    }

    public void onActivate() {
        this.sY = this.mc.field_1724.method_23318();
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (this.mc.field_1724.method_24828() && this.mc.field_1724.method_23318() > Math.floor(this.mc.field_1724.method_23318() + 0.2)) {
            this.mc.field_1690.field_1832.method_23481(true);
        }
        if (this.return_ && this.mc.field_1690.field_1832.method_1434()) {
            this.mc.field_1690.field_1832.method_23481(false);
        }
        if (((Boolean)this.center.get()).booleanValue()) {
            if (!((Boolean)this.onlyOnGround.get()).booleanValue()) {
                this.mc.field_1724.method_18800(0.0, 0.0, 0.0);
                this.mc.field_1724.method_5784(class_1313.field_6308, new class_243(0.0, -(this.sY - Math.floor(this.sY)), 0.0));
            }
            PlayerUtils.centerPlayer();
        }
        if (((Boolean)this.onlyOnGround.get()).booleanValue() && !this.mc.field_1724.method_24828()) {
            return;
        }
        this.return_ = false;
        if (((Boolean)this.multiPlace.get()).booleanValue()) {
            boolean p1 = this.place(0, -1, 0);
            boolean p2 = this.place(1, 0, 0);
            boolean p3 = this.place(-1, 0, 0);
            boolean p4 = this.place(0, 0, 1);
            boolean p5 = this.place(0, 0, -1);
            boolean p6 = this.place(1, 1, 0);
            boolean p7 = this.place(-1, 1, 0);
            boolean p8 = this.place(0, 1, 1);
            boolean p9 = this.place(0, 1, -1);
            boolean p10 = this.place(0, 2, 0);
            if (((Boolean)this.turnOff.get()).booleanValue() && p1 && p2 && p3 && p4 && p5 && p6 && p7 && p8 && p9 && p10) {
                this.toggle();
            }
        } else {
            boolean p1 = this.place(0, -1, 0);
            if (this.return_) {
                return;
            }
            boolean p2 = this.place(1, 0, 0);
            if (this.return_) {
                return;
            }
            boolean p3 = this.place(-1, 0, 0);
            if (this.return_) {
                return;
            }
            boolean p4 = this.place(0, 0, 1);
            if (this.return_) {
                return;
            }
            boolean p5 = this.place(0, 0, -1);
            if (this.return_) {
                return;
            }
            boolean p6 = this.place(1, 1, 0);
            if (this.return_) {
                return;
            }
            boolean p7 = this.place(-1, 1, 0);
            if (this.return_) {
                return;
            }
            boolean p8 = this.place(0, 1, 1);
            if (this.return_) {
                return;
            }
            boolean p9 = this.place(0, 1, -1);
            if (this.return_) {
                return;
            }
            boolean p10 = this.place(0, 2, 0);
            if (((Boolean)this.turnOff.get()).booleanValue() && p1 && p2 && p3 && p4 && p5 && p6 && p7 && p8 && p9 && p10) {
                this.toggle();
            }
        }
    }

    private boolean place(int x, int y, int z) {
        this.setBlockPos(x, y, z);
        FindItemResult findItemResult = InvUtils.findInHotbar(itemStack -> this.validItem((class_1799)itemStack, (class_2338)this.bp));
        if (!BlockUtils.canPlace((class_2338)this.bp)) {
            return true;
        }
        if (BlockUtils.place((class_2338)this.bp, (FindItemResult)findItemResult, (boolean)((Boolean)this.rotate.get()), (int)100, (boolean)true)) {
            this.return_ = true;
        }
        return false;
    }

    private void setBlockPos(int x, int y, int z) {
        this.bp.method_10102(this.mc.field_1724.method_23317() + (double)x, this.mc.field_1724.method_23318() + (double)y, this.mc.field_1724.method_23321() + (double)z);
    }

    private boolean validItem(class_1799 itemStack, class_2338 pos) {
        if (!(itemStack.method_7909() instanceof class_1747)) {
            return false;
        }
        class_2248 block = ((class_1747)itemStack.method_7909()).method_7711();
        if (!class_2248.method_9614((class_265)block.method_9564().method_26220((class_1922)this.mc.field_1687, pos))) {
            return false;
        }
        return !(block instanceof class_2346) || !class_2346.method_10128((class_2680)this.mc.field_1687.method_8320(pos));
    }
}

