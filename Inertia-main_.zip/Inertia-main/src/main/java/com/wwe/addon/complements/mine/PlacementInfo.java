package com.wwe.addon.complements.mine;

import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public class PlacementInfo {
    private class_2338 pos;
    private class_2350 direction;
    private class_243 vec3d;
    private class_1309 target;
    private float damage, selfDamage;
    private boolean support, faceplace, shouldBreak, selfPop;
    private int surroundBreak, pops, friendPops;
    private double value;

    public PlacementInfo() {}
    public PlacementInfo(class_2338 pos) { this.pos = pos; }
    public class_2338 getPos(){ return pos; }
    public class_2338 getBlockPos(){ return pos; }
    public void setDirection(class_2350 d){ direction=d; }
    public class_2350 getDirection(){ return direction; }
    public void setVec3d(class_243 v){ vec3d=v; }
    public class_243 getVec3d(){ return vec3d; }
    public void setTarget(class_1309 t){ target=t; }
    public class_1309 getTarget(){ return target; }
    public void setDamage(float v){ damage=v; }
    public float getDamage(){ return damage; }
    public void setSelfDamage(float v){ selfDamage=v; }
    public float getSelfDamage(){ return selfDamage; }
    public void setSupport(boolean v){ support=v; }
    public boolean isSupport(){ return support; }
    public void setFaceplace(boolean v){ faceplace=v; }
    public boolean isFaceplace(){ return faceplace; }
    public void setShouldBreak(boolean v){ shouldBreak=v; }
    public boolean shouldBreak(){ return shouldBreak; }
    public void setSelfPop(boolean v){ selfPop=v; }
    public boolean isSelfPop(){ return selfPop; }
    public void setSurroundBreak(int v){ surroundBreak=v; }
    public int getSurroundBreak(){ return surroundBreak; }
    public int getPops(){ return pops; }
    public int getFriendPops(){ return friendPops; }
    public void incrementPops(){ pops++; }
    public void incrementFriendPops(){ friendPops++; }
    public void addFriendDamage(float v){ value += v; }
    public double getValue(){ return value; }
    public void reset(){ direction=null; vec3d=null; target=null; damage=0; selfDamage=0; support=false; faceplace=false; shouldBreak=false; selfPop=false; surroundBreak=0; pops=0; friendPops=0; value=0; }
    public void copy(PlacementInfo o){ this.pos=o.pos; this.direction=o.direction; this.vec3d=o.vec3d; this.target=o.target; this.damage=o.damage; this.selfDamage=o.selfDamage; this.support=o.support; this.faceplace=o.faceplace; this.shouldBreak=o.shouldBreak; this.selfPop=o.selfPop; this.surroundBreak=o.surroundBreak; this.pops=o.pops; this.friendPops=o.friendPops; this.value=o.value; }
}
