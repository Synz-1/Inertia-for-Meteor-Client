/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 *  meteordevelopment.meteorclient.MeteorClient
 *  net.minecraft.class_1297
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350$class_2351
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_259
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 *  net.minecraft.class_2784
 *  net.minecraft.class_3532
 *  org.jetbrains.annotations.Nullable
 */
package com.wwe.addon.complements.click;

import com.google.common.collect.ImmutableList;
import java.util.List;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2784;
import net.minecraft.class_3532;
import org.jetbrains.annotations.Nullable;

public class ServerUtils {
    public static boolean noBlocksAround(class_1297 entity) {
        class_238 box = entity.method_5829().method_1014(0.0625).method_1012(0.0, -0.55, 0.0);
        int minX = (int)Math.floor(box.field_1323);
        int minY = (int)Math.floor(box.field_1322);
        int minZ = (int)Math.floor(box.field_1321);
        int maxX = (int)Math.floor(box.field_1320);
        int maxY = (int)Math.floor(box.field_1325);
        int maxZ = (int)Math.floor(box.field_1324);
        for (int y = minY; y <= maxY; ++y) {
            for (int z = minZ; z <= maxZ; ++z) {
                for (int x = minX; x <= maxX; ++x) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 type = MeteorClient.mc.field_1687.method_8320(pos);
                    if (type == null || type.method_26215()) continue;
                    return false;
                }
            }
        }
        return true;
    }

    public static double getSquaredMovementDelta(class_243 startPos, class_243 endPos) {
        double d0 = ServerUtils.clampHorizontal(endPos.method_10216());
        double d1 = ServerUtils.clampVertical(endPos.method_10214());
        double d2 = ServerUtils.clampHorizontal(endPos.method_10215());
        double d6 = d0 - startPos.method_10216();
        double d7 = d1 - startPos.method_10214();
        double d8 = d2 - startPos.method_10215();
        class_243 movedPos = ServerUtils.move(startPos, new class_243(d6, d7, d8));
        d6 = d0 - movedPos.field_1352;
        d7 = d1 - movedPos.field_1351;
        d8 = d2 - movedPos.field_1350;
        if (d7 > -0.5 || d7 < 0.5) {
            d7 = 0.0;
        }
        return d6 * d6 + d7 * d7 + d8 * d8;
    }

    public static class_243 move(class_243 startPos, class_243 movement) {
        class_243 vec3d = ServerUtils.adjustMovementForCollisions(startPos, movement);
        if (vec3d.method_1027() > 1.0E-7) {
            return startPos.method_1019(vec3d);
        }
        return startPos;
    }

    private static class_243 adjustMovementForCollisions(class_243 startPos, class_243 movement) {
        boolean bl4;
        class_238 box = MeteorClient.mc.field_1724.method_5829().method_997(MeteorClient.mc.field_1724.method_19538().method_22882()).method_997(startPos);
        float stepHeight = 1.0f;
        List list = MeteorClient.mc.field_1687.method_20743((class_1297)MeteorClient.mc.field_1724, box.method_18804(movement));
        class_243 vec3d = movement.method_1027() == 0.0 ? movement : ServerUtils.adjustMovementForCollisions((class_1297)MeteorClient.mc.field_1724, movement, box, (class_1937)MeteorClient.mc.field_1687, list);
        boolean bl = movement.field_1352 != vec3d.field_1352;
        boolean bl2 = movement.field_1351 != vec3d.field_1351;
        boolean bl3 = movement.field_1350 != vec3d.field_1350;
        boolean bl5 = bl4 = MeteorClient.mc.field_1724.method_24828() || bl2 && movement.field_1351 < 0.0;
        if (bl4 && (bl || bl3)) {
            class_243 vec3d4;
            class_243 vec3d2 = ServerUtils.adjustMovementForCollisions((class_1297)MeteorClient.mc.field_1724, new class_243(movement.field_1352, 1.0, movement.field_1350), box, (class_1937)MeteorClient.mc.field_1687, list);
            class_243 vec3d3 = ServerUtils.adjustMovementForCollisions((class_1297)MeteorClient.mc.field_1724, new class_243(0.0, 1.0, 0.0), box.method_1012(movement.field_1352, 0.0, movement.field_1350), (class_1937)MeteorClient.mc.field_1687, list);
            if (vec3d3.field_1351 < 1.0 && (vec3d4 = ServerUtils.adjustMovementForCollisions((class_1297)MeteorClient.mc.field_1724, new class_243(movement.field_1352, 0.0, movement.field_1350), box.method_997(vec3d3), (class_1937)MeteorClient.mc.field_1687, list).method_1019(vec3d3)).method_37268() > vec3d2.method_37268()) {
                vec3d2 = vec3d4;
            }
            if (vec3d2.method_37268() > vec3d.method_37268()) {
                return vec3d2.method_1019(ServerUtils.adjustMovementForCollisions((class_1297)MeteorClient.mc.field_1724, new class_243(0.0, -vec3d2.field_1351 + movement.field_1351, 0.0), box.method_997(vec3d2), (class_1937)MeteorClient.mc.field_1687, list));
            }
        }
        return vec3d;
    }

    public static class_243 adjustMovementForCollisions(@Nullable class_1297 entity, class_243 movement, class_238 entityBoundingBox, class_1937 world, List<class_265> collisions) {
        boolean bl;
        ImmutableList.Builder builder = ImmutableList.builderWithExpectedSize((int)(collisions.size() + 1));
        if (!collisions.isEmpty()) {
            builder.addAll(collisions);
        }
        class_2784 worldBorder = world.method_8621();
        boolean bl2 = bl = entity != null && worldBorder.method_39459(entity, entityBoundingBox.method_18804(movement));
        if (bl) {
            builder.add((Object)worldBorder.method_17903());
        }
        builder.addAll(world.method_20812(entity, entityBoundingBox.method_18804(movement)));
        return ServerUtils.adjustMovementForCollisions(movement, entityBoundingBox, (List<class_265>)builder.build());
    }

    private static class_243 adjustMovementForCollisions(class_243 movement, class_238 entityBoundingBox, List<class_265> collisions) {
        boolean bl;
        if (collisions.isEmpty()) {
            return movement;
        }
        double d = movement.field_1352;
        double e = movement.field_1351;
        double f = movement.field_1350;
        if (e != 0.0 && (e = class_259.method_1085((class_2350.class_2351)class_2350.class_2351.field_11052, (class_238)entityBoundingBox, collisions, (double)e)) != 0.0) {
            entityBoundingBox = entityBoundingBox.method_989(0.0, e, 0.0);
        }
        boolean bl2 = bl = Math.abs(d) < Math.abs(f);
        if (bl && f != 0.0 && (f = class_259.method_1085((class_2350.class_2351)class_2350.class_2351.field_11051, (class_238)entityBoundingBox, collisions, (double)f)) != 0.0) {
            entityBoundingBox = entityBoundingBox.method_989(0.0, 0.0, f);
        }
        if (d != 0.0) {
            d = class_259.method_1085((class_2350.class_2351)class_2350.class_2351.field_11048, (class_238)entityBoundingBox, collisions, (double)d);
            if (!bl && d != 0.0) {
                entityBoundingBox = entityBoundingBox.method_989(d, 0.0, 0.0);
            }
        }
        if (!bl && f != 0.0) {
            f = class_259.method_1085((class_2350.class_2351)class_2350.class_2351.field_11051, (class_238)entityBoundingBox, collisions, (double)f);
        }
        return new class_243(d, e, f);
    }

    private static double clampHorizontal(double d) {
        return class_3532.method_15350((double)d, (double)-3.0E7, (double)3.0E7);
    }

    private static double clampVertical(double d) {
        return class_3532.method_15350((double)d, (double)-2.0E7, (double)2.0E7);
    }
}

