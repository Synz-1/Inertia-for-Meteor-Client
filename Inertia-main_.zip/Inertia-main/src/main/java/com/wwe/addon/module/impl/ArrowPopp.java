/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Send
 *  meteordevelopment.meteorclient.events.world.TickEvent$Post
 *  meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.EntityTypeListSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.ItemListSetting
 *  meteordevelopment.meteorclient.settings.ItemListSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.friends.Friends
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1657
 *  net.minecraft.class_1753
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1922
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2374
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2680
 *  net.minecraft.class_2828$class_2829
 *  net.minecraft.class_2828$class_5911
 *  net.minecraft.class_2833
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_2886
 *  net.minecraft.class_746
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_2833;
import net.minecraft.class_2846;
import net.minecraft.class_2886;
import net.minecraft.class_746;

public class ArrowPopp
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final SettingGroup sgTarget;
    private final SettingGroup sgTP;
    private final SettingGroup sgBow;
    private final ItemListSetting allowedItems;
    private final Setting<Integer> multiUse;
    private final Setting<Boolean> skipBoatCollision;
    private final Setting<Set<class_1299<?>>> targetTypes;
    private final Setting<Boolean> hitFriends;
    private final Setting<Integer> preTPPackets;
    private final Setting<Double> verticalBoost;
    private final Setting<Double> maxTPRange;
    private final Setting<Double> aboveTargetOffset;
    private final Setting<Double> jitterX;
    private final Setting<Double> jitterY;
    private final Setting<Boolean> autoBow;
    private final Setting<Integer> bowCharge;
    private boolean charging;
    private int chargeTimer;
    private boolean wasHoldingBow;
    private boolean interacting;
    private boolean actioning;
    private class_1297 target;

    public ArrowPopp() {
        super(inertia.inertia, "ArrowPopp", "High Speed and Reach ArrowPopp.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgTarget = this.settings.createGroup("Targeting");
        this.sgTP = this.settings.createGroup("Quantum TP");
        this.sgBow = this.settings.createGroup("Auto Bow");
        this.allowedItems = (ItemListSetting)this.sgGeneral.add((Setting)((ItemListSetting.Builder)((ItemListSetting.Builder)new ItemListSetting.Builder().name("projectiles")).description("Objetos que activan el Quantum TP.")).defaultValue(new class_1792[]{class_1802.field_8634, class_1802.field_8436, class_1802.field_8150, class_1802.field_8287, class_1802.field_8543, class_1802.field_8803, class_1802.field_49098, class_1802.field_8102, class_1802.field_8547}).build());
        this.multiUse = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("multi-interact")).description("Cantidad de interacciones al lanzar.")).defaultValue((Object)1)).min(1).sliderMax(10).build());
        this.skipBoatCollision = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("skip-boat-collision")).description("Ignora colisiones si usas BoatNoclip.")).defaultValue((Object)true)).build());
        this.targetTypes = this.sgTarget.add((Setting)((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("targets")).description("Entidades v\u00e1lidas.")).onlyAttackable().defaultValue(new class_1299[]{class_1299.field_6097}).build());
        this.hitFriends = this.sgTarget.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("attack-friends")).defaultValue((Object)false)).build());
        this.preTPPackets = this.sgTP.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("pre-tp-packets")).description("Paquetes previos para bypass.")).defaultValue((Object)6)).min(0).sliderMax(20).build());
        this.verticalBoost = this.sgTP.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("vertical-boost")).description("Altura del salto cu\u00e1ntico.")).defaultValue(55.0).min(5.0).sliderMax(120.0).build());
        this.maxTPRange = this.sgTP.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("max-tp-range")).description("Distancia m\u00e1xima al target.")).defaultValue(60.0).min(5.0).sliderMax(120.0).build());
        this.aboveTargetOffset = this.sgTP.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("above-target")).description("Offset sobre el target.")).defaultValue(0.01).min(0.0).sliderMax(5.0).build());
        this.jitterX = this.sgTP.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("horizontal-jitter")).defaultValue(0.05).min(0.001).sliderMax(1.0).build());
        this.jitterY = this.sgTP.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("vertical-jitter")).defaultValue(0.01).min(0.001).sliderMax(1.0).build());
        this.autoBow = this.sgBow.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-bow")).description("Dispara autom\u00e1ticamente cuando cargas el arco.")).defaultValue((Object)true)).build());
        this.bowCharge = this.sgBow.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("bow-charge-ticks")).defaultValue((Object)4)).min(4).sliderRange(4, 60).visible(() -> this.autoBow.get())).build());
        this.charging = false;
        this.chargeTimer = 0;
        this.wasHoldingBow = false;
        this.interacting = false;
        this.actioning = false;
        this.target = null;
    }

    private class_1297 findTarget() {
        class_1297 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1297 e : this.mc.field_1687.method_18112()) {
            double d;
            if (!this.isValidTarget(e) || !((d = this.mc.field_1724.method_5858(e)) < bestDist)) continue;
            bestDist = d;
            best = e;
        }
        return best;
    }

    private boolean isValidTarget(class_1297 e) {
        if (!((Set)this.targetTypes.get()).contains(e.method_5864())) {
            return false;
        }
        if (!e.method_5805()) {
            return false;
        }
        if (e == this.mc.field_1724) {
            return false;
        }
        if (((Boolean)this.hitFriends.get()).booleanValue() && e instanceof class_1657) {
            class_1657 p = (class_1657)e;
            if (Friends.get().isFriend(p)) {
                return false;
            }
        }
        return true;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        boolean holdingBow;
        this.target = this.findTarget();
        if (!((Boolean)this.autoBow.get()).booleanValue()) {
            return;
        }
        boolean bl = holdingBow = this.mc.field_1724.method_6047().method_7909() instanceof class_1753 || this.mc.field_1724.method_6079().method_7909() instanceof class_1753;
        if (holdingBow && !this.wasHoldingBow) {
            this.chargeTimer = 0;
        }
        if (this.charging && holdingBow) {
            ++this.chargeTimer;
            if (this.chargeTimer >= (Integer)this.bowCharge.get()) {
                this.fireArrow();
                this.chargeTimer = 0;
            }
        } else {
            this.chargeTimer = 0;
        }
        this.wasHoldingBow = holdingBow;
    }

    private void fireArrow() {
        this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12974, class_2338.field_10980, class_2350.field_11033));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler(priority=200)
    private void onPacketSend(PacketEvent.Send event) {
        class_2596 hand;
        class_2886 pkt;
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        class_2596 class_25962 = event.packet;
        if (class_25962 instanceof class_2886) {
            pkt = (class_2886)class_25962;
            hand = pkt.method_12551();
            class_1799 stack = hand == class_1268.field_5808 ? this.mc.field_1724.method_6047() : this.mc.field_1724.method_6079();
            class_1792 item = stack.method_7909();
            if (((List)this.allowedItems.get()).contains(item)) {
                if (this.interacting) {
                    return;
                }
                this.interacting = true;
                event.cancel();
                try {
                    this.performQuantumTP((class_1268)hand);
                }
                finally {
                    this.interacting = false;
                }
            } else if (item instanceof class_1753) {
                this.charging = true;
            }
        }
        if ((hand = event.packet) instanceof class_2846) {
            pkt = (class_2846)hand;
            if (!this.actioning) {
                if (pkt.method_12363() != class_2846.class_2847.field_12974) {
                    return;
                }
                class_1792 main = this.mc.field_1724.method_6047().method_7909();
                class_1792 off = this.mc.field_1724.method_6079().method_7909();
                if (!(main instanceof class_1753) && !(off instanceof class_1753)) {
                    return;
                }
                this.charging = false;
                event.cancel();
                this.actioning = true;
                this.performAction(pkt.method_12363());
                this.actioning = false;
            }
        }
    }

    private void performQuantumTP(class_1268 hand) {
        int i;
        class_243 offset;
        class_243 shot;
        class_243 upTarget;
        if (this.target == null) {
            return;
        }
        if (!this.withinRange(this.target)) {
            return;
        }
        class_746 base = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_243 origin = new class_243(base.method_23317(), base.method_23318(), base.method_23321());
        class_238 box = this.target.method_5829();
        class_243 top = new class_243(box.method_1005().field_1352, box.field_1325, box.method_1005().field_1350);
        class_243 upOrigin = origin.method_1031(0.0, ((Double)this.verticalBoost.get()).doubleValue(), 0.0);
        if (!this.validate(upOrigin, upTarget = top.method_1031(0.0, ((Double)this.verticalBoost.get()).doubleValue(), 0.0), shot = top.method_1031(0.0, ((Double)this.aboveTargetOffset.get()).doubleValue(), 0.0), upTarget, upOrigin, offset = this.computeOffset(origin))) {
            return;
        }
        for (i = 0; i < (Integer)this.preTPPackets.get(); ++i) {
            this.mc.method_1562().method_52787((class_2596)new class_2828.class_5911(true, this.mc.field_1724.field_5976));
        }
        this.move((class_1297)base, upOrigin);
        this.move((class_1297)base, upTarget);
        this.move((class_1297)base, shot);
        for (i = 0; i < (Integer)this.multiUse.get(); ++i) {
            this.mc.method_1562().method_52787((class_2596)new class_2886(hand, 0, this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455()));
        }
        this.move((class_1297)base, upTarget);
        this.move((class_1297)base, upOrigin);
        this.move((class_1297)base, origin);
        this.move((class_1297)base, offset);
        base.method_5814(offset.field_1352, offset.field_1351, offset.field_1350);
    }

    private void performAction(class_2846.class_2847 action) {
        class_243 offset;
        class_243 shot;
        class_243 upTarget;
        if (this.target == null) {
            return;
        }
        if (!this.withinRange(this.target)) {
            return;
        }
        class_746 base = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_243 origin = new class_243(base.method_23317(), base.method_23318(), base.method_23321());
        class_238 box = this.target.method_5829();
        class_243 top = new class_243(box.method_1005().field_1352, box.field_1325, box.method_1005().field_1350);
        class_243 upOrigin = origin.method_1031(0.0, ((Double)this.verticalBoost.get()).doubleValue(), 0.0);
        if (!this.validate(upOrigin, upTarget = top.method_1031(0.0, ((Double)this.verticalBoost.get()).doubleValue(), 0.0), shot = top.method_1031(0.0, ((Double)this.aboveTargetOffset.get()).doubleValue(), 0.0), upTarget, upOrigin, offset = this.computeOffset(origin))) {
            return;
        }
        for (int i = 0; i < (Integer)this.preTPPackets.get(); ++i) {
            this.mc.method_1562().method_52787((class_2596)new class_2828.class_5911(true, this.mc.field_1724.field_5976));
        }
        this.move((class_1297)base, upOrigin);
        this.move((class_1297)base, upTarget);
        this.move((class_1297)base, shot);
        this.mc.method_1562().method_52787((class_2596)new class_2846(action, class_2338.field_10980, class_2350.field_11033));
        this.move((class_1297)base, upTarget);
        this.move((class_1297)base, upOrigin);
        this.move((class_1297)base, origin);
        this.move((class_1297)base, offset);
        base.method_5814(offset.field_1352, offset.field_1351, offset.field_1350);
    }

    private boolean withinRange(class_1297 e) {
        return this.mc.field_1724.method_5858(e) <= (Double)this.maxTPRange.get() * (Double)this.maxTPRange.get();
    }

    private void move(class_1297 e, class_243 pos) {
        if (e == this.mc.field_1724) {
            class_2828.class_2829 pkt = new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, false, this.mc.field_1724.field_5976);
            ((IPlayerMoveC2SPacket)pkt).meteor$setTag(1337);
            this.mc.method_1562().method_52787((class_2596)pkt);
        } else {
            this.mc.method_1562().method_52787((class_2596)new class_2833(new class_243(e.method_23317(), e.method_23318(), e.method_23321()), e.method_36454(), e.method_36455(), false));
        }
        e.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
    }

    private boolean validate(class_243 ... positions) {
        for (class_243 p : positions) {
            if (!this.invalid(p)) continue;
            return false;
        }
        return true;
    }

    private boolean invalid(class_243 pos) {
        if (this.mc.field_1687 == null) {
            return true;
        }
        if (this.mc.field_1687.method_22350(class_2338.method_49638((class_2374)pos)) == null) {
            return true;
        }
        class_746 e = this.mc.field_1724.method_5765() ? this.mc.field_1724.method_5854() : this.mc.field_1724;
        class_238 box = e.method_5829().method_989(pos.field_1352 - e.method_23317(), pos.field_1351 - e.method_23318(), pos.field_1350 - e.method_23321());
        for (class_2338 bp : class_2338.method_10097((class_2338)class_2338.method_49637((double)box.field_1323, (double)box.field_1322, (double)box.field_1321), (class_2338)class_2338.method_49637((double)box.field_1320, (double)box.field_1325, (double)box.field_1324))) {
            class_2680 state = this.mc.field_1687.method_8320(bp);
            if (!state.method_27852(class_2246.field_10164) && state.method_26220((class_1922)this.mc.field_1687, bp).method_1110()) continue;
            return true;
        }
        for (class_1297 other : this.mc.field_1687.method_8335((class_1297)e, box)) {
            if (!other.method_5863()) continue;
            return true;
        }
        return false;
    }

    private class_243 computeOffset(class_243 base) {
        double dx = (Double)this.jitterX.get();
        double dy = (Double)this.jitterY.get();
        class_243[] offsets = new class_243[]{base.method_1031(dx, dy, 0.0), base.method_1031(-dx, dy, 0.0), base.method_1031(0.0, dy, dx), base.method_1031(0.0, dy, -dx), base.method_1031(dx, dy, dx), base.method_1031(-dx, dy, -dx), base.method_1031(-dx, dy, dx), base.method_1031(dx, dy, -dx)};
        List<class_243> list = Arrays.asList(offsets);
        Collections.shuffle(list);
        for (class_243 p : list) {
            if (this.invalid(p)) continue;
            return p;
        }
        class_243 fallback = base.method_1031(0.0, dy, 0.0);
        if (!this.invalid(fallback)) {
            return fallback;
        }
        return base;
    }
}

