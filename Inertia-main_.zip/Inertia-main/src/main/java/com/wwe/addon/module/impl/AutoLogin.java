/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.game.GameJoinedEvent
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.settings.StringSetting$Builder
 *  meteordevelopment.meteorclient.utils.player.ChatUtils
 *  meteordevelopment.orbit.EventHandler
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;

public class AutoLogin
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final Setting<String> command;
    private final Setting<String> password;

    public AutoLogin() {
        super(inertia.inertia, "AutoLogin", "It uses the login only.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.command = this.sgGeneral.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("command")).description("The Command to execute")).defaultValue((Object)"/l")).build());
        this.password = this.sgGeneral.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("password")).description("The password to log in with")).defaultValue((Object)"12345")).build());
        this.runInMainMenu = true;
    }

    @EventHandler
    private void onGameJoined(GameJoinedEvent event) {
        ChatUtils.sendPlayerMsg((String)((String)this.command.get() + " " + (String)this.password.get()));
    }
}

