/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.world.TickEvent$Post
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.orbit.EventHandler
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.orbit.EventHandler;

public class AutoVclip
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> healthLevel;
    private final Setting<Integer> clipDistance;
    private int cooldownTimer;
    private static final int COOLDOWN = 100;

    public AutoVclip() {
        super(inertia.inertia, "AutoVclip", "Use vclip only.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.healthLevel = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("health-level")).description("Health level at which to trigger vclip.")).defaultValue((Object)10)).min(1).sliderRange(1, 20).build());
        this.clipDistance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("clip-distance")).description("Distance to vclip.")).defaultValue((Object)100)).min(1).sliderRange(1, 500).build());
        this.cooldownTimer = 0;
    }

    public void onActivate() {
        this.cooldownTimer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (this.mc.field_1724 == null) {
            return;
        }
        if (this.cooldownTimer > 0) {
            --this.cooldownTimer;
            return;
        }
        if (this.mc.field_1724.method_6032() <= (float)((Integer)this.healthLevel.get()).intValue()) {
            this.mc.field_1724.field_3944.method_45729(".vclip " + String.valueOf(this.clipDistance.get()));
            this.cooldownTimer = 100;
        }
    }
}

