/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.world.TickEvent$Post
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.orbit.EventHandler
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.orbit.EventHandler;

public class HitBoxDesync
extends AddonModule {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> alternating;
    private final Setting<Boolean> minimal;
    private final Setting<Boolean> specific;
    private final Setting<Boolean> close;
    private final Setting<Boolean> selfDisable;
    private final Setting<Boolean> jumpDisable;
    private long lastAlternation;
    private double prevY;

    public HitBoxDesync() {
        super(inertia.inertia, "HitBoxDesync", "Desynchronizes your client hitbox position.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.alternating = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("alternating")).description("Periodically applies a tiny alternating correction to the desynced hitbox position.")).defaultValue((Object)false)).build());
        this.minimal = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("minimal")).description("Makes the alternating correction minimal, only required on certain servers.")).defaultValue((Object)false)).build());
        this.specific = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("specific")).description("Uses the shorter alternating interval required against certain clients.")).defaultValue((Object)false)).build());
        this.close = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("close")).description("Compatibility option kept from Zen; Zen's current implementation does not consume it in its tick path.")).defaultValue((Object)false)).build());
        this.selfDisable = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("self-disable")).description("Disables the module after applying a non-alternating desync.")).defaultValue((Object)true)).build());
        this.jumpDisable = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("jump-disable")).description("Disables the module whenever your Y level changes.")).defaultValue((Object)true)).build());
    }

    @EventHandler
    private void onTick(TickEvent.Post post) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            this.toggle();
            return;
        }
        double d = this.mc.field_1724.method_23318();
        if (((Boolean)this.jumpDisable.get()).booleanValue() && Double.compare(d, this.prevY) != 0) {
            this.toggle();
            return;
        }
        long l = (Boolean)this.specific.get() != false ? 500L : 1500L;
        long l2 = System.currentTimeMillis();
        boolean bl = l2 - this.lastAlternation >= l;
        boolean bl2 = bl && (Boolean)this.alternating.get() != false && !this.mc.field_1724.method_5715();
        double d2 = Math.floor(this.mc.field_1724.method_23317()) + 0.5;
        double d3 = Math.floor(this.mc.field_1724.method_23321()) + 0.5;
        double d4 = d2 - this.mc.field_1724.method_23317();
        double d5 = d3 - this.mc.field_1724.method_23321();
        boolean bl3 = d4 > 0.0;
        boolean bl4 = d5 > 0.0;
        double d6 = (Boolean)this.minimal.get() != false ? 0.001 : 0.002;
        double d7 = d2 + (bl2 ? d6 : 0.0) + (bl3 ? 1.0 : -1.0) * 0.2;
        double d8 = d3 + (bl2 ? d6 : 0.0) + (bl4 ? 1.0 : -1.0) * 0.2;
        this.mc.field_1724.method_5814(d7, d, d8);
        if (bl) {
            this.lastAlternation = l2;
        }
        if (((Boolean)this.selfDisable.get()).booleanValue() && !((Boolean)this.alternating.get()).booleanValue()) {
            this.toggle();
        }
    }

    public void onActivate() {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            if (this.isActive()) {
                this.toggle();
            }
            return;
        }
        this.prevY = this.mc.field_1724.method_23318();
    }
}

