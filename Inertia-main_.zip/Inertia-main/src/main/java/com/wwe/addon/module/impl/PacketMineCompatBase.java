/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.settings.IVisible
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.modules.Category
 *  org.spongepowered.asm.mixin.Mixin
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.module.AddonModule;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import meteordevelopment.meteorclient.settings.IVisible;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Category;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(targets={"com.wwe.addon.modules.PacketMine"})
public class PacketMineCompatBase
extends AddonModule {
    protected SettingGroup sgGeneral = PacketMineCompatBase.defaultGroup((Object)this);

    public PacketMineCompatBase(Category category, String string, String string2) {
        super(category, string, string2);
    }

    private static Method find(Method[] methodArray, String string, int n) {
        for (Method method : methodArray) {
            if (!method.getName().equals(string) || method.getParameterCount() != n) continue;
            return method;
        }
        return null;
    }

    private static Object call(Object object, String string, Object ... objectArray) {
        Method method = PacketMineCompatBase.find(object.getClass().getMethods(), string, objectArray.length);
        if (method == null) {
            throw new IllegalStateException("Missing Meteor builder method: " + string + "/" + objectArray.length);
        }
        try {
            return method.invoke(object, objectArray);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Failed invoking Meteor builder method: " + string, reflectiveOperationException);
        }
    }

    private static Setting<?> add(SettingGroup settingGroup, Setting<?> setting) {
        Method method = PacketMineCompatBase.find(settingGroup.getClass().getMethods(), "add", 1);
        if (method == null) {
            throw new IllegalStateException("Meteor SettingGroup.add(T) not found");
        }
        try {
            return (Setting)method.invoke(settingGroup, setting);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Failed to add PacketMine setting", reflectiveOperationException);
        }
    }

    private static SettingGroup defaultGroup(Object object) {
        try {
            Field field = object.getClass().getField("settings");
            Object object2 = field.get(object);
            Method method = PacketMineCompatBase.find(object2.getClass().getMethods(), "getDefaultGroup", 0);
            if (method == null) {
                throw new IllegalStateException("Meteor Settings.getDefaultGroup() not found");
            }
            return (SettingGroup)method.invoke(object2, new Object[0]);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Failed to access Meteor module settings", reflectiveOperationException);
        }
    }

    private static Setting<?> build(Object object, String string, String string2, Object object2, SettingGroup settingGroup, IVisible iVisible, Double d, Double d2) {
        try {
            Method method;
            String string3;
            if (object2 instanceof Boolean) {
                string3 = "meteordevelopment.meteorclient.settings.BoolSetting$Builder";
            } else if (object2 instanceof Double) {
                string3 = "meteordevelopment.meteorclient.settings.DoubleSetting$Builder";
            } else if (object2 instanceof Integer) {
                string3 = "meteordevelopment.meteorclient.settings.IntSetting$Builder";
            } else if (object2 instanceof Enum) {
                string3 = "meteordevelopment.meteorclient.settings.EnumSetting$Builder";
            } else {
                throw new IllegalArgumentException("Unsupported legacy PacketMine setting type: " + String.valueOf(object2.getClass()));
            }
            Class<?> clazz = Class.forName(string3, true, object.getClass().getClassLoader());
            Constructor<?> constructor = clazz.getDeclaredConstructor(new Class[0]);
            if (!constructor.canAccess(null)) {
                constructor.setAccessible(true);
            }
            Object obj = constructor.newInstance(new Object[0]);
            PacketMineCompatBase.call(obj, "name", string);
            PacketMineCompatBase.call(obj, "description", string2);
            PacketMineCompatBase.call(obj, "defaultValue", object2);
            if (d != null && d2 != null) {
                method = PacketMineCompatBase.find(clazz.getMethods(), "range", 2);
                if (method != null) {
                    method.invoke(obj, d, d2);
                } else {
                    Method method2 = PacketMineCompatBase.find(clazz.getMethods(), "min", 1);
                    Method method3 = PacketMineCompatBase.find(clazz.getMethods(), "max", 1);
                    if (method2 == null || method3 == null) {
                        throw new IllegalStateException("Meteor numeric builder lacks range/min/max API");
                    }
                    method2.invoke(obj, d);
                    method3.invoke(obj, d2);
                }
            }
            if (iVisible != null) {
                method = PacketMineCompatBase.find(clazz.getMethods(), "visible", 1);
                if (method == null) {
                    throw new IllegalStateException("Meteor setting builder lacks visible(...) API");
                }
                method.invoke(obj, iVisible);
            }
            method = (Setting)PacketMineCompatBase.call(obj, "build", new Object[0]);
            return PacketMineCompatBase.add(settingGroup, method);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Failed constructing PacketMine setting '" + string + "'", reflectiveOperationException);
        }
    }

    private static Setting<?> color(Object object, String string, String string2, int n, int n2, int n3, int n4, SettingGroup settingGroup, IVisible iVisible) {
        try {
            Method method;
            Object obj;
            Object obj2;
            Class<?> clazz;
            block6: {
                ClassLoader classLoader = object.getClass().getClassLoader();
                clazz = Class.forName("meteordevelopment.meteorclient.settings.ColorSetting$Builder", true, classLoader);
                obj2 = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                PacketMineCompatBase.call(obj2, "name", string);
                PacketMineCompatBase.call(obj2, "description", string2);
                Class<?> clazz2 = Class.forName("meteordevelopment.meteorclient.utils.render.color.SettingColor", true, classLoader);
                try {
                    obj = clazz2.getConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE).newInstance(n, n2, n3, n4);
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    obj = clazz2.getConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE).newInstance(n, n2, n3);
                    if (n4 == 255) break block6;
                    throw new IllegalStateException("SettingColor 3-arg constructor cannot represent alpha=" + n4);
                }
            }
            PacketMineCompatBase.call(obj2, "defaultValue", obj);
            if (iVisible != null) {
                method = PacketMineCompatBase.find(clazz.getMethods(), "visible", 1);
                if (method == null) {
                    throw new IllegalStateException("Meteor ColorSetting builder lacks visible(...) API");
                }
                method.invoke(obj2, iVisible);
            }
            method = (Setting)PacketMineCompatBase.call(obj2, "build", new Object[0]);
            return PacketMineCompatBase.add(settingGroup, method);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new IllegalStateException("Failed constructing PacketMine color setting '" + string + "'", reflectiveOperationException);
        }
    }

    public Setting<?> setting(String string, String string2, Object object) {
        return PacketMineCompatBase.build((Object)this, string, string2, object, PacketMineCompatBase.defaultGroup((Object)this), null, null, null);
    }

    public Setting<?> setting(String string, String string2, Object object, SettingGroup settingGroup, double d, double d2) {
        return PacketMineCompatBase.build((Object)this, string, string2, object, settingGroup, null, d, d2);
    }

    public Setting<?> setting(String string, String string2, Object object, SettingGroup settingGroup) {
        return PacketMineCompatBase.build((Object)this, string, string2, object, settingGroup, null, null, null);
    }

    public Setting<?> setting(String string, String string2, Object object, SettingGroup settingGroup, IVisible iVisible) {
        return PacketMineCompatBase.build((Object)this, string, string2, object, settingGroup, iVisible, null, null);
    }

    public Setting<?> setting(String string, String string2, Object object, IVisible iVisible) {
        return PacketMineCompatBase.build((Object)this, string, string2, object, PacketMineCompatBase.defaultGroup((Object)this), iVisible, null, null);
    }

    public Setting<?> setting(String string, String string2, int n, int n2, int n3, int n4, SettingGroup settingGroup, IVisible iVisible) {
        return PacketMineCompatBase.color((Object)this, string, string2, n, n2, n3, n4, settingGroup, iVisible);
    }

    public Setting<?> setting(String string, String string2, int n, int n2, int n3, SettingGroup settingGroup, IVisible iVisible) {
        return PacketMineCompatBase.color((Object)this, string, string2, n, n2, n3, 255, settingGroup, iVisible);
    }
}

