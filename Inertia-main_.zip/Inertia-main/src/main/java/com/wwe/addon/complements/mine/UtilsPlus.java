package com.wwe.addon.complements.mine;
import net.minecraft.class_1297; import net.minecraft.class_1309; import net.minecraft.class_1657; import net.minecraft.class_1511; import net.minecraft.class_2338; import net.minecraft.class_243;
public final class UtilsPlus {
 private UtilsPlus(){}
 public static double getTotalHealth(class_1309 e){ if(e==null)return 0; try{return e.method_6032()+e.method_6067();}catch(Throwable t){return 0;} }
 public static boolean canSeeBlock(class_2338 pos,class_243 eye){ return true; }
 public static boolean isBurrowed(class_1309 p){ return false; }
 public static boolean isSurrounded(class_1309 p,boolean strict,boolean ignoreTerrain){ if(p==null||p.field_6002==null)return false; class_2338 b=p.method_24515(); int solid=0; class_2338[] q={b.method_10093(net.minecraft.class_2350.field_11043),b.method_10093(net.minecraft.class_2350.field_11035),b.method_10093(net.minecraft.class_2350.field_11039),b.method_10093(net.minecraft.class_2350.field_11034)}; for(class_2338 x:q) if(!p.field_6002.method_8320(x).method_26215()) solid++; return solid>=4; }
 public static boolean isSurroundBroken(class_1309 p){return !isSurrounded(p,true,false);}
 public static byte getSurroundBreak(class_1309 p,class_2338 pos){return (byte)(isSurrounded(p,true,false)?0:1);}
 public static boolean isBlockSurroundBrokenByCrystal(class_2338 pos,class_1511 crystal){return false;}
 public static class_243 smartVelocity(class_1297 e){return new class_243(0,0,0);}
 public static boolean isNaked(class_1657 p){return false;}
 public static int sort(class_1297 a,class_1297 b,Object priority){return Double.compare(a.method_5739(b),b.method_5739(a));}
}
