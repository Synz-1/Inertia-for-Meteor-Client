/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.Object2IntMap$Entry
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Receive
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.renderer.ShapeMode
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.ColorSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.EntityTypeListSetting$Builder
 *  meteordevelopment.meteorclient.settings.EnumSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.friends.Friends
 *  meteordevelopment.meteorclient.utils.entity.SortPriority
 *  meteordevelopment.meteorclient.utils.entity.TargetUtils
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.InvUtils
 *  meteordevelopment.meteorclient.utils.player.Rotations
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1321
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1887
 *  net.minecraft.class_1893
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2604
 *  net.minecraft.class_2680
 *  net.minecraft.class_2824
 *  net.minecraft.class_2868
 *  net.minecraft.class_2879
 *  net.minecraft.class_2885
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_3959
 *  net.minecraft.class_3959$class_242
 *  net.minecraft.class_3959$class_3960
 *  net.minecraft.class_3965
 *  net.minecraft.class_5134
 *  net.minecraft.class_5321
 *  net.minecraft.class_5575
 *  net.minecraft.class_6880
 *  net.minecraft.class_9304
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import com.wwe.addon.module.impl.AutoCrystal$AlwaysTruePredicate;
import com.wwe.addon.module.impl.AutoCrystal$GodSwing;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_2824;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_5575;
import net.minecraft.class_6880;
import net.minecraft.class_9304;

public class AutoCrystal
extends AddonModule {
    private final SettingGroup sgGodSync;
    private final Setting<Boolean> godSync;
    private final Setting<Integer> predictions;
    private final Setting<Integer> offset;
    private final Setting<AutoCrystal$GodSwing> godSwing;
    private final Setting<Boolean> fast;
    private final SettingGroup sgGeneral;
    private final SettingGroup sgTarget;
    private final SettingGroup sgRender;
    private final Setting<Set<class_1299<?>>> entities;
    private final Setting<Double> placeRange;
    private final Setting<Double> breakRange;
    private final Setting<SortPriority> priority;
    private final Setting<Boolean> ignoreFriends;
    private final Setting<Boolean> ignoreBots;
    private final Setting<Double> minDamage;
    private final Setting<Double> maxSelfDamage;
    private final Setting<Integer> placeDelay;
    private final Setting<Integer> breakDelay;
    private final Setting<AutoSwitch> autoSwitch;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> autoRefill;
    private final Setting<Boolean> pauseOnEat;
    private final Setting<SwingMode> swingMode;
    private final Setting<Boolean> renderPlace;
    private final Setting<ShapeMode> placeRenderMode;
    private final Setting<SettingColor> placeFillColor;
    private final Setting<SettingColor> placeOutlineColor;
    private class_1297 target = null;
    private class_2338 bestBase = null;
    private final Map<class_2338, Long> recentPlacements;
    private int lastCrystalSlot = -1;
    private int placeTickCounter = 0;
    private int breakTickCounter = 0;
    private static final Map<Integer, Long> SENT = new HashMap<Integer, Long>();
    private static Field ENTITY_ID_FIELD;
    private static boolean initialized;
    private static int highestID = -100000;
    private Map damageCache = new HashMap();
    private int stuckTicks = 0;

    public AutoCrystal() {
        super(inertia.inertia, "AutoCrystal", "Place and breaks crystals.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgTarget = this.settings.createGroup("Target");
        this.sgRender = this.settings.createGroup("Render");
        this.entities = this.sgTarget.add((Setting)((EntityTypeListSetting.Builder)new EntityTypeListSetting.Builder().name("entities")).onlyAttackable().defaultValue(new class_1299[]{class_1299.field_6097, class_1299.field_38095, class_1299.field_6119}).build());
        this.placeRange = this.sgTarget.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("place-range")).defaultValue(6.0).min(0.0).sliderMax(6.0).build());
        this.breakRange = this.sgTarget.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("break-range")).defaultValue(6.0).min(0.0).sliderMax(6.0).build());
        this.priority = this.sgTarget.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("priority")).defaultValue((Object)SortPriority.LowestHealth)).build());
        this.ignoreFriends = this.sgTarget.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("ignore-friends")).defaultValue((Object)true)).build());
        this.ignoreBots = this.sgTarget.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("ignore-bots")).defaultValue((Object)true)).build());
        this.minDamage = this.sgGeneral.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("min-damage")).defaultValue(6.0).min(0.0).sliderMax(36.0).build());
        this.maxSelfDamage = this.sgGeneral.add((Setting)((DoubleSetting.Builder)new DoubleSetting.Builder().name("max-self-damage")).defaultValue(16.0).min(0.0).sliderMax(36.0).build());
        this.placeDelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("place-delay")).defaultValue((Object)0)).min(0).sliderMax(20).build());
        this.breakDelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("break-delay")).defaultValue((Object)0)).min(0).sliderMax(20).build());
        this.autoSwitch = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("auto-switch")).defaultValue((Object)AutoSwitch.Silent)).build());
        this.rotate = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("rotate")).defaultValue((Object)false)).build());
        this.autoRefill = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-refill")).defaultValue((Object)true)).build());
        this.pauseOnEat = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("pause-on-eat")).defaultValue((Object)true)).build());
        this.swingMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("swing-mode")).defaultValue((Object)SwingMode.Client)).build());
        this.renderPlace = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("render-place")).defaultValue((Object)true)).build());
        this.placeRenderMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("place-render-mode")).defaultValue((Object)ShapeMode.Sides)).visible(() -> this.renderPlace.get())).build());
        this.placeFillColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("place-fill-color")).defaultValue(new SettingColor(90, 0, 0, 50)).visible(() -> this.renderPlace.get())).build());
        this.placeOutlineColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("place-outline-color")).defaultValue(new SettingColor(90, 0, 0, 255)).visible(() -> this.renderPlace.get())).build());
        this.recentPlacements = new HashMap<class_2338, Long>();
        this.sgGodSync = this.settings.createGroup("GodSync");
        this.godSync = this.sgGodSync.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("god-sync")).defaultValue((Object)true)).build());
        this.predictions = this.sgGodSync.add((Setting)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("predictions")).defaultValue((Object)24)).min(1).sliderMax(64).build());
        this.offset = this.sgGodSync.add((Setting)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("offset")).defaultValue((Object)0)).min(0).sliderMax(2).build());
        this.godSwing = this.sgGodSync.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("god-swing")).defaultValue((Object)AutoCrystal$GodSwing.Normal)).build());
        this.fast = this.sgGodSync.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("fast")).defaultValue((Object)false)).build());
    }

    public void onActivate$original() {
        this.target = null;
        this.bestBase = null;
        this.recentPlacements.clear();
        this.lastCrystalSlot = -1;
        this.placeTickCounter = 0;
        this.breakTickCounter = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre pre) {
        this.damageCache.clear();
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (((Boolean)this.pauseOnEat.get()).booleanValue() && this.mc.field_1724.method_6115()) {
            this.target = null;
            this.bestBase = null;
            return;
        }
        this.recentPlacements.entrySet().removeIf(entry -> System.currentTimeMillis() - (Long)entry.getValue() > 40L);
        if (this.placeTickCounter > 0) {
            --this.placeTickCounter;
        }
        if (this.breakTickCounter > 0) {
            --this.breakTickCounter;
        }
        this.target = TargetUtils.get(class_12972 -> {
            class_1657 class_16572;
            if (!(class_12972 instanceof class_1309) || class_12972 == this.mc.field_1724 || !class_12972.method_5805()) {
                return false;
            }
            if (!((Set)this.entities.get()).contains(class_12972.method_5864())) {
                return false;
            }
            if (((Boolean)this.ignoreFriends.get()).booleanValue() && class_12972 instanceof class_1657) {
                class_16572 = (class_1657)class_12972;
                if (Friends.get().isFriend(class_16572)) {
                    return false;
                }
            }
            if (((Boolean)this.ignoreBots.get()).booleanValue() && class_12972 instanceof class_1657) {
                class_16572 = (class_1657)class_12972;
                if (this.mc.method_1562().method_2871(class_16572.method_5667()) == null) {
                    return false;
                }
            }
            return !(class_12972 instanceof class_1321) || !(class_16572 = (class_1321)class_12972).method_6181();
        }, (SortPriority)((SortPriority)this.priority.get()));
        if (this.target == null) {
            this.bestBase = null;
            return;
        }
        if (this.breakTickCounter <= 0) {
            this.tryBreakCrystalLoop();
        }
        if (this.bestBase != null) {
            if (this.recentPlacements.containsKey(this.bestBase)) {
                return;
            }
            if (this.placeTickCounter > 0) {
                return;
            }
            if (!this.isLockedBaseViable(this.bestBase)) {
                this.stuckTicks = 0;
            } else {
                ++this.stuckTicks;
                if (this.stuckTicks >= 20) {
                    this.recentPlacements.put(this.bestBase, System.currentTimeMillis());
                    this.bestBase = null;
                    this.stuckTicks = 0;
                } else {
                    this.tryPlaceCrystalAt(this.bestBase);
                    return;
                }
            }
        }
        if (this.placeTickCounter <= 0) {
            List<class_2338> list = this.collectPlacePositions();
            if (!list.isEmpty()) {
                class_2338 class_23383;
                list.sort(Comparator.comparingDouble(class_23382 -> this.score(class_23382.method_10084())).reversed());
                this.bestBase = class_23383 = list.get(0);
                this.tryPlaceCrystalAt(class_23383);
            } else {
                this.bestBase = null;
            }
        }
    }

    private double score(class_2338 class_23382) {
        return this.calculateDamage(this.target, class_23382) - this.calculateDamage((class_1297)this.mc.field_1724, class_23382) * 0.1;
    }

    private List<class_2338> collectPlacePositions() {
        ArrayList<class_2338> arrayList = new ArrayList<class_2338>();
        class_2338 class_23382 = this.mc.field_1724.method_24515();
        double d = (Double)this.placeRange.get() * (Double)this.placeRange.get();
        int n = (int)Math.ceil((Double)this.placeRange.get());
        for (int i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    class_2338 class_23383;
                    double d2;
                    class_2338 class_23384 = class_23382.method_10069(i, j, k);
                    if (!this.isValidBase(class_23384) || this.recentPlacements.containsKey(class_23384) || (d2 = this.mc.field_1724.method_5649((double)(class_23383 = class_23384.method_10084()).method_10263() + 0.5, (double)class_23383.method_10264() + 0.5, (double)class_23383.method_10260() + 0.5)) > d) continue;
                    double d3 = this.calculateDamage(this.target, class_23383);
                    double d4 = this.calculateDamage((class_1297)this.mc.field_1724, class_23383);
                    if (d3 < (Double)this.minDamage.get() || d4 > (Double)this.maxSelfDamage.get() || ((Boolean)this.ignoreBots.get()).booleanValue() && this.wouldHitIgnoredBot(class_23383)) continue;
                    arrayList.add(class_23384);
                }
            }
        }
        return arrayList;
    }

    private boolean isBot(class_1297 class_12972) {
        if (!(class_12972 instanceof class_1657)) {
            return false;
        }
        class_1657 class_16572 = (class_1657)class_12972;
        return this.mc.method_1562().method_2871(class_16572.method_5667()) == null;
    }

    private boolean wouldHitIgnoredBot(class_2338 class_23382) {
        for (class_1297 class_12972 : this.mc.field_1687.method_18112()) {
            class_1657 class_16572;
            if (!(class_12972 instanceof class_1657) || (class_16572 = (class_1657)class_12972) == this.mc.field_1724 || !this.isBot((class_1297)class_16572) || !(this.calculateDamage((class_1297)class_16572, class_23382) >= (Double)this.minDamage.get())) continue;
            return true;
        }
        return false;
    }

    private boolean isValidBase$uncached(class_2338 class_23382) {
        class_2680 class_26802 = this.mc.field_1687.method_8320(class_23382);
        if (!class_26802.method_27852(class_2246.field_10540) && !class_26802.method_27852(class_2246.field_9987)) {
            return false;
        }
        class_2338 class_23383 = class_23382.method_10084();
        if (!this.mc.field_1687.method_8320(class_23383).method_26215()) {
            return false;
        }
        class_2338 class_23384 = this.mc.field_1724.method_24515();
        if (class_23383.equals((Object)class_23384) || class_23383.equals((Object)class_23384.method_10084())) {
            return false;
        }
        class_238 class_2383 = new class_238((double)class_23383.method_10263(), (double)class_23383.method_10264(), (double)class_23383.method_10260(), (double)class_23383.method_10263() + 1.0, (double)class_23383.method_10264() + 1.0, (double)class_23383.method_10260() + 1.0);
        for (class_1297 class_12972 : this.mc.field_1687.method_18112()) {
            if (class_12972 == this.mc.field_1724 || !class_12972.method_5805() || class_12972 instanceof class_1511 || !class_12972.method_5829().method_994(class_2383)) continue;
            return false;
        }
        return true;
    }

    private void tryPlaceCrystalAt(class_2338 class_23382) {
        if (this.placeCrystal(class_23382.method_10084())) {
            if (((Boolean)this.godSync.get()).booleanValue()) {
                AutoCrystal.godSyncWithSettings(this.mc, (Integer)this.predictions.get(), (Integer)this.offset.get(), ((AutoCrystal$GodSwing)((Object)this.godSwing.get())).ordinal());
            }
            this.stuckTicks = 0;
            this.recentPlacements.put(class_23382, System.currentTimeMillis());
            this.placeTickCounter = (Integer)this.placeDelay.get();
        }
    }

    private boolean placeCrystal(class_2338 class_23382) {
        class_2338 class_23383 = class_23382.method_10074();
        class_3965 class_39652 = new class_3965(new class_243((double)class_23383.method_10263() + 0.5, (double)class_23383.method_10264() + 1.0, (double)class_23383.method_10260() + 0.5), class_2350.field_11036, class_23383, false);
        if (this.mc.field_1724.method_6079().method_7909() == class_1802.field_8301) {
            this.mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5810, class_39652, 0));
            this.doSwing(class_1268.field_5810);
            return true;
        }
        FindItemResult findItemResult = InvUtils.findInHotbar(class_17992 -> class_17992.method_7909() == class_1802.field_8301);
        if (!findItemResult.found()) {
            if (((Boolean)this.autoRefill.get()).booleanValue()) {
                FindItemResult findItemResult2 = InvUtils.find(class_17992 -> class_17992.method_7909() == class_1802.field_8301);
                if (!findItemResult2.found()) {
                    return false;
                }
                int n = this.lastCrystalSlot != -1 ? this.lastCrystalSlot : this.mc.field_1724.method_31548().method_67532();
                InvUtils.move().from(findItemResult2.slot()).toHotbar(n);
            }
            return false;
        }
        this.lastCrystalSlot = findItemResult.slot();
        switch (((AutoSwitch)((Object)this.autoSwitch.get())).ordinal()) {
            case 1: {
                int n = this.mc.field_1724.method_31548().method_67532();
                this.mc.method_1562().method_52787((class_2596)new class_2868(findItemResult.slot()));
                this.mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5808, class_39652, 0));
                this.doSwing(class_1268.field_5808);
                this.mc.method_1562().method_52787((class_2596)new class_2868(n));
                return true;
            }
            case 0: {
                InvUtils.swap((int)findItemResult.slot(), (boolean)false);
                this.mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5808, class_39652, 0));
                this.doSwing(class_1268.field_5808);
                return true;
            }
            case 2: {
                if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301) {
                    return false;
                }
                this.mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5808, class_39652, 0));
                this.doSwing(class_1268.field_5808);
                return true;
            }
        }
        return false;
    }

    private void tryBreakCrystalLoop() {
        double d = (Double)this.breakRange.get();
        double d2 = d * d;
        List list = this.mc.field_1687.method_18023(class_5575.method_31795(class_1511.class), new class_238(this.mc.field_1724.method_23317() - d2, this.mc.field_1724.method_23318() - d2, this.mc.field_1724.method_23321() - d2, this.mc.field_1724.method_23317() + d2, this.mc.field_1724.method_23318() + d2, this.mc.field_1724.method_23321() + d2), (Predicate)new AutoCrystal$AlwaysTruePredicate());
        for (class_1511 class_15112 : list) {
            double d3;
            double d4;
            if (class_15112.method_31481() || this.mc.field_1724.method_5858((class_1297)class_15112) > d2 || (d4 = this.calculateDamage(this.target, class_15112.method_24515())) < (Double)this.minDamage.get() || (d3 = this.calculateDamage((class_1297)this.mc.field_1724, class_15112.method_24515())) > (Double)this.maxSelfDamage.get()) continue;
            this.attackCrystal(class_15112);
        }
    }

    private void attackCrystal(class_1511 class_15112) {
        if (((Boolean)this.rotate.get()).booleanValue()) {
            Rotations.rotate((double)Rotations.getYaw((class_1297)class_15112), (double)Rotations.getPitch((class_1297)class_15112));
        }
        this.mc.method_1562().method_52787((class_2596)class_2824.method_34206((class_1297)class_15112, (boolean)this.mc.field_1724.method_5715()));
        this.doSwing(class_1268.field_5808);
        class_15112.method_31472();
        this.breakTickCounter = (Integer)this.breakDelay.get();
    }

    private void doSwing(class_1268 class_12682) {
        switch (((SwingMode)((Object)this.swingMode.get())).ordinal()) {
            case 0: {
                this.mc.method_1562().method_52787((class_2596)new class_2879(class_12682));
                break;
            }
            case 1: {
                this.mc.field_1724.method_6104(class_12682);
                break;
            }
        }
    }

    private double calculateDamage$uncached(class_1297 class_12972, class_2338 class_23382) {
        double d;
        class_243 class_2432 = new class_243((double)class_23382.method_10263() + 0.5, (double)class_23382.method_10264() + 0.5, (double)class_23382.method_10260() + 0.5);
        double d2 = Math.sqrt(Math.pow(class_12972.method_23317() - class_2432.field_1352, 2.0) + Math.pow(class_12972.method_23318() - class_2432.field_1351, 2.0) + Math.pow(class_12972.method_23321() - class_2432.field_1350, 2.0));
        if (d2 > (d = 12.0)) {
            return 0.0;
        }
        double d3 = this.getExposure(class_2432, class_12972);
        if (d3 <= 0.0) {
            return 0.0;
        }
        double d4 = (1.0 - d2 / d) * d3;
        double d5 = d4 * d4 * 7.0 * d;
        if (!(class_12972 instanceof class_1309)) {
            return Math.max(0.0, d5);
        }
        class_1309 class_13092 = (class_1309)class_12972;
        if (class_12972 instanceof class_1657) {
            class_1657 class_16572 = (class_1657)class_12972;
            float f = class_16572.method_6096();
            double d6 = class_16572.method_45325(class_5134.field_23725);
            double d7 = Math.max((double)f / 5.0, (double)f - d5 / (2.0 + d6 / 4.0));
            d7 = Math.min(20.0, d7);
            d5 *= 1.0 - d7 / 25.0;
            int n = 0;
            n += this.getEpf(class_16572.method_6118(class_1304.field_6169), (class_5321<class_1887>)class_1893.field_9111);
            n += this.getEpf(class_16572.method_6118(class_1304.field_6169), (class_5321<class_1887>)class_1893.field_9107);
            n += this.getEpf(class_16572.method_6118(class_1304.field_6174), (class_5321<class_1887>)class_1893.field_9111);
            n += this.getEpf(class_16572.method_6118(class_1304.field_6174), (class_5321<class_1887>)class_1893.field_9107);
            n += this.getEpf(class_16572.method_6118(class_1304.field_6172), (class_5321<class_1887>)class_1893.field_9111);
            n += this.getEpf(class_16572.method_6118(class_1304.field_6172), (class_5321<class_1887>)class_1893.field_9107);
            n += this.getEpf(class_16572.method_6118(class_1304.field_6166), (class_5321<class_1887>)class_1893.field_9111);
            n += this.getEpf(class_16572.method_6118(class_1304.field_6166), (class_5321<class_1887>)class_1893.field_9107);
            n = Math.min(n, 20);
            d5 *= 1.0 - (double)n * 0.04;
            class_1293 class_12932 = class_16572.method_6112(class_1294.field_5907);
            if (class_12932 != null) {
                d5 *= Math.max(0.0, 1.0 - (double)(class_12932.method_5578() + 1) * 0.2);
            }
        } else {
            double d8 = Math.min(20.0, (double)class_13092.method_6096() / 5.0);
            d5 *= 1.0 - d8 / 25.0;
        }
        return Math.max(0.0, d5);
    }

    private double getExposure(class_243 class_2432, class_1297 class_12972) {
        class_238 class_2383 = class_12972.method_5829();
        double d = 1.0 / ((class_2383.field_1320 - class_2383.field_1323) * 2.0 + 1.0);
        double d2 = 1.0 / ((class_2383.field_1325 - class_2383.field_1322) * 2.0 + 1.0);
        double d3 = 1.0 / ((class_2383.field_1324 - class_2383.field_1321) * 2.0 + 1.0);
        if (d < 0.0 || d2 < 0.0 || d3 < 0.0) {
            return 0.0;
        }
        double d4 = (1.0 - Math.floor(1.0 / d) * d) / 2.0;
        double d5 = (1.0 - Math.floor(1.0 / d3) * d3) / 2.0;
        int n = 0;
        int n2 = 0;
        for (double d6 = 0.0; d6 <= 1.0; d6 += d) {
            for (double d7 = 0.0; d7 <= 1.0; d7 += d2) {
                for (double d8 = 0.0; d8 <= 1.0; d8 += d3) {
                    double d9;
                    double d10;
                    double d11 = class_3532.method_16436((double)d6, (double)class_2383.field_1323, (double)class_2383.field_1320) + d4;
                    class_243 class_2433 = new class_243(d11, d10 = class_3532.method_16436((double)d7, (double)class_2383.field_1322, (double)class_2383.field_1325), d9 = class_3532.method_16436((double)d8, (double)class_2383.field_1321, (double)class_2383.field_1324) + d5);
                    class_3959 class_39592 = new class_3959(class_2433, class_2432, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, class_12972);
                    if (this.mc.field_1687.method_17742(class_39592).method_17783() == class_239.class_240.field_1333) {
                        ++n;
                    }
                    ++n2;
                }
            }
        }
        return n2 == 0 ? 0.0 : (double)n / (double)n2;
    }

    private int getEpf(class_1799 class_17992, class_5321<class_1887> class_53212) {
        class_9304 class_93042 = class_17992.method_58657();
        for (Object2IntMap.Entry entry : class_93042.method_57539()) {
            class_6880 class_68802 = (class_6880)entry.getKey();
            if (!class_68802.method_40225(class_53212)) continue;
            return Math.min(entry.getIntValue(), 4);
        }
        return 0;
    }

    @EventHandler
    private void onRender3D(Render3DEvent render3DEvent) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (((Boolean)this.renderPlace.get()).booleanValue() && this.bestBase != null) {
            render3DEvent.renderer.box(this.bestBase, (Color)this.placeFillColor.get(), (Color)this.placeOutlineColor.get(), (ShapeMode)this.placeRenderMode.get(), 0);
        }
    }

    public String getInfoString() {
        return this.target != null ? this.target.method_5477().getString() : null;
    }

    private static void godSync(class_310 class_3102) {
        if (class_3102 == null || class_3102.field_1724 == null || class_3102.field_1687 == null) {
            return;
        }
        long l = System.currentTimeMillis();
        SENT.entrySet().removeIf(entry -> l - (Long)entry.getValue() > 300L);
        int n = 0;
        for (class_1297 class_12972 : class_3102.field_1687.method_18112()) {
            if (class_12972 == null || class_12972.method_5628() <= n) continue;
            n = class_12972.method_5628();
        }
        for (int i = 1; i < 10; ++i) {
            int n2;
            class_1297 class_12972;
            class_12972 = class_3102.field_1687.method_8469(n);
            if (class_12972 != null && !(class_12972 instanceof class_1511) || SENT.containsKey(n2 = n + i)) continue;
            class_2824 class_28242 = class_2824.method_34206((class_1297)class_3102.field_1724, (boolean)class_3102.field_1724.method_5715());
            try {
                AutoCrystal.setEntityId(class_28242, n2);
            }
            catch (Throwable throwable) {
                continue;
            }
            class_3102.method_1562().method_52787((class_2596)class_28242);
            SENT.put(n2, l);
        }
        class_3102.method_1562().method_52787((class_2596)new class_2879(class_1268.field_5808));
    }

    private static void setEntityId(class_2824 class_28242, int n) throws Exception {
        if (!initialized) {
            try {
                ENTITY_ID_FIELD = class_2824.class.getDeclaredField("entityId");
            }
            catch (NoSuchFieldException noSuchFieldException) {
                ENTITY_ID_FIELD = class_2824.class.getDeclaredField("field_12870");
            }
            ENTITY_ID_FIELD.setAccessible(true);
            initialized = true;
        }
        ENTITY_ID_FIELD.setInt(class_28242, n);
    }

    private static void godSyncWithSettings(class_310 class_3102, int n, int n2, int n3) {
        block5: {
            int n4;
            Object object2;
            if (class_3102 == null || class_3102.field_1724 == null || class_3102.field_1687 == null) break block5;
            Iterator<Map.Entry<Integer, Long>> iterator = SENT.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<Integer, Long> entry = iterator.next();
                if (System.currentTimeMillis() - entry.getValue() <= 300L) continue;
                iterator.remove();
            }
            int n5 = highestID;
            for (Object object2 : class_3102.field_1687.method_18112()) {
                if (!(object2 instanceof class_1511) || (n4 = ((class_1511)object2).method_5628()) <= n5) continue;
                n5 = n4;
            }
            int n6 = n;
            object2 = class_3102.method_1562().method_2871(class_3102.field_1724.method_5667());
            if (object2 != null) {
                int n7 = Math.min(object2.method_2959() / 8, 32);
                n6 += n7;
            }
            for (n4 = 1 - n2; n4 < n6; ++n4) {
                int n8 = n5 + n4;
                if (SENT.containsKey(n8)) continue;
                class_2824 class_28242 = class_2824.method_34206((class_1297)class_3102.field_1724, (boolean)class_3102.field_1724.method_5715());
                AutoCrystal.setEntityId(class_28242, n8);
                class_3102.method_1562().method_52787((class_2596)class_28242);
                SENT.put(n8, System.currentTimeMillis());
                if (n3 != 2) continue;
                class_3102.method_1562().method_52787((class_2596)new class_2879(class_1268.field_5808));
            }
            if (n3 == 1) {
                class_3102.method_1562().method_52787((class_2596)new class_2879(class_1268.field_5808));
            }
        }
    }

    public void onActivate() {
        this.onActivate$original();
        highestID = -100000;
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive receive) {
        block2: {
            block1: {
                class_2596 class_25962 = receive.packet;
                if (!(class_25962 instanceof class_2604)) break block1;
                int n = ((class_2604)class_25962).method_11167();
                if (n <= highestID) break block2;
                highestID = n;
                break block2;
            }
            if (!(receive.packet instanceof class_2604)) break block2;
            int n = ((class_2604)receive.packet).method_11167();
            if (n > highestID) {
                highestID = n;
            }
        }
    }

    private double calculateDamage(class_1297 class_12972, class_2338 class_23382) {
        Double d;
        HashMap<class_2338, Double> hashMap = (HashMap<class_2338, Double>)this.damageCache.get(class_12972);
        if (hashMap == null) {
            hashMap = new HashMap<class_2338, Double>();
            this.damageCache.put(class_12972, hashMap);
        }
        if ((d = (Double)hashMap.get(class_23382)) != null) {
            return d;
        }
        double d2 = this.calculateDamage$uncached(class_12972, class_23382);
        hashMap.put(class_23382, d2);
        return d2;
    }

    private boolean isValidBase(class_2338 class_23382) {
        class_2338 class_23383 = class_23382.method_10084();
        double d = this.mc.field_1724.method_5649((double)class_23383.method_10263() + 0.5, (double)class_23383.method_10264() + 0.5, (double)class_23383.method_10260() + 0.5);
        double d2 = (Double)this.placeRange.get();
        if (!(d <= d2 * d2)) {
            return false;
        }
        return this.isValidBase$uncached(class_23382);
    }

    private boolean isLockedBaseViable(class_2338 class_23382) {
        if (!this.isValidBase(class_23382)) {
            return false;
        }
        class_2338 class_23383 = class_23382.method_10084();
        double d = (Double)this.placeRange.get();
        if (this.mc.field_1724.method_5649((double)class_23383.method_10263() + 0.5, (double)class_23383.method_10264() + 0.5, (double)class_23383.method_10260() + 0.5) > d * d) {
            return false;
        }
        if (this.calculateDamage(this.target, class_23383) < (Double)this.minDamage.get()) {
            return false;
        }
        if (!(this.calculateDamage((class_1297)this.mc.field_1724, class_23383) <= (Double)this.maxSelfDamage.get())) {
            return false;
        }
        return (Boolean)this.ignoreBots.get() == false || !this.wouldHitIgnoredBot(class_23383);
    }

    public static enum AutoSwitch {
        Normal,
        Silent,
        Off;

    }

    public static enum SwingMode {
        Packet,
        Client,
        None;

    }
}

