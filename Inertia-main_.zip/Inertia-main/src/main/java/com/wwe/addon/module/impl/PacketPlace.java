/*
 * Decompiled with CFR 0.152.
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;

public class PacketPlace
extends AddonModule {
    public PacketPlace() {
        super(inertia.inertia, "PacketPlace", "Places using packets.");
    }
}

