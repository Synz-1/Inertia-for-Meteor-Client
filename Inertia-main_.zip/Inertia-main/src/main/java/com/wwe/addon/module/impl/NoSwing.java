/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Send
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_2879
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2879;

public class NoSwing
extends AddonModule {
    public NoSwing() {
        super(inertia.inertia, "NoSwing", "prevent the enemy from seeing your hand movements.");
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (event.packet instanceof class_2879) {
            event.cancel();
        }
    }
}

