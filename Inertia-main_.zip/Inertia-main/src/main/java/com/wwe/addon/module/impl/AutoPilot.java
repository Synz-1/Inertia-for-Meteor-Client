/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.world.TickEvent$Post
 *  meteordevelopment.meteorclient.settings.BlockPosSetting$Builder
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_2561
 *  net.minecraft.class_2661
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockPosSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2561;
import net.minecraft.class_2661;

public class AutoPilot
extends AddonModule {
    private final SettingGroup sgGeneral;
    public final Setting<class_2338> coords;
    private final Setting<Boolean> disconnect;
    float yaw;

    public AutoPilot() {
        super(inertia.inertia, "AutoPilot", "Cursed go brrrr..");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.coords = this.sgGeneral.add((Setting)((BlockPosSetting.Builder)((BlockPosSetting.Builder)new BlockPosSetting.Builder().name("Coords")).description("Center of the sphere")).build());
        this.disconnect = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("disconnect")).description("Disconnect.")).defaultValue((Object)true)).build());
        this.yaw = 180.0f;
    }

    public void onDeactivate() {
        this.unpress();
    }

    @EventHandler
    private void onTick(TickEvent.Post e) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.mc.field_1724.method_24515().method_19771((class_2382)new class_2338(((class_2338)this.coords.get()).method_10263(), this.mc.field_1724.method_31478(), ((class_2338)this.coords.get()).method_10260()), 2.0)) {
            if (((Boolean)this.disconnect.get()).booleanValue()) {
                this.mc.field_1724.field_3944.method_52781(new class_2661((class_2561)class_2561.method_43470((String)"The player's coordinates have reached the specified ones.")));
                this.toggle();
            } else {
                this.unpress();
                this.toggle();
                return;
            }
        }
        class_2338 blockPos = new class_2338((class_2382)this.coords.get());
        double playerX = this.mc.field_1724.method_23317();
        double playerZ = this.mc.field_1724.method_23321();
        double deltaX = (double)blockPos.method_10263() + 0.5 - playerX;
        double deltaZ = (double)blockPos.method_10260() + 0.5 - playerZ;
        float yaw = (float)(Math.atan2(deltaZ, deltaX) * 57.29577951308232) - 90.0f;
        this.mc.field_1724.method_36456(yaw);
        this.mc.field_1690.field_1894.method_23481(true);
    }

    private void unpress() {
        this.mc.field_1690.field_1894.method_23481(false);
    }
}

