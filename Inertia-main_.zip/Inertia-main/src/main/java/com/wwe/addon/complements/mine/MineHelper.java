/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.wwe.addon.complements.mine.AutoBed
 *  com.wwe.addon.complements.mine.AutoFunnyCrystal
 *  com.wwe.addon.complements.mine.MineHelper$1
 *  it.unimi.dsi.fastutil.ints.Int2FloatOpenHashMap
 *  it.unimi.dsi.fastutil.ints.Int2IntMap
 *  it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap
 *  it.unimi.dsi.fastutil.objects.Object2BooleanMap
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Receive
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Sent
 *  meteordevelopment.meteorclient.events.render.Render2DEvent
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.renderer.ShapeMode
 *  meteordevelopment.meteorclient.renderer.text.TextRenderer
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.friends.Friends
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.systems.modules.Modules
 *  meteordevelopment.meteorclient.systems.modules.movement.Blink
 *  meteordevelopment.meteorclient.utils.entity.EntityUtils
 *  meteordevelopment.meteorclient.utils.entity.SortPriority
 *  meteordevelopment.meteorclient.utils.entity.Target
 *  meteordevelopment.meteorclient.utils.misc.Keybind
 *  meteordevelopment.meteorclient.utils.misc.Vec3
 *  meteordevelopment.meteorclient.utils.player.FindItemResult
 *  meteordevelopment.meteorclient.utils.player.InvUtils
 *  meteordevelopment.meteorclient.utils.player.PlayerUtils
 *  meteordevelopment.meteorclient.utils.player.Rotations
 *  meteordevelopment.meteorclient.utils.render.NametagUtils
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.meteorclient.utils.world.TickRate
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.class_1268
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1303
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1310
 *  net.minecraft.class_1322
 *  net.minecraft.class_1511
 *  net.minecraft.class_1542
 *  net.minecraft.class_1657
 *  net.minecraft.class_1665
 *  net.minecraft.class_1713
 *  net.minecraft.class_1743
 *  net.minecraft.class_1774
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1810
 *  net.minecraft.class_1829
 *  net.minecraft.class_1890
 *  net.minecraft.class_1934
 *  net.minecraft.class_1937
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2338$class_2339
 *  net.minecraft.class_2350
 *  net.minecraft.class_238
 *  net.minecraft.class_2382
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2604
 *  net.minecraft.class_2664
 *  net.minecraft.class_2680
 *  net.minecraft.class_2716
 *  net.minecraft.class_2739
 *  net.minecraft.class_2824
 *  net.minecraft.class_2828
 *  net.minecraft.class_2846
 *  net.minecraft.class_2846$class_2847
 *  net.minecraft.class_2868
 *  net.minecraft.class_2885
 *  net.minecraft.class_2886
 *  net.minecraft.class_2945$class_2946
 *  net.minecraft.class_3532
 *  net.minecraft.class_3965
 *  net.minecraft.class_5134
 *  org.jetbrains.annotations.Nullable
 *  venomhack.Venomhack420
 *  venomhack.enums.FacePlaceBreak
 *  venomhack.enums.Origin
 *  venomhack.enums.RenderShape
 *  venomhack.enums.SurroundBreak
 *  venomhack.enums.SwapMode
 *  venomhack.enums.SwitchMode
 *  venomhack.enums.Threading
 *  venomhack.enums.Type
 *  venomhack.mixinInterface.IBlink
 *  venomhack.mixinInterface.IVec3d
 *  venomhack.modules.misc.PacketMine
 *  venomhack.utils.AntiCheatHelper
 *  venomhack.utils.BlockUtils2
 *  venomhack.utils.CityUtils
 *  venomhack.utils.DamageCalcUtils
 *  venomhack.utils.PingUtils
 *  venomhack.utils.PlayerUtils2
 *  venomhack.utils.RandUtils
 *  venomhack.utils.TextUtils
 *  venomhack.utils.UtilsPlus
 *  venomhack.utils.customObjects.PlacementInfo
 *  venomhack.utils.customObjects.RenderBlock
 *  venomhack.utils.customObjects.Timer
 */
package com.wwe.addon.complements.mine;

import com.wwe.addon.complements.mine.MineHelper;
import it.unimi.dsi.fastutil.ints.Int2FloatOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2IntMap;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.movement.Blink;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.Target;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.Vec3;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.NametagUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1310;
import net.minecraft.class_1322;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1774;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1829;
import net.minecraft.class_1890;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2664;
import net.minecraft.class_2680;
import net.minecraft.class_2716;
import net.minecraft.class_2739;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_2945;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import org.jetbrains.annotations.Nullable;
import com.wwe.addon.inertia;
import com.wwe.addon.complements.mine.FacePlaceBreak;
import com.wwe.addon.complements.mine.Origin;
import com.wwe.addon.complements.mine.RenderShape;
import com.wwe.addon.complements.mine.SurroundBreak;
import com.wwe.addon.complements.mine.SwapMode;
import com.wwe.addon.complements.mine.SwitchMode;
import com.wwe.addon.complements.mine.Threading;
import com.wwe.addon.complements.mine.Type;
import com.wwe.addon.module.impl.PacketMine;
import com.wwe.addon.complements.mine.AntiCheatHelper;
import com.wwe.addon.complements.mine.BlockUtils2;
import com.wwe.addon.complements.mine.CityUtils;
import com.wwe.addon.complements.mine.DamageCalcUtils;
import com.wwe.addon.complements.mine.PingUtils;
import com.wwe.addon.complements.mine.PlayerUtils2;
import com.wwe.addon.complements.mine.RandUtils;
import com.wwe.addon.complements.mine.TextUtils;
import com.wwe.addon.complements.mine.UtilsPlus;
import com.wwe.addon.complements.mine.PlacementInfo;
import com.wwe.addon.complements.mine.RenderBlock;
import com.wwe.addon.complements.mine.Timer;

private class MineHelper
extends Module {
    private final SettingGroup sgBreak = this.group("Break");
    private final SettingGroup sgMisc = this.group("Misc");
    private final SettingGroup sgFacePlace = this.group("FacePlace");
    private final SettingGroup sgEnvironment = this.group("Environment");
    private final SettingGroup sgPause = this.group("Pause");
    private final SettingGroup sgTargeting = this.group("Target");
    private final SettingGroup sgSupport = this.group("Support");
    private final SettingGroup sgSwitch = this.group("Switch");
    private final SettingGroup sgAntiCheat = this.group("Anti Cheat");
    private final SettingGroup sgExperimental = this.group("Experimental");
    private final SettingGroup sgRender = this.group("Rendering");
    private final SettingGroup sgDebug = this.group("Debug");
    private final Setting<Origin> placeOrigin = this.setting("origin", "How to calculate ranges.", Origin.NCP, this.sgMisc);
    private final Setting<Boolean> sequential = this.setting("fast-timing", "Speeds up the ca at the cost of anti cheat compatibility.", false, this.sgMisc);
    private final Setting<Boolean> accurate = this.setting("accurate-damage", "Will slow down ca, while keeping the same lethality. Works best on low ping.", false, this.sgMisc);
    private final Setting<Type> antiFriendPop = this.setting("anti-friend-pop", "Avoids popping your friends.", Type.BOTH, this.sgMisc);
    private final Setting<Boolean> wallsRanges = this.setting("wall-ranges", "Enables walls range settings.", false, this.sgMisc);
    private final Setting<Boolean> oldMode = this.setting("1.12-mode", "Won't try to place in 1x1x1 holes.", false, this.sgMisc);
    private final Setting<Threading> threadMode = this.setting("thread-mode", "Will impact performance and can impact speed.", Threading.THREADED, this.sgMisc);
    private final Setting<Integer> placeDelay = this.setting("place-delay", "The amount of delay in ticks before placing.", 0, this.sgGeneral, 0.0, 10.0);
    private final Setting<Double> placeRange = this.setting("place-range", "The radius in which crystals can be placed.", 5.0, this.sgGeneral, 0.0, 6.0, 1);
    private final Setting<Double> placeWallsRange = this.setting("walls-range", "The radius in which crystals can be placed through walls.", 3.0, this.sgGeneral, () -> this.wallsRanges.get(), 0.0, 6.0, 1);
    private final Setting<Double> minPlaceDamage = this.setting("min-damage", "The minimum damage the crystal will place.", 6.0, this.sgGeneral, 0.0, 12.0, 1);
    private final Setting<Double> maxPlaceDamage = this.setting("max-damage", "The maximum self damage the crystal will place.", 4.0, this.sgGeneral, 0.0, 20.0, 1);
    private final Setting<Boolean> noSuicidePlace = this.setting("anti-suicide-place", "Will not place crystals that are lethal to yourself.", true, this.sgGeneral);
    private final Setting<Integer> breakDelay = this.setting("break-delay", "The amount of delay in ticks before breaking.", 0, this.sgBreak, 0.0, 10.0);
    private final Setting<Double> minBreakDamage = this.setting("min-damage", "The minimum damage for a crystal to get broken.", 3.0, this.sgBreak, 0.0, 12.0, 1);
    private final Setting<Double> maxBreakDamage = this.setting("max-self-damage", "The maximum self-damage allowed.", 4.0, this.sgBreak, 0.0, 20.0, 1);
    private final Setting<Double> breakRatio = this.setting("break-ratio", "The damage / self damage ratio at which to ignore the max self damage. Set to 0 to disable.", 0.0, this.sgBreak, null, 0.0, 5.0);
    private final Setting<Double> breakRange = this.setting("break-range", "The maximum range that crystals can be to be broken.", 5.0, this.sgBreak, 0.0, 6.0, 1);
    private final Setting<Double> breakWallsRange = this.setting("walls-range", "The maximum range that crystals can be to be broken through walls.", 3.0, this.sgBreak, () -> this.wallsRanges.get(), 0.0, 6.0, 1);
    private final Setting<Boolean> precision = this.setting("hit-boxes", "Increases range by considering the crystals hitboxes into range calculations.", false, this.sgBreak);
    private final Setting<Integer> breakAttempts = this.setting("break-attempts", "How many times to hit a crystal before stopping to target it.", 2, this.sgBreak, 1.0, 10.0);
    private final Setting<Integer> retryDelay = this.setting("retry-delay", "How many ticks to wait until you try to hit a crystal again that reached max break attempts.", 10, this.sgBreak, 0.0, 20.0);
    private final Setting<Boolean> inhibit = this.setting("no-unnecessary-breaks", "Will prevent unnecessary packets.", false, this.sgBreak);
    private final Setting<Integer> minAge = this.setting("min-age", "How many ticks a crystal has to exist in order to consider it.", 0, this.sgBreak, 0.0, 5.0);
    private final Setting<Boolean> noSuicideBreak = this.setting("anti-suicide-break", "Will not break crystals that are lethal to yourself.", true, this.sgBreak);
    private final Setting<Integer> maxBreaksPerSecond = this.setting("breaks-per-second", "How many crystals to attack per second at max.", 25, this.sgBreak, 0.0, 25.0);
    private final Setting<Boolean> facePlace = this.setting("face-place", "Will face-place when target is below a certain health or armor durability threshold.", true, this.sgFacePlace);
    private final Setting<FacePlaceBreak> facePlaceSpeedMode = this.setting("break-speed-mode", "Default uses the normal break speed, custom allows you to set a custom break delay.", FacePlaceBreak.DEFAULT, this.sgFacePlace, () -> this.facePlace.get());
    private final Setting<Integer> facePlaceSpeed = this.setting("break-speed", "The delay to wait before breaking faceplace crystals.", 5, this.sgFacePlace, () -> (Boolean)this.facePlace.get() != false && this.facePlaceSpeedMode.get() == FacePlaceBreak.CUSTOM, 0.0, 10.0);
    private final Setting<Integer> facePlaceHealth = this.setting("health", "The health the target has to be at to start faceplacing.", 12, this.sgFacePlace, () -> this.facePlace.get(), 0.0, 36.0);
    private final Setting<Integer> facePlaceDurability = this.setting("durability", "The durability threshold to be able to face-place.", 10, this.sgFacePlace, () -> this.facePlace.get(), 0.0, 100.0, 0, 100);
    private final Setting<Boolean> facePlaceSelf = this.setting("face-place-self", "Whether to faceplace when you are in the same hole as your target.", true, this.sgFacePlace, () -> this.facePlace.get());
    private final Setting<Boolean> facePlaceHole = this.setting("hole-fags", "Automatically starts faceplacing surrounded or burrowed targets.", false, this.sgFacePlace, () -> this.facePlace.get());
    private final Setting<Boolean> facePlaceArmor = this.setting("missing-armor", "Automatically starts faceplacing when a target misses a piece of armor.", true, this.sgFacePlace, () -> this.facePlace.get());
    private final Setting<Keybind> forceFacePlace = this.setting("force-face-place", "Starts faceplacing when this button is pressed", Keybind.fromKey((int)-1), this.sgFacePlace, () -> this.facePlace.get());
    private final Setting<Boolean> pauseSword = this.setting("pause-when-swording", "Doesn't faceplace when you are holding a sword.", true, this.sgFacePlace, () -> this.facePlace.get());
    private final Setting<Boolean> ignoreTerrain = this.setting("ignore-terrain", "Ignores non blast resistant blocks in damage calcs (useful during terrain pvp).", true, this.sgEnvironment);
    private final Setting<SurroundBreak> surroundBreak = this.setting("surround-break", "Places a crystal next to a surrounded player and keeps it there so they cannot use Surround again.", SurroundBreak.OFF, this.sgEnvironment);
    private final Setting<Keybind> forceSurroundBreak = this.setting("surround-break-key", "Will surround break when pressing this button.", Keybind.fromKey((int)-1), this.sgEnvironment, () -> this.surroundBreak.get() == SurroundBreak.KEYBIND);
    private final Setting<Boolean> antiSurroundBreak = this.setting("surround-protect", "Breaks crystals that could surround break you.", true, this.sgEnvironment);
    private final Setting<Boolean> antiCev = this.setting("anti-funny-crystal", "Breaks crystals that could funny crystal you.", true, this.sgEnvironment);
    private final Setting<Boolean> ccEntities = this.setting("cc-entities", "Crystals only check in a 1x1x1 for other entities, instead of 1x2x1.", false, this.sgEnvironment);
    private final Setting<Boolean> pauseBedAura = this.setting("auto-bed-compat", "Will pause while auto bed is working.", false, this.sgPause);
    private final Setting<Type> pauseMode = this.setting("pause-mode", "What to pause.", Type.NONE, this.sgPause);
    private final Setting<Boolean> pauseOnEat = this.setting("pause-on-eat", "Pauses Auto Crystal while eating.", false, this.sgPause, () -> this.pauseMode.get() != Type.NONE);
    private final Setting<Boolean> pauseOnMine = this.setting("pause-on-mine", "Pauses Auto Crystal while mining blocks.", false, this.sgPause, () -> this.pauseMode.get() != Type.NONE);
    private final Setting<Boolean> facePlacePause = this.setting("pause-face-placing", "When to interrupt face-placing.", false, this.sgPause, () -> this.pauseMode.get() != Type.NONE && (Boolean)this.facePlace.get() != false);
    private final Setting<Boolean> pauseFacePlaceCev = this.setting("fp-pause-on-funny-crystal", "Will stop face placing while auto funny crystal is active.", true, this.sgPause, () -> this.pauseMode.get() != Type.NONE && (Boolean)this.facePlacePause.get() != false && (Boolean)this.facePlace.get() != false);
    private final Setting<Boolean> facePlacePauseEat = this.setting("fp-pause-on-eat", "Pauses face placing while eating.", false, this.sgPause, () -> this.pauseMode.get() != Type.NONE && (Boolean)this.facePlacePause.get() != false && (Boolean)this.facePlace.get() != false);
    private final Setting<Boolean> facePlacePauseMine = this.setting("fp-pause-on-mine", "Pauses face placing while mining.", false, this.sgPause, () -> this.pauseMode.get() != Type.NONE && (Boolean)this.facePlacePause.get() != false && (Boolean)this.facePlace.get() != false);
    private final Setting<Object2BooleanMap<class_1299<?>>> entities = this.setting("entities", "The entities to attack.", this.sgTargeting, true, null, null, null, new class_1299[]{class_1299.field_6097});
    private final Setting<Boolean> ignoreNakeds = this.setting("ignore-nakeds", "Will not target naked players.", false, this.sgTargeting);
    private final Setting<Integer> targetRange = this.setting("target-range", "The maximum range the entity can be to be targeted.", 10, this.sgTargeting, 0.0, 18.0);
    private final Setting<Boolean> predict = this.setting("predict-movement", "Predicts the targets movement.", false, this.sgTargeting);
    private final Setting<Integer> predictTicks = this.setting("predict-ticks", "By how many ticks to advance the targets movement forward.", 0, this.sgTargeting, () -> this.predict.get(), 0.0, 4.0);
    private final Setting<Integer> antiStepOffset = this.setting("predict-anti-step-offset", "The maximum step height on the server.", 1, this.sgTargeting, () -> this.predict.get(), 1.0, 4.0);
    private final Setting<Boolean> netDamage = this.setting("total-damage", "Adds up the damage dealt to all targets to find the most efficient location.", false, this.sgTargeting);
    private final Setting<SortPriority> sortPriority = this.setting("target-mode", "Which target to target first.", SortPriority.LowestHealth, this.sgTargeting);
    private final Setting<Boolean> support = this.setting("support", "Places a block in the air and crystals on it. Helps with killing players that are flying.", false, this.sgSupport);
    private final Setting<Integer> supportDelay = this.setting("support-delay", "The delay between support blocks being placed.", 5, this.sgSupport, () -> this.support.get(), 0.0, 10.0);
    private final Setting<Boolean> supportBackup = this.setting("support-backup", "Makes it so support only works if there are no other options.", true, this.sgSupport, () -> this.support.get());
    private final Setting<Boolean> supportAirPlace = this.setting("airplace", "Whether to airplace the support block or not.", true, this.sgSupport, () -> this.support.get());
    private final Setting<Double> supportDamage = this.setting("support-min-damage", "Minimum damage to allow support (has to be higher than min place damage).", 10.0, this.sgSupport, () -> this.support.get(), 0.0, 36.0, 2);
    private final Setting<Boolean> antiWeakness = this.setting("anti-weakness", "Switches to tools to break crystals with to bypass weakness effect.", true, this.sgSwitch);
    private final Setting<SwitchMode> switchMode = this.setting("switch-mode", "How to switch items.", SwitchMode.NONE, this.sgSwitch);
    private final Setting<SwapMode> silentMode = this.setting("silent-mode", "New bypasses certain anti cheat configurations, but might cause desync.", SwapMode.OLD, this.sgSwitch, () -> this.switchMode.get() == SwitchMode.SILENT);
    private final Setting<Integer> switchHealth = this.setting("switch-health", "The health to stop switching to crystals.", 0, this.sgSwitch, () -> this.switchMode.get() != SwitchMode.NONE, 0.0, 36.0);
    private final Setting<Integer> afterSwitchBreakPause = this.setting("pause-breaking-after-switch.", "The amount of milliseconds to wait after switching slots before attempting to break crystals again.", 0, this.sgSwitch, 0.0, 500.0);
    private final Setting<Boolean> strictDirections = this.setting("strict-directions", "Places only on visible sides.", false, this.sgAntiCheat);
    private final Setting<Type> rotationMode = this.setting("rotation-mode", "The method of rotating when using Auto Crystal.", Type.NONE, this.sgAntiCheat);
    private final Setting<Integer> yawstep = this.setting("max-yawstep", "How far to rotate with each step.", 180, this.sgAntiCheat, () -> this.rotationMode.get() != Type.NONE, 1.0, 180.0, 1, 180);
    private final Setting<Boolean> strictLook = this.setting("strict-look", "Looks at exactly where you're placing.", false, this.sgAntiCheat, () -> ((Type)this.rotationMode.get()).placeTrue());
    private final Setting<Target> breakRotationMode = this.setting("break-rotation-target", "What part of the crystal to face before breaking.", Target.Head, this.sgAntiCheat, () -> ((Type)this.rotationMode.get()).breakTrue());
    private final Setting<Integer> delayBypass = this.setting("delay-bypass", "When below this break threshold ignore break delay. 3 works best for mpvp. Set to 0 to disable.", 0, this.sgExperimental, 0.0, 5.0);
    private final Setting<Boolean> idPredict = this.setting("crystal-predict", "Tries to speed up breaking.", false, this.sgExperimental);
    private final Setting<Boolean> aggressivePredict = this.setting("aggressive-predict", "Spams attacks in an attempt to increase speed even further.", false, this.sgExperimental, () -> this.idPredict.get());
    private final Setting<Boolean> instantPredict = this.setting("instant-predict", "Attempts to destroy the placed crystal right after spawning it in.", false, this.sgExperimental, () -> this.idPredict.get());
    private final Setting<Integer> minIdOffset = this.setting("min-id-offset", "Minimum id offset.", 3, this.sgExperimental, () -> this.idPredict.get(), 0.0, 10.0);
    private final Setting<Integer> maxIdOffset = this.setting("max-predict-ids", "How many ids to predict in advance max.", 5, this.sgExperimental, () -> this.idPredict.get(), 1.0, 10.0);
    private final Setting<Boolean> swing = this.setting("swing", "Renders your hand swing client-side.", true, this.sgRender);
    private final Setting<Boolean> render = this.setting("render", "Creates a render effect where you are placing.", true, this.sgRender);
    private final Setting<RenderShape> renderShape = this.setting("render-shape", "What shape mode to use.", RenderShape.CUBOID, this.sgRender, () -> this.render.get());
    private final Setting<ShapeMode> shapeMode = this.setting("shape-mode", "What part of the shapes to render.", ShapeMode.Both, this.sgRender, () -> this.render.get());
    private final Setting<Double> height = this.setting("height", "The height of the render.", 1.0, this.sgRender, () -> this.render.get(), 0.0, 2.0);
    private final Setting<Double> width = this.setting("width", "The width of the render.", 1.0, this.sgRender, () -> this.render.get(), 0.0, 2.0);
    private final Setting<Double> yOffset = this.setting("y-offset", "The height shift for the rendered shape.", 0.0, this.sgRender, () -> this.render.get(), 0.0, 1.0);
    private final Setting<Double> weirdOffset = this.setting("weird-offset", "Offset for the pyramid render shape.", 0.0, this.sgRender, () -> (Boolean)this.render.get() != false && this.renderShape.get() == RenderShape.CORNER_PYRAMIDS, -1.0, 1.0);
    private final Setting<Integer> renderTime = this.setting("render-time", "For how long a shape should be rendered.", 10, this.sgRender, () -> this.render.get(), 0.0, 20.0);
    private final Setting<Boolean> fade = this.setting("fade", "Will reduce the opacity of the rendered block over time.", true, this.sgRender, () -> this.render.get());
    private final Setting<Boolean> shrink = this.setting("shrink", "Will reduce the size of the renderer.", false, this.sgRender, () -> this.render.get());
    private final Setting<Boolean> slide = this.setting("slide", "Will make the render slide smoothly from one position to the next.", true, this.sgRender, () -> this.render.get());
    private final Setting<Integer> slideSpeed = this.setting("slide-speed", "How much of the difference between the last and new position the slider should progress each tick in percent.", 10, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.slide.get() != false, 1.0, 100.0);
    private final Setting<Integer> beforeFadeDelay = this.setting("before-fade-delay", "How long to wait before starting to fade. This value has to be smaller than your render time.", 5, this.sgRender, () -> (Boolean)this.render.get() != false && ((Boolean)this.fade.get() != false || (Boolean)this.shrink.get() != false), 0.0, 10.0);
    private final Setting<Integer> maxBlocks = this.setting("max-render-blocks", "How many blocks to be rendered at once max.", 1, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.slide.get() == false, 1.0, 10.0);
    private final Setting<SettingColor> sideColor = this.setting("side-color", "The side color.", 255, 0, 0, 75, true, this.sgRender, () -> (Boolean)this.render.get() != false && ((ShapeMode)this.shapeMode.get()).sides());
    private final Setting<SettingColor> lineColor = this.setting("line-color", "The line color.", 255, 0, 0, 200, true, this.sgRender, () -> (Boolean)this.render.get() != false && ((ShapeMode)this.shapeMode.get()).lines());
    private final Setting<Boolean> renderDamage = this.setting("render-damage", "Renders the damage of the crystal where it is placing.", true, this.sgRender, () -> this.render.get());
    private final Setting<Boolean> renderSelfDamage = this.setting("render-self-damage", "Renders the damage the crystal is dealing to yourself.", false, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.renderDamage.get() != false);
    private final Setting<Integer> damageRenderTime = this.setting("damage-render-time", "For how long the damage text should be rendered.", 10, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.renderDamage.get() != false, 0.0, 20.0);
    private final Setting<Integer> roundDamage = this.setting("round-damage", "Round damage to x decimal places.", 2, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.renderDamage.get() != false, 0.0, 3.0);
    private final Setting<Double> damageScale = this.setting("damage-scale", "The scale of the damage text.", 1.4, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.renderDamage.get() != false, 0.0, 5.0, 1);
    private final Setting<SettingColor> damageColor = this.setting("damage-color", "The color of the damage text.", 255, 255, 255, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.renderDamage.get() != false);
    private final Setting<SettingColor> selfDamageColor = this.setting("self-damage-color", "The color of the self damage text.", 255, 0, 0, this.sgRender, () -> (Boolean)this.render.get() != false && (Boolean)this.renderDamage.get() != false && (Boolean)this.renderSelfDamage.get() != false);
    private final Setting<Boolean> debug = this.setting("debug", "debug", false, this.sgDebug);
    private final Setting<Boolean> debugFailedPlace = this.setting("failed-placement", "debug", false, this.sgDebug, () -> this.debug.get());
    private final Setting<Boolean> debugActualDamage = this.setting("actual-damage", "debug", false, this.sgDebug, () -> this.debug.get());
    private final Setting<Boolean> debugPlaceDirection = this.setting("interact-direction", "debug", false, this.sgDebug, () -> this.debug.get());
    private final Setting<Boolean> debugAttackedId = this.setting("attacked-id", "debug", false, this.sgDebug, () -> this.debug.get());
    private final Setting<Boolean> debugIsPop = this.setting("is-pop", "debug", false, this.sgDebug, () -> this.debug.get());
    private volatile int lastId;
    private float serverYaw;
    private boolean weak;
    private boolean hasRotatedThisTick;
    private short breaks;
    private short places;
    private class_243 playerPos;
    private class_243 rotationTarget;
    private class_2338 lastBlock;
    private class_1309 lastPlaceTarget;
    private final Timer breakTimer = new Timer();
    private final Timer switchTimer = new Timer();
    private final Timer sinceLastActionTimer = new Timer();
    private int placeDelayLeft;
    private int breakDelayLeft;
    private int supportDelayLeft;
    private int retryDelayLeft;
    private int lastPredictedId;
    private int ticksSinceLastBreak;
    private int antiWeaknessSlot;
    private final List<RenderBlock> renderBlocks = Collections.synchronizedList(new ArrayList());
    private final List<class_1657> friends = Collections.synchronizedList(new ArrayList());
    private final List<class_1309> targets = new CopyOnWriteArrayList<class_1309>();
    private final Int2FloatOpenHashMap lastTakenDamages = new Int2FloatOpenHashMap();
    private final Int2IntMap attemptedBreaks = new Int2IntOpenHashMap();
    private final Map<Integer, Long> crystalsToRemove = new ConcurrentHashMap<Integer, Long>();
    private final Map<Integer, Long> crystalAliveMap = new ConcurrentHashMap<Integer, Long>();
    private final Map<class_2338, Long> pendingPlacements = new ConcurrentHashMap<class_2338, Long>();
    private ExecutorService executor;
    private float slideProgress = 0.0f;

    public MineHelper() {
        super(inertia.inertia, "MineHelper", "Automatically places and breaks crystals to damage other players.");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler(priority=1000)
    private void onTick(TickEvent.Pre event) {
        List<RenderBlock> list = this.renderBlocks;
        synchronized (list) {
            for (RenderBlock block2 : this.renderBlocks) {
                block2.ticks -= 1.0f;
                if (!(block2.ticks <= 0.0f)) continue;
                this.slideProgress = 0.0f;
            }
            this.renderBlocks.removeIf(block -> block.ticks <= 0.0f);
        }
        this.hasRotatedThisTick = false;
        --this.supportDelayLeft;
        --this.retryDelayLeft;
        ++this.ticksSinceLastBreak;
        if (this.retryDelayLeft == 0) {
            this.attemptedBreaks.clear();
        }
        this.handleHurtTime();
        if (PlayerUtils.getGameMode() == class_1934.field_9219) {
            return;
        }
        this.playerPos = this.mc.field_1724.method_19538();
        if (Modules.get().isActive(Blink.class)) {
            this.playerPos = this.mc.field_1724.method_19538();
        }
        PlayerUtils2.collectTargets(this.targets, this.friends, (int)((Integer)this.targetRange.get()), (int)Integer.MAX_VALUE, (boolean)((Boolean)this.ignoreNakeds.get()), (boolean)false, (boolean)((Boolean)this.ignoreTerrain.get()), (SortPriority)((SortPriority)this.sortPriority.get()), (Object2BooleanMap)((Object2BooleanMap)this.entities.get()));
        if (this.targets.isEmpty()) {
            this.rotationTarget = null;
            return;
        }
        if (((Boolean)this.pauseBedAura.get()).booleanValue() && isExternalModuleActive("AutoBed")) {
            return;
        }
        if (!(((Boolean)this.pauseBedAura.get()).booleanValue() && isExternalModuleActive("AutoBed") || this.breakDelayLeft >= 1 && ((Integer)this.delayBypass.get() == 0 || this.breaks >= (Integer)this.delayBypass.get()) || this.pauseBreak())) {
            this.doBreak();
        } else {
            --this.breakDelayLeft;
        }
        if (this.placeDelayLeft < 1) {
            if (this.canPlace()) {
                if (this.threadMode.get() == Threading.THREADED && !this.executor.isShutdown() && !this.executor.isTerminated()) {
                    this.executor.submit(this::doPlace);
                } else {
                    this.doPlace();
                }
            } else {
                this.places = 0;
            }
        } else {
            --this.placeDelayLeft;
        }
    }

    @EventHandler(priority=-2147483648)
    private void lateTick(TickEvent.Pre event) {
        if (this.rotationTarget == null || this.hasRotatedThisTick) {
            return;
        }
        if (this.rotationMode.get() == Type.NONE || (Integer)this.yawstep.get() == 180) {
            return;
        }
        double targetYaw = Rotations.getYaw((class_243)this.rotationTarget);
        if (MineHelper.distanceBetweenAngles(this.serverYaw, targetYaw) <= (double)((Integer)this.yawstep.get()).intValue()) {
            Rotations.rotate((double)targetYaw, (double)Rotations.getPitch((class_243)this.rotationTarget));
            this.rotationTarget = null;
        } else {
            targetYaw = class_3532.method_15338((double)targetYaw) + 180.0;
            float serverYaw = class_3532.method_15393((float)this.serverYaw) + 180.0f;
            double delta = Math.abs(targetYaw - (double)serverYaw);
            float yaw = this.serverYaw;
            yaw = (double)serverYaw < targetYaw ? (delta < 180.0 ? (yaw += (float)((Integer)this.yawstep.get()).intValue()) : (yaw -= (float)((Integer)this.yawstep.get()).intValue())) : (delta < 180.0 ? (yaw -= (float)((Integer)this.yawstep.get()).intValue()) : (yaw += (float)((Integer)this.yawstep.get()).intValue()));
            Rotations.rotate((double)yaw, (double)Rotations.getPitch((class_243)this.rotationTarget));
        }
    }

    private boolean validRotation(class_243 target) {
        return MineHelper.distanceBetweenAngles(this.serverYaw, Rotations.getYaw((class_243)target)) <= (double)((Integer)this.yawstep.get()).intValue();
    }

    private static double distanceBetweenAngles(double alpha, double beta) {
        double phi = Math.abs(class_3532.method_15338((double)beta) - class_3532.method_15338((double)alpha)) % 360.0;
        return phi > 180.0 ? 360.0 - phi : phi;
    }

    @EventHandler(priority=0x7FFFFFFF)
    private void onPacketRecieve(PacketEvent.Receive event) {
        if (this.playerPos == null) {
            return;
        }
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (this.breakTimer.millisPassed() >= 1000L) {
            this.breaks = 0;
        }
        if (this.breaks == 0) {
            this.breakTimer.reset();
        }
        if ((double)TickRate.INSTANCE.getTimeSinceLastTick() < 1.5) {
            long considerDeadTime = (long)((float)this.getPing() * 20.0f / TickRate.INSTANCE.getTickRate());
            for (Map.Entry<Integer, Long> entry : this.crystalsToRemove.entrySet()) {
                if (System.currentTimeMillis() - considerDeadTime <= entry.getValue()) continue;
                this.crystalsToRemove.remove(entry.getKey());
            }
            for (Map.Entry<Integer, Long> entry : this.pendingPlacements.entrySet()) {
                if (System.currentTimeMillis() - considerDeadTime <= entry.getValue()) continue;
                if (((Boolean)this.debug.get()).booleanValue() && ((Boolean)this.debugFailedPlace.get()).booleanValue()) {
                    this.info("failed placement. distance: " + class_243.method_24953((class_2382)((class_2382)entry.getKey())).method_1022(PlayerUtils2.eyePos((class_1657)this.mc.field_1724)), new Object[0]);
                }
                this.pendingPlacements.remove(entry.getKey());
            }
        } else {
            this.attemptedBreaks.clear();
            this.crystalsToRemove.clear();
        }
        class_2596 class_25962 = event.packet;
        if (class_25962 instanceof class_2604) {
            class_2604 packet = (class_2604)class_25962;
            if (packet.method_11167() > this.lastId) {
                this.lastId = packet.method_11167();
            }
            this.crystalAliveMap.put(packet.method_11167(), System.currentTimeMillis());
            if (packet.method_11169() != class_1299.field_6110) {
                return;
            }
            crystal = new class_1511((class_1937)this.mc.field_1687, packet.method_11175(), packet.method_11174(), packet.method_11176());
            crystal.method_5838(packet.method_11167());
            this.pendingPlacements.remove(crystal.method_24515().method_10074());
            if ((Integer)this.minAge.get() > 0) {
                return;
            }
            if (this.breakDelayLeft > 0 && ((Integer)this.delayBypass.get() == 0 || this.breaks >= (Integer)this.delayBypass.get())) {
                return;
            }
            if (this.pauseBreak()) {
                return;
            }
            if (this.shouldNotBreak((class_1511)crystal, (Boolean)this.inhibit.get(), true)) {
                return;
            }
            for (class_1309 target : this.targets) {
                if (target.method_29504() || crystal.method_5739((class_1297)target) > 9.0f) continue;
                float damage = this.applyHurtTimeToDamage(target, DamageCalcUtils.explosionDamage((class_1309)target, (class_243)crystal.method_19538(), (boolean)((Boolean)this.predict.get()), (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)false, (boolean)true, (int)6), false, false);
                if ((double)damage < (this.shouldFacePlace(target) ? 1.5 : (Double)this.minBreakDamage.get())) continue;
                if (this.unsafeBreak((class_1309)this.mc.field_1724, crystal.method_19538(), damage)) {
                    return;
                }
                if (((Type)this.antiFriendPop.get()).breakTrue()) {
                    for (class_1657 friend : this.friends) {
                        if (!this.unsafeBreak((class_1309)friend, crystal.method_19538(), damage)) continue;
                        return;
                    }
                }
                this.doAttack((class_1511)crystal, false, null);
                return;
            }
        } else {
            crystal = event.packet;
            if (crystal instanceof class_2664) {
                class_2664 packet = (class_2664)crystal;
                pos = new class_243(packet.method_11475(), packet.method_11477(), packet.method_11478());
                for (class_1297 entity : this.mc.field_1687.method_18112()) {
                    if (!(entity instanceof class_1511) || entity.method_5707((class_243)pos) > Math.pow(packet.method_11476() * 2.0f, 2.0)) continue;
                    this.crystalsToRemove.put(entity.method_5628(), System.currentTimeMillis());
                }
            } else {
                pos = event.packet;
                if (pos instanceof class_2716) {
                    class_2716 packet = (class_2716)pos;
                    pos = packet.method_36548().iterator();
                    while (pos.hasNext()) {
                        int id = (Integer)pos.next();
                        if (id > this.lastId) {
                            this.lastId = id;
                        }
                        this.crystalAliveMap.remove(id);
                        this.attemptedBreaks.remove(id);
                    }
                } else {
                    pos = event.packet;
                    if (pos instanceof class_2739) {
                        class_1309 living;
                        class_2739 class_27392 = (class_2739)pos;
                        if (class_27392.method_11807() > this.lastId) {
                            this.lastId = class_27392.method_11807();
                        }
                        if (class_27392.method_11809() == null) {
                            return;
                        }
                        try {
                            class_1297 entity = this.mc.field_1687.method_8469(class_27392.method_11807());
                            if (!(entity instanceof class_1309)) {
                                return;
                            }
                            class_1309 livingEntity = (class_1309)entity;
                            living = livingEntity;
                        }
                        catch (ArrayIndexOutOfBoundsException ignored) {
                            return;
                        }
                        float healthDelta = 0.0f;
                        float absorbtionDelta = 0.0f;
                        for (class_2945.class_2946 entry : class_27392.method_11809()) {
                            if (entry.method_12797() == class_1657.field_7491) {
                                absorbtionDelta = living.method_6067() - ((Float)entry.method_12794()).floatValue();
                            }
                            if (entry.method_12797() != class_1309.field_6247) continue;
                            healthDelta = living.method_6032() - ((Float)entry.method_12794()).floatValue();
                        }
                        if (healthDelta + absorbtionDelta > 0.0f) {
                            if (((Boolean)this.debug.get()).booleanValue() && ((Boolean)this.debugActualDamage.get()).booleanValue()) {
                                this.info("actual damage: " + TextUtils.round((float)(healthDelta + absorbtionDelta), (int)4), new Object[0]);
                            }
                            if ((long)living.field_6008 - Math.round((double)this.getPing() / 50.0) > 10L) {
                                this.lastTakenDamages.put(class_27392.method_11807(), this.lastTakenDamages.getOrDefault(class_27392.method_11807(), 0.0f) + healthDelta + absorbtionDelta);
                            } else {
                                this.lastTakenDamages.put(class_27392.method_11807(), healthDelta + absorbtionDelta);
                            }
                        }
                    }
                }
            }
        }
    }

    public void doFacePlaceCity(class_2338 pos) {
        if (this.breakDelayLeft > 0 && ((Integer)this.delayBypass.get() == 0 || this.breaks >= (Integer)this.delayBypass.get())) {
            return;
        }
        class_2338 up = pos.method_10084();
        List entities = this.mc.field_1687.method_8333(null, new class_238(up), entity -> {
            class_1511 crystal;
            return entity instanceof class_1511 && !this.shouldNotBreak(crystal = (class_1511)entity, (Boolean)this.inhibit.get(), true) && entity.method_24515().equals((Object)up);
        }).stream().map(entity -> (class_1511)entity).toList();
        if (entities.isEmpty()) {
            return;
        }
        class_1511 crystal = (class_1511)entities.get(0);
        boolean notSurround = true;
        for (class_1309 target : this.targets) {
            if (!BlockUtils2.getCity((class_1309)target, (boolean)false, (boolean)true).contains(pos)) continue;
            notSurround = false;
            break;
        }
        if (notSurround) {
            return;
        }
        PlacementInfo replace = new PlacementInfo(pos.method_10074());
        if (this.placeDelayLeft > 0 || this.invalidPlace(replace.getBlockPos(), this.mc.field_1687.method_8320(replace.getBlockPos()), false, replace, crystal.method_5628(), null, true)) {
            replace = null;
        }
        this.doAttack(crystal, false, replace);
    }

    private float applyHurtTimeToDamage(class_1309 entity, float damage, boolean placing, boolean force) {
        block6: {
            block7: {
                if (this.getPing() == 0) {
                    return damage;
                }
                if (force || ((Boolean)this.accurate.get()).booleanValue() || entity == this.mc.field_1724) break block6;
                if (!(entity instanceof class_1657)) break block7;
                class_1657 player = (class_1657)entity;
                if (!Friends.get().shouldAttack(player)) break block6;
            }
            return damage;
        }
        if ((long)entity.field_6008 - Math.round((double)(this.getPing() * (placing ? 3 : 2)) / 50.0) > 10L) {
            float adjustedSelfDamage = damage - this.lastTakenDamages.getOrDefault(entity.method_5628(), 0.0f);
            if (adjustedSelfDamage < 0.0f) {
                adjustedSelfDamage = 0.0f;
            }
            return adjustedSelfDamage;
        }
        return damage;
    }

    private boolean canPlace() {
        if (((Type)this.pauseMode.get()).placeTrue() && PlayerUtils.shouldPause((boolean)((Boolean)this.pauseOnMine.get()), (boolean)((Boolean)this.pauseOnEat.get()), (boolean)((Boolean)this.pauseOnEat.get()))) {
            return false;
        }
        if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301 && this.mc.field_1724.method_6079().method_7909() != class_1802.field_8301) {
            if (this.switchMode.get() == SwitchMode.NONE) {
                return false;
            }
            if (PlayerUtils.getTotalHealth() <= (double)((Integer)this.switchHealth.get()).intValue()) {
                return false;
            }
            return this.switchMode.get() == SwitchMode.SILENT && this.silentMode.get() == SwapMode.NEW ? InvUtils.find((class_1792[])new class_1792[]{class_1802.field_8301}).found() : InvUtils.find(item -> item.method_7909() instanceof class_1774, (int)0, (int)8).found();
        }
        return this.placeDelayLeft <= 0;
    }

    private void doPlace() {
        PlacementInfo bestPlace = new PlacementInfo();
        boolean canSupport = (Boolean)this.support.get() != false && this.supportDelayLeft < 1 && InvUtils.findInHotbar((class_1792[])new class_1792[]{class_1802.field_8281}).found();
        class_243 playerPos = this.mc.field_1724.method_19538();
        if (this.placeOrigin.get() == Origin.NCP) {
            playerPos = PlayerUtils2.eyePos((class_1657)this.mc.field_1724);
        }
        int range = (int)Math.ceil((Double)this.placeRange.get()) + 1;
        class_2338.class_2339 blockPos = new class_2338.class_2339();
        class_243 crystalVec = new class_243(0.0, 0.0, 0.0);
        for (int x = -range; x <= range; ++x) {
            for (int y = -range; y <= range; ++y) {
                for (int z = -range; z <= range; ++z) {
                    blockPos.method_10102(playerPos.field_1352 + (double)x, playerPos.field_1351 + (double)y, playerPos.field_1350 + (double)z);
                    class_2680 blockState = this.mc.field_1687.method_8320((class_2338)blockPos);
                    PlacementInfo place = new PlacementInfo((class_2338)blockPos);
                    if (this.invalidPlace((class_2338)blockPos, blockState, canSupport, place, 0, bestPlace, false)) continue;
                    float totalDamage = 0.0f;
                    boolean facePlaceLimit = false;
                    boolean foundPos = false;
                    crystalVec = new class_243((double)blockPos.method_10263() + 0.5, (double)(blockPos.method_10264() + 1), (double)blockPos.method_10260() + 0.5);
                    block8: for (class_1309 target : this.targets) {
                        if (target.method_29504() || bestPlace.getBlockPos() != null && DamageCalcUtils.explosionDamage((class_1309)target, (class_243)crystalVec, (boolean)((Boolean)this.predict.get()), (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)true, (boolean)true, (boolean)false, (int)6) < bestPlace.getDamage()) continue;
                        float damage = this.applyHurtTimeToDamage(target, DamageCalcUtils.explosionDamage((class_1309)target, (class_243)crystalVec, (boolean)((Boolean)this.predict.get()), (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)true, (boolean)true, (int)6), true, false);
                        totalDamage += damage;
                        if ((Boolean)this.accurate.get() == false && (double)this.applyHurtTimeToDamage(target, damage, true, true) > (double)UtilsPlus.getTotalHealth((class_1309)target) + 0.5 || ((Boolean)this.accurate.get()).booleanValue() && (double)damage > (double)UtilsPlus.getTotalHealth((class_1309)target) + 0.5) {
                            place.incrementPops();
                        }
                        place.reset(target, damage);
                        if (blockPos.method_10264() > target.method_31478() || place.isSupport() && (double)damage < (Double)this.supportDamage.get() || !((Boolean)this.netDamage.get()).booleanValue() && bestPlace.getSurroundBreak() == 0 && place.value(this.lastPlaceTarget) < bestPlace.value(this.lastPlaceTarget) && (!canSupport || !((Boolean)this.supportBackup.get()).booleanValue() || !bestPlace.isSupport() || place.isSupport())) continue;
                        if (!facePlaceLimit && this.shouldFacePlace(target)) {
                            place.setFaceplace(true);
                        }
                        float minDamage = place.isFaceplace() ? 1.5f : ((Double)this.minPlaceDamage.get()).floatValue();
                        block9: for (class_1297 entity : this.mc.field_1687.method_18112()) {
                            double distance;
                            if (!(entity instanceof class_1511)) continue;
                            class_1511 crystal = (class_1511)entity;
                            if (this.mc.field_1724.field_6281 == 0.0f && this.mc.field_1724.field_6250 == 0.0f || !(crystal.method_19538().method_1028(playerPos.field_1352 + this.mc.field_1724.method_23317() - this.mc.field_1724.field_6014, playerPos.field_1351 + this.mc.field_1724.method_23318() - this.mc.field_1724.field_6036, playerPos.field_1350 + this.mc.field_1724.method_23321() - this.mc.field_1724.field_5969) < crystal.method_19538().method_1025(playerPos)) ? this.shouldNotBreak(crystal, true, true) : this.shouldNotBreak(crystal, true, false) || (distance = Math.sqrt(playerPos.method_1028(crystal.method_23317(), crystal.method_23318() - 0.5, crystal.method_23321()))) >= 8.0 || (distance = Math.sqrt(((Origin)this.placeOrigin.get()).getOrigin(playerPos).method_1028(crystal.method_23317(), crystal.method_23318() - 0.5, crystal.method_23321()))) > (Double)this.placeRange.get() || (Boolean)this.wallsRanges.get() != false && distance > (Double)this.placeWallsRange.get() && !UtilsPlus.canSeeBlock((class_2338)blockPos, (class_243)((Origin)this.placeOrigin.get()).getOrigin(playerPos))) continue;
                            float multiDamage = this.applyHurtTimeToDamage(target, DamageCalcUtils.explosionDamage((class_1309)target, (class_243)crystal.method_19538(), (boolean)((Boolean)this.predict.get()), (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)false, (boolean)true, (int)6), false, false);
                            if (multiDamage < minDamage || this.unsafeBreak((class_1309)this.mc.field_1724, crystal.method_19538(), multiDamage)) continue;
                            if (((Type)this.antiFriendPop.get()).breakTrue()) {
                                for (class_1657 friend : this.friends) {
                                    if (!this.unsafeBreak((class_1309)friend, crystal.method_19538(), multiDamage)) continue;
                                    continue block9;
                                }
                            }
                            return;
                        }
                        if (damage < minDamage) {
                            switch (1.$SwitchMap$venomhack$enums$SurroundBreak[((SurroundBreak)this.surroundBreak.get()).ordinal()]) {
                                case 1: {
                                    continue block8;
                                }
                                case 2: {
                                    if (!(this.mc.field_1724.method_6047().method_7909() instanceof class_1810)) continue block8;
                                    break;
                                }
                                case 3: {
                                    if (((Keybind)this.forceSurroundBreak.get()).isPressed() && this.mc.field_1755 == null) break;
                                    continue block8;
                                }
                            }
                            if (bestPlace.getBlockPos() != null && bestPlace.getSurroundBreak() == 0 || isExternalModuleActive("AutoFunnyCrystal") || !UtilsPlus.isSurrounded((class_1309)target, (boolean)true, (boolean)((Boolean)this.ignoreTerrain.get()))) continue;
                            for (int i = 0; i < this.targets.indexOf(target) + 1; ++i) {
                                if (UtilsPlus.isSurroundBroken((class_1309)this.targets.get(i))) continue block8;
                            }
                            byte breakValue = UtilsPlus.getSurroundBreak((class_1309)target, (class_2338)blockPos);
                            if (bestPlace.getSurroundBreak() >= breakValue) continue;
                            place.setSurroundBreak(breakValue);
                        }
                        foundPos = true;
                        if (((Boolean)this.netDamage.get()).booleanValue()) continue;
                        if (place.isFaceplace()) {
                            facePlaceLimit = true;
                        }
                        bestPlace.copy(place);
                    }
                    if (!((Boolean)this.netDamage.get()).booleanValue() || !foundPos) continue;
                    place.setDamage(totalDamage);
                    if (!(place.value(this.lastPlaceTarget) > bestPlace.value(this.lastPlaceTarget)) && (!((Boolean)this.supportBackup.get()).booleanValue() || !bestPlace.isSupport() || place.isSupport())) continue;
                    bestPlace.copy(place);
                }
            }
        }
        if (bestPlace.getBlockPos() != null) {
            this.place(bestPlace, ((Type)this.rotationMode.get()).placeTrue());
        }
    }

    private class_2680 getState(class_2338 pos) {
        return ((PacketMine)Modules.get().get(PacketMine.class)).getState(pos);
    }

    private boolean invalidPlace(class_2338 blockPos, class_2680 blockState, boolean canSupport, PlacementInfo place, int idToIgnore, @Nullable PlacementInfo bestPlace, boolean upStateGotMined) {
        boolean movingTowardsCrystal;
        class_2680 upState;
        if (BlockUtils2.invalidPos((class_2338)blockPos)) {
            return true;
        }
        if (!(this.pendingPlacements.isEmpty() || this.pendingPlacements.size() <= 1 && this.pendingPlacements.get(blockPos) != null)) {
            return true;
        }
        class_243 pos = class_243.method_24953((class_2382)blockPos);
        if (!upStateGotMined && !(upState = this.getState(blockPos.method_10084())).method_26215()) {
            if (upState.method_26204().method_36555() != 0.0f) {
                return true;
            }
            place.setShouldBreak(true);
        }
        if (((Boolean)this.oldMode.get()).booleanValue() && !this.getState(blockPos.method_10086(2)).method_26215()) {
            return true;
        }
        if (blockState.method_26204() != class_2246.field_9987 && blockState.method_26204() != class_2246.field_10540) {
            if (!canSupport) {
                return true;
            }
            if (((Boolean)this.supportBackup.get()).booleanValue() && bestPlace != null && bestPlace.getPos() != null && !bestPlace.isSupport()) {
                return true;
            }
            if (!blockState.method_26207().method_15800()) {
                return true;
            }
            if (!((Boolean)this.supportAirPlace.get()).booleanValue() && BlockUtils2.noSupport((class_2338)blockPos)) {
                return true;
            }
            place.setSupport(true);
        }
        class_2350 dir = BlockUtils2.getClosestDirection((class_2338)blockPos, (boolean)false);
        if (((Boolean)this.strictDirections.get()).booleanValue() && (dir = BlockUtils2.getStrictSide((class_2338)blockPos)) == null) {
            return true;
        }
        place.setDirection(dir);
        pos = pos.method_1031((double)dir.method_10163().method_10263() * 0.5, (double)dir.method_10163().method_10264() * 0.5, (double)dir.method_10163().method_10260() * 0.5);
        place.setVec3d(pos);
        if (BlockUtils2.outOfPlaceRange((class_2338)blockPos, (Origin)((Origin)this.placeOrigin.get()), (double)((Double)this.placeRange.get()))) {
            return true;
        }
        if (((Boolean)this.wallsRanges.get()).booleanValue() && BlockUtils2.outOfPlaceRange((class_2338)blockPos, (Origin)((Origin)this.placeOrigin.get()), (double)((Double)this.placeWallsRange.get())) && !UtilsPlus.canSeeBlock((class_2338)blockPos, (class_243)PlayerUtils2.eyePos((class_1657)this.mc.field_1724))) {
            return true;
        }
        class_1511 crystal = new class_1511((class_1937)this.mc.field_1687, (double)blockPos.method_10263() + 0.5, (double)(blockPos.method_10264() + 1), (double)blockPos.method_10260() + 0.5);
        boolean bl = movingTowardsCrystal = (this.mc.field_1724.field_6281 != 0.0f || this.mc.field_1724.field_6250 != 0.0f) && crystal.method_19538().method_1028(this.playerPos.field_1352 + this.mc.field_1724.method_23317() - this.mc.field_1724.field_6014, this.playerPos.field_1351 + this.mc.field_1724.method_23318() - this.mc.field_1724.field_6036, this.playerPos.field_1350 + this.mc.field_1724.method_23321() - this.mc.field_1724.field_5969) < crystal.method_19538().method_1025(this.playerPos);
        if (!movingTowardsCrystal && this.notInBreakRange(crystal)) {
            return true;
        }
        if (this.intersectsWithEntity(blockPos, place.isSupport(), idToIgnore)) {
            return true;
        }
        float selfDamage = this.applyHurtTimeToDamage((class_1309)this.mc.field_1724, DamageCalcUtils.explosionDamage((class_1309)this.mc.field_1724, (class_243)crystal.method_19538(), (boolean)false, (int)0, (int)0, (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)true, (boolean)true, (int)6), false, false);
        place.setSelfDamage(selfDamage);
        if ((double)selfDamage > (Double)this.maxPlaceDamage.get()) {
            return true;
        }
        if ((double)(EntityUtils.getTotalHealth((class_1657)this.mc.field_1724) - selfDamage) < 0.5) {
            if (((Boolean)this.noSuicidePlace.get()).booleanValue()) {
                return true;
            }
            place.setSelfPop();
        }
        if (((Type)this.antiFriendPop.get()).placeTrue()) {
            for (class_1657 friend : this.friends) {
                float friendDamage = this.applyHurtTimeToDamage((class_1309)friend, DamageCalcUtils.explosionDamage((class_1309)friend, (class_243)crystal.method_19538(), (boolean)((Boolean)this.predict.get()), (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)true, (boolean)true, (int)6), true, false);
                if ((double)friendDamage > (Double)this.maxPlaceDamage.get()) {
                    return true;
                }
                if ((double)(EntityUtils.getTotalHealth((class_1657)friend) - friendDamage) < 0.5) {
                    if (((Boolean)this.noSuicidePlace.get()).booleanValue()) {
                        return true;
                    }
                    place.incrementFriendPops();
                }
                place.addFriendDamage(friendDamage);
            }
        }
        return false;
    }

    private void place(PlacementInfo place, boolean rotate) {
        if (rotate) {
            class_243 vec = place.getPos();
            if (((Boolean)this.strictLook.get()).booleanValue()) {
                vec = class_243.method_24953((class_2382)place.getBlockPos());
            }
            if (!this.hasRotatedThisTick && ((Integer)this.yawstep.get() == 180 || this.validRotation(place.getPos()))) {
                Rotations.rotate((double)Rotations.getYaw((class_243)vec), (double)Rotations.getPitch((class_243)vec), (int)85, () -> this.place(place, false));
                this.hasRotatedThisTick = true;
            } else if (this.rotationTarget == null) {
                this.rotationTarget = place.getPos();
            }
            return;
        }
        class_3965 result = new class_3965(place.getPos(), place.getDirection(), place.getBlockPos(), false);
        if (place.isSupport()) {
            BlockUtils2.justPlace((FindItemResult)InvUtils.findInHotbar((class_1792[])new class_1792[]{class_1802.field_8281}), (class_3965)result, (boolean)((Boolean)this.swing.get()), (boolean)((Type)this.rotationMode.get()).placeTrue(), (int)45);
            this.supportDelayLeft = (Integer)this.supportDelay.get();
        }
        if (place.shouldBreak()) {
            this.mc.field_1724.field_3944.method_2883((class_2596)new class_2846(class_2846.class_2847.field_12968, place.getBlockPos().method_10084(), class_2350.field_11033));
            this.mc.field_1724.field_3944.method_2883((class_2596)new class_2846(class_2846.class_2847.field_12973, place.getBlockPos().method_10084(), class_2350.field_11033));
        }
        int preSlot = -1;
        if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301 && this.mc.field_1724.method_6079().method_7909() != class_1802.field_8301) {
            int slot;
            preSlot = this.mc.field_1724.method_31548().field_7545;
            int n = slot = this.switchMode.get() == SwitchMode.SILENT && this.silentMode.get() == SwapMode.NEW ? InvUtils.find((class_1792[])new class_1792[]{class_1802.field_8301}).slot() : InvUtils.find(item -> item.method_7909() instanceof class_1774, (int)0, (int)8).slot();
            if (slot == -1) {
                return;
            }
            if (this.switchMode.get() == SwitchMode.AUTO) {
                this.mc.field_1724.field_3944.method_2883((class_2596)new class_2868(slot));
                this.mc.field_1724.method_31548().field_7545 = slot;
            } else if (this.silentMode.get() == SwapMode.OLD) {
                this.mc.field_1724.field_3944.method_2883((class_2596)new class_2868(slot));
            } else {
                RandUtils.clickSlotPacket((int)(this.mc.field_1724.method_31548().field_7545 + 36), (int)slot, (class_1713)class_1713.field_7791);
                preSlot = slot;
            }
        }
        this.mc.field_1724.field_3944.method_2883((class_2596)new class_2885(this.getHand(), result, 0));
        RandUtils.swing((boolean)((Boolean)this.swing.get()), (class_1268)this.getHand());
        if (preSlot != -1 && this.switchMode.get() == SwitchMode.SILENT) {
            if (this.silentMode.get() == SwapMode.OLD) {
                this.mc.field_1724.field_3944.method_2883((class_2596)new class_2868(preSlot));
            } else {
                RandUtils.clickSlotPacket((int)(this.mc.field_1724.method_31548().field_7545 + 36), (int)preSlot, (class_1713)class_1713.field_7791);
            }
        }
        if (((Boolean)this.debug.get()).booleanValue()) {
            if (((Boolean)this.debugPlaceDirection.get()).booleanValue()) {
                this.info("dir:" + place.getDirection(), new Object[0]);
            }
            if (((Boolean)this.debugIsPop.get()).booleanValue() && place.getPops() > 0) {
                this.info("pops", new Object[0]);
            }
        }
        this.placeDelayLeft = (Integer)this.placeDelay.get();
        if (place.isFaceplace() && !((Boolean)this.netDamage.get()).booleanValue() && this.facePlaceSpeedMode.get() == FacePlaceBreak.CUSTOM && UtilsPlus.isSurrounded((class_1309)place.getTarget(), (boolean)true, (boolean)((Boolean)this.ignoreTerrain.get()))) {
            this.breakDelayLeft = Math.max((Integer)this.facePlaceSpeed.get(), this.breakDelayLeft);
        }
        if ((this.breakDelayLeft < 1 || (Integer)this.delayBypass.get() != 0 && this.breaks < (Integer)this.delayBypass.get()) && ((Boolean)this.idPredict.get()).booleanValue() && ((Boolean)this.instantPredict.get()).booleanValue()) {
            class_1511 crystal = new class_1511((class_1937)this.mc.field_1687, place.getPos().field_1352, place.getPos().field_1351, place.getPos().field_1350);
            crystal.method_5838(this.lastId + (Integer)this.minIdOffset.get());
            this.doAttack(crystal, true, null);
        }
        this.queueRenderBlock(place.getBlockPos(), place.getDamage(), place.getSelfDamage());
        this.pendingPlacements.putIfAbsent(place.getBlockPos(), System.currentTimeMillis());
        this.places = (short)(this.places + 1);
        this.lastPlaceTarget = place.getTarget();
        this.lastBlock = place.getBlockPos();
        this.sinceLastActionTimer.reset();
    }

    private void queueRenderBlock(class_2338 pos, float damage, float selfDamage) {
        boolean found = false;
        for (RenderBlock block : this.renderBlocks) {
            if (!block.pos.equals((Object)pos)) continue;
            block.set(((Integer)this.renderTime.get()).intValue(), damage, selfDamage, null);
            found = true;
        }
        if (found) {
            return;
        }
        RenderBlock block = new RenderBlock(pos, ((Integer)this.renderTime.get()).intValue(), damage, selfDamage, null);
        if (((Boolean)this.slide.get()).booleanValue()) {
            if (this.renderBlocks.size() > 1) {
                this.renderBlocks.set(1, block);
            } else {
                this.renderBlocks.add(block);
                this.slideProgress = 0.0f;
            }
        } else {
            if (!this.renderBlocks.isEmpty()) {
                while (this.renderBlocks.size() >= (Integer)this.maxBlocks.get()) {
                    this.renderBlocks.remove(0);
                }
            }
            this.renderBlocks.add(block);
        }
    }

    private void doBreak() {
        @Nullable PlacementInfo surroundReplace = null;
        float bestDamage = 0.0f;
        class_1511 bestCrystal = null;
        block0: for (class_1297 e : this.mc.field_1687.method_18112()) {
            if (!(e instanceof class_1511)) continue;
            class_1511 crystal = (class_1511)e;
            if ((Integer)this.minAge.get() > 0) {
                long yawstepsNeeded = Math.round(MineHelper.distanceBetweenAngles(this.serverYaw, Rotations.getYaw((class_1297)crystal)) / (double)((Integer)this.yawstep.get()).intValue());
                Long msAge = this.crystalAliveMap.getOrDefault(crystal.method_5628(), 0L);
                float msRequired = (float)((Integer)this.minAge.get()).intValue() * 1000.0f / TickRate.INSTANCE.getTickRate();
                if (this.getPing() != 100) {
                    msRequired -= (float)PingUtils.getAveragePing();
                }
                if ((float)(System.currentTimeMillis() - msAge) < msRequired && (!((Type)this.rotationMode.get()).breakTrue() || (Integer)this.yawstep.get() == 180 || Math.round((double)(msRequired - (float)System.currentTimeMillis() + (float)msAge.longValue()) / 50.0) > yawstepsNeeded)) continue;
            }
            if (this.shouldNotBreak(crystal, (Boolean)this.inhibit.get(), true)) continue;
            class_243 crystalPos = crystal.method_19538();
            int totalDamage = 0;
            boolean foundBreak = false;
            for (class_1309 target : this.targets) {
                if (target.method_29504() || !((Boolean)this.netDamage.get()).booleanValue() && bestDamage != 0.0f && bestDamage > DamageCalcUtils.explosionDamage((class_1309)target, (class_243)crystalPos, (boolean)((Boolean)this.predict.get()), (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)false, (boolean)false, (int)6)) continue;
                float damage = this.applyHurtTimeToDamage(target, DamageCalcUtils.explosionDamage((class_1309)target, (class_243)crystalPos, (boolean)((Boolean)this.predict.get()), (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)false, (boolean)true, (int)6), false, false);
                totalDamage = (int)((float)totalDamage + damage);
                if (this.unsafeBreak((class_1309)this.mc.field_1724, crystalPos, damage)) continue block0;
                if (((Type)this.antiFriendPop.get()).breakTrue()) {
                    for (class_1657 friend : this.friends) {
                        if (!this.unsafeBreak((class_1309)friend, crystalPos, damage)) continue;
                        continue block0;
                    }
                }
                if (bestCrystal == null) {
                    if (((Boolean)this.antiSurroundBreak.get()).booleanValue() && UtilsPlus.isSurrounded((class_1309)this.mc.field_1724, (boolean)true, (boolean)((Boolean)this.ignoreTerrain.get())) && UtilsPlus.getSurroundBreak((class_1309)this.mc.field_1724, (class_2338)crystal.method_24515().method_10074()) > 0) {
                        bestCrystal = crystal;
                        bestDamage = damage;
                    }
                    if (((Boolean)this.antiCev.get()).booleanValue() && this.getState(this.mc.field_1724.method_24515().method_10086(2)).method_26204() == class_2246.field_10540 && crystal.method_24515().equals((Object)this.mc.field_1724.method_24515().method_10069(0, 3, 0))) {
                        bestCrystal = crystal;
                        bestDamage = damage;
                    }
                }
                if (bestCrystal == null) {
                    class_2338 targetBlockPos = target.method_24515().method_10074();
                    class_2338 crystalPosDown = crystal.method_24515().method_10087(2);
                    for (class_2382 city : CityUtils.CITY_WITHOUT_BURROW) {
                        class_2338 pos = targetBlockPos.method_10081(city);
                        if (!crystalPosDown.equals((Object)pos)) continue;
                        PlacementInfo placeInfo = new PlacementInfo(pos);
                        if (this.invalidPlace(pos, this.getState(pos), false, placeInfo, -69, null, false)) continue;
                        bestCrystal = crystal;
                        bestDamage = damage;
                        surroundReplace = placeInfo;
                        break;
                    }
                }
                double d = damage;
                double d2 = this.shouldFacePlace(target) ? 1.5 : (Double)this.minBreakDamage.get();
                if (d < d2) {
                    if (bestDamage > damage || this.placeDelayLeft > 0) continue;
                    for (class_2382 city : CityUtils.CITY_WITHOUT_BURROW) {
                        class_2338 pos = target.method_24515().method_10081(city);
                        if (!UtilsPlus.isBlockSurroundBrokenByCrystal((class_2338)pos, (class_1511)crystal)) continue;
                        class_2338 down = pos.method_10074();
                        PlacementInfo placeInfo = new PlacementInfo(down);
                        if (this.invalidPlace(down, this.getState(down), false, placeInfo, crystal.method_5628(), null, false)) continue;
                        bestCrystal = crystal;
                        bestDamage = damage;
                        surroundReplace = placeInfo;
                        break;
                    }
                    if (surroundReplace == null) continue;
                }
                foundBreak = true;
                if (((Boolean)this.netDamage.get()).booleanValue() || !(damage > bestDamage)) continue;
                bestDamage = damage;
                bestCrystal = crystal;
            }
            if (!((Boolean)this.netDamage.get()).booleanValue() || !foundBreak || (float)totalDamage < bestDamage) continue;
            bestDamage = totalDamage;
            bestCrystal = crystal;
        }
        if (bestCrystal != null) {
            this.doAttack(bestCrystal, false, surroundReplace);
        } else if (((Boolean)this.idPredict.get()).booleanValue() && this.places > 0) {
            if (this.lastBlock == null) {
                return;
            }
            class_1511 predictedCrystal = new class_1511((class_1937)this.mc.field_1687, (double)this.lastBlock.method_10263() + 0.5, (double)(this.lastBlock.method_10264() + 1), (double)this.lastBlock.method_10260() + 0.5);
            if (((Boolean)this.aggressivePredict.get()).booleanValue()) {
                for (int id = ((Integer)this.minIdOffset.get()).intValue(); id <= (Integer)this.maxIdOffset.get(); ++id) {
                    if (this.badId(id)) continue;
                    predictedCrystal.method_5838(this.lastId + id);
                    this.doAttack(predictedCrystal, true, null);
                }
            } else {
                if (this.places + (Integer)this.minIdOffset.get() >= (Integer)this.maxIdOffset.get()) {
                    return;
                }
                if (this.lastPredictedId == this.places + (Integer)this.minIdOffset.get()) {
                    return;
                }
                if (this.badId(this.lastId + this.places + (Integer)this.minIdOffset.get())) {
                    this.places = (short)(this.places + 1);
                    return;
                }
                predictedCrystal.method_5838(this.lastId + this.places + (Integer)this.minIdOffset.get());
                this.doAttack(predictedCrystal, true, null);
                this.lastPredictedId = this.places + (Integer)this.minIdOffset.get();
            }
        }
    }

    private boolean badId(int id) {
        try {
            class_1297 entity = this.mc.field_1687.method_8469(id);
            return entity instanceof class_1542 || entity instanceof class_1303 || entity instanceof class_1665 || entity == this.mc.field_1724;
        }
        catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            return false;
        }
    }

    private void doAttack(class_1511 crystal, boolean predict, @Nullable PlacementInfo surroundReplace) {
        boolean cantBreakRn;
        boolean canSilentWeaknessSwitch = this.antiWeaknessSlot != -1 && this.canBreakCrystal(this.mc.field_1724.method_31548().method_5438(this.antiWeaknessSlot), 0);
        boolean bl = cantBreakRn = this.weak && !this.canBreakCrystal(this.mc.field_1724.method_6047(), this.ticksSinceLastBreak);
        if (cantBreakRn) {
            if (this.antiWeaknessSlot == -1) {
                return;
            }
            if (!canSilentWeaknessSwitch && this.switchMode.get() == SwitchMode.SILENT && this.silentMode.get() == SwapMode.NEW) {
                RandUtils.clickSlotPacket((int)(this.mc.field_1724.method_31548().field_7545 + 36), (int)this.antiWeaknessSlot, (class_1713)class_1713.field_7791);
            } else {
                this.mc.field_1724.field_3944.method_2883((class_2596)new class_2868(this.antiWeaknessSlot));
            }
            if (!canSilentWeaknessSwitch || this.switchMode.get() != SwitchMode.SILENT || (Integer)this.afterSwitchBreakPause.get() > 0 && this.silentMode.get() == SwapMode.OLD) {
                this.mc.field_1724.method_31548().field_7545 = this.antiWeaknessSlot;
                return;
            }
        }
        if (((Type)this.rotationMode.get()).breakTrue()) {
            if (!this.hasRotatedThisTick && ((Integer)this.yawstep.get() == 180 || this.validRotation(crystal.method_19538()))) {
                Rotations.rotate((double)Rotations.getYaw((class_1297)crystal), (double)Rotations.getPitch((class_1297)crystal, (Target)((Target)this.breakRotationMode.get())), (int)85, () -> this.attackCrystal(crystal, predict, cantBreakRn, surroundReplace));
                this.hasRotatedThisTick = true;
            } else if (this.rotationTarget == null) {
                this.rotationTarget = crystal.method_19538();
            }
        } else {
            this.attackCrystal(crystal, predict, cantBreakRn, surroundReplace);
        }
    }

    private void attackCrystal(class_1511 crystal, boolean predict, boolean shouldAntiWeakness, @Nullable PlacementInfo surroundReplace) {
        this.mc.field_1724.field_3944.method_2883((class_2596)class_2824.method_34206((class_1297)crystal, (boolean)this.mc.field_1724.method_5715()));
        RandUtils.swing((boolean)((Boolean)this.swing.get()), (class_1268)this.getHand());
        if (shouldAntiWeakness && this.switchMode.get() == SwitchMode.SILENT) {
            if (this.silentMode.get() == SwapMode.OLD) {
                this.mc.field_1724.field_3944.method_2883((class_2596)new class_2868(this.mc.field_1724.method_31548().field_7545));
            } else {
                RandUtils.clickSlotPacket((int)(this.mc.field_1724.method_31548().field_7545 + 36), (int)this.antiWeaknessSlot, (class_1713)class_1713.field_7791);
            }
        }
        this.crystalsToRemove.put(crystal.method_5628(), System.currentTimeMillis());
        int tries = this.attemptedBreaks.getOrDefault(crystal.method_5628(), 0);
        this.attemptedBreaks.put(crystal.method_5628(), tries + 1);
        if (surroundReplace != null && this.placeDelayLeft < 1) {
            this.place(surroundReplace, ((Type)this.rotationMode.get()).placeTrue());
        }
        if (!predict) {
            this.places = 0;
            this.lastPredictedId = 0;
        }
        if (tries == 0) {
            for (class_1297 entity : this.mc.field_1687.method_18112()) {
                if (!(entity instanceof class_1511) || crystal.method_5739(entity) > 11.0f) continue;
                this.crystalsToRemove.put(entity.method_5628(), System.currentTimeMillis());
            }
            if (((Boolean)this.sequential.get()).booleanValue() && this.canPlace()) {
                if (this.threadMode.get() == Threading.THREADED && !this.executor.isShutdown() && !this.executor.isTerminated()) {
                    this.executor.submit(this::doPlace);
                } else {
                    this.doPlace();
                }
            }
        }
        this.breaks = (short)(this.breaks + 1);
        this.breakDelayLeft = (Integer)this.breakDelay.get();
        this.sinceLastActionTimer.reset();
        if (((Boolean)this.debug.get()).booleanValue()) {
            float selfDamage;
            if (((Boolean)this.debugActualDamage.get()).booleanValue() && tries == 0 && TextUtils.round((float)(selfDamage = this.applyHurtTimeToDamage((class_1309)this.mc.field_1724, DamageCalcUtils.explosionDamage((class_1309)this.mc.field_1724, (class_243)crystal.method_19538(), (int)6), false, false)), (int)4) > 0.0) {
                this.info("calculated damage: " + TextUtils.round((float)selfDamage, (int)4), new Object[0]);
            }
            if (((Boolean)this.debugAttackedId.get()).booleanValue()) {
                this.info("id: " + crystal.method_5628(), new Object[0]);
            }
        }
    }

    private boolean shouldNotBreak(class_1511 crystal, boolean inhibit, boolean checkRange) {
        if (crystal.method_31481() || !crystal.method_5805()) {
            return true;
        }
        if (checkRange && this.notInBreakRange(crystal)) {
            return true;
        }
        if (inhibit && this.crystalsToRemove.containsKey(crystal.method_5628())) {
            return true;
        }
        if (this.attemptedBreaks.getOrDefault(crystal.method_5628(), 0) >= (Integer)this.breakAttempts.get()) {
            if (this.retryDelayLeft < 0) {
                this.retryDelayLeft = (Integer)this.retryDelay.get();
            }
            return true;
        }
        return false;
    }

    private boolean notInBreakRange(class_1511 crystal) {
        return AntiCheatHelper.outOfHitRange((class_1297)crystal, (Origin)Origin.NCP, (double)((Double)this.breakRange.get()), (double)((Boolean)this.wallsRanges.get() != false ? (Double)this.breakWallsRange.get() : (Double)this.breakRange.get()), (boolean)((Boolean)this.precision.get()));
    }

    private boolean unsafeBreak(class_1309 entity, class_243 crystalPos, double targetDamage) {
        float selfDamage = this.applyHurtTimeToDamage(entity, DamageCalcUtils.explosionDamage((class_1309)entity, (class_243)crystalPos, (entity != this.mc.field_1724 && (Boolean)this.predict.get() != false ? 1 : 0) != 0, (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()), (boolean)((Boolean)this.ignoreTerrain.get()), (boolean)false, (boolean)true, (int)6), false, false);
        if (((Boolean)this.noSuicideBreak.get()).booleanValue() && (double)(EntityUtils.getTotalHealth((class_1657)((class_1657)entity)) - selfDamage) < 0.5) {
            return true;
        }
        if ((double)selfDamage > (Double)this.maxBreakDamage.get()) {
            if ((Double)this.breakRatio.get() == 0.0) {
                return true;
            }
            return targetDamage / (double)selfDamage < (Double)this.breakRatio.get();
        }
        return false;
    }

    private boolean pauseBreak() {
        if (this.breaks >= (Integer)this.maxBreaksPerSecond.get()) {
            return true;
        }
        if (!this.switchTimer.passedMillis((long)((Integer)this.afterSwitchBreakPause.get()).intValue())) {
            return true;
        }
        if (((Type)this.pauseMode.get()).breakTrue() && PlayerUtils.shouldPause((boolean)((Boolean)this.pauseOnMine.get()), (boolean)((Boolean)this.pauseOnEat.get()), (boolean)((Boolean)this.pauseOnEat.get()))) {
            return true;
        }
        this.weak = false;
        if (((Boolean)this.antiWeakness.get()).booleanValue()) {
            Map effects = this.mc.field_1724.method_6088();
            class_1293 weakness = (class_1293)effects.get(class_1294.field_5911);
            class_1293 strength = (class_1293)effects.get(class_1294.field_5910);
            if (weakness != null && (strength == null || weakness.method_5578() >= strength.method_5578())) {
                this.weak = true;
                this.antiWeaknessSlot = InvUtils.find(stack -> this.canBreakCrystal((class_1799)stack, 0), (int)0, (int)8).slot();
                if (this.antiWeaknessSlot == -1) {
                    this.antiWeaknessSlot = InvUtils.find(stack -> this.canBreakCrystal((class_1799)stack, this.ticksSinceLastBreak), (int)0, (int)8).slot();
                }
                if (PlayerUtils.shouldPause((boolean)false, (this.pauseMode.get() != Type.NONE && (Boolean)this.pauseOnEat.get() != false ? 1 : 0) != 0, (boolean)false)) {
                    return true;
                }
                return this.antiWeaknessSlot == -1;
            }
        }
        return false;
    }

    private boolean shouldFacePlace(class_1309 target) {
        if (!((Boolean)this.facePlace.get()).booleanValue()) {
            return false;
        }
        if (((Keybind)this.forceFacePlace.get()).isPressed() && this.mc.field_1755 == null) {
            return true;
        }
        if (!(target instanceof class_1657)) {
            return false;
        }
        if (((Boolean)this.facePlacePause.get()).booleanValue()) {
            if (PlayerUtils.shouldPause((boolean)((Boolean)this.facePlacePauseMine.get()), (boolean)((Boolean)this.facePlacePauseEat.get()), (boolean)((Boolean)this.facePlacePauseEat.get()))) {
                return false;
            }
            if (((Boolean)this.pauseFacePlaceCev.get()).booleanValue() && isExternalModuleActive("AutoFunnyCrystal")) {
                return false;
            }
        }
        if (!((Boolean)this.facePlaceSelf.get()).booleanValue() && this.mc.field_1724.method_5739((class_1297)target) < 1.0f) {
            return false;
        }
        if (((Boolean)this.pauseSword.get()).booleanValue() && (this.mc.field_1724.method_6047().method_7909() instanceof class_1829 || this.mc.field_1724.method_6047().method_7909() instanceof class_1743)) {
            return false;
        }
        if (EntityUtils.getTotalHealth((class_1657)((class_1657)target)) <= (float)((Integer)this.facePlaceHealth.get()).intValue()) {
            return true;
        }
        if (((Boolean)this.facePlaceHole.get()).booleanValue() && (UtilsPlus.isSurrounded((class_1309)target, (boolean)true, (boolean)((Boolean)this.ignoreTerrain.get())) || UtilsPlus.isBurrowed((class_1309)target))) {
            return true;
        }
        for (class_1799 itemStack : target.method_5661()) {
            if (!(itemStack == null || itemStack.method_7960() ? (Boolean)this.facePlaceArmor.get() != false : RandUtils.durabilityPercentage((class_1799)itemStack) <= (double)((Integer)this.facePlaceDurability.get()).intValue())) continue;
            return true;
        }
        return false;
    }

    private boolean isExternalModuleActive(String name) {
        try {
            java.lang.reflect.Method m = Modules.get().getClass().getMethod("getAll");
            Object result = m.invoke(Modules.get());
            if (result instanceof Iterable<?> iterable) {
                for (Object object : iterable) {
                    if (object instanceof Module module && module.name.equalsIgnoreCase(name)) return module.isActive();
                }
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private class_1268 getHand() {
        if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301 && this.mc.field_1724.method_6079().method_7909() == class_1802.field_8301) {
            return class_1268.field_5810;
        }
        return class_1268.field_5808;
    }

    private boolean canBreakCrystal(class_1799 stack, int timeSinceLastCooldownReset) {
        double damage = this.mc.field_1724.method_26825(class_5134.field_23721);
        for (Object modifier : stack.method_7926(class_1304.field_6173).get((Object)class_5134.field_23721)) {
            damage += modifier.method_6186();
        }
        float enchantDamage = class_1890.method_8218((class_1799)stack, (class_1310)class_1310.field_6290);
        for (class_1293 instance : this.mc.field_1724.method_6026()) {
            if (instance.method_5579() == class_1294.field_5910) {
                damage += (double)(3 * (instance.method_5578() + 1));
                continue;
            }
            if (instance.method_5579() != class_1294.field_5911) continue;
            damage -= (double)(4 * (instance.method_5578() + 1));
            if (timeSinceLastCooldownReset != 0 || enchantDamage != 0.0f) continue;
            return false;
        }
        if (damage < 0.0) {
            damage = 0.0;
        }
        double progress = 1.0;
        for (class_1322 modifier : stack.method_7926(class_1304.field_6173).get((Object)class_5134.field_23723)) {
            progress = class_3532.method_15350((double)(((double)timeSinceLastCooldownReset + 0.5) / (1.0 / (4.0 + modifier.method_6186()) * 20.0)), (double)0.0, (double)1.0);
        }
        damage *= (double)0.2f + progress * progress * (double)0.8f;
        return (damage += (double)enchantDamage) > 0.0;
    }

    private void handleHurtTime() {
        long ticksBehind = Math.round((double)this.getPing() / 50.0);
        if ((long)this.mc.field_1724.field_6008 - ticksBehind <= 10L) {
            this.lastTakenDamages.put(this.mc.field_1724.method_5628(), 0.0f);
        }
        for (class_1657 friend : this.friends) {
            if ((long)friend.field_6008 - ticksBehind > 10L) continue;
            this.lastTakenDamages.put(friend.method_5628(), 0.0f);
        }
        for (class_1309 target : this.targets) {
            if ((long)target.field_6008 - ticksBehind > 10L) continue;
            this.lastTakenDamages.put(target.method_5628(), 0.0f);
        }
    }

    private boolean intersectsWithEntity(class_2338 blockPos, boolean support, int idToIgnore) {
        if (this.getState(blockPos.method_10084()).method_26215() && !this.mc.field_1687.method_8320(blockPos.method_10084()).method_26215() && idToIgnore != -69) {
            return true;
        }
        int x = blockPos.method_10263();
        int y = blockPos.method_10264();
        int z = blockPos.method_10260();
        class_238 box = new class_238((double)x, (double)(y + 1), (double)z, (double)(x + 1), (double)(y + ((Boolean)this.ccEntities.get() != false ? 2 : 3)), (double)(z + 1));
        class_238 supportBox = new class_238(blockPos);
        for (class_1297 entity2 : this.mc.field_1687.method_18112()) {
            if (entity2 == this.mc.field_1724 || !(entity2 instanceof class_1657)) continue;
            class_1657 player = (class_1657)entity2;
            if (entity2.method_31481() || player.method_6032() <= 0.0f) continue;
            if (entity2.method_7325()) {
                return false;
            }
            if (entity2.method_24515().method_10262((class_2382)blockPos) > 16.0) continue;
            class_238 playerBox = player.method_5829();
            if (((Boolean)this.predict.get()).booleanValue()) {
                playerBox = PlayerUtils2.predictBox((class_1657)player, (int)((Integer)this.predictTicks.get()), (int)((Integer)this.antiStepOffset.get()));
            }
            if (!playerBox.method_994(box) && (!support || !playerBox.method_994(supportBox))) continue;
            return true;
        }
        if (EntityUtils.intersectsWithEntity((class_238)box, entity -> {
            class_1309 living;
            if (entity.method_5628() == idToIgnore) {
                return false;
            }
            if (entity.method_31481()) {
                return false;
            }
            if (entity instanceof class_1657 && entity != this.mc.field_1724) {
                return false;
            }
            if (entity instanceof class_1309 && (living = (class_1309)entity).method_6032() <= 0.0f) {
                return false;
            }
            if (entity.method_7325()) {
                return false;
            }
            if (idToIgnore == -69 && (entity instanceof class_1511 || entity instanceof class_1542)) {
                return false;
            }
            return !this.crystalsToRemove.containsKey(entity.method_5628());
        })) {
            return true;
        }
        if (!support) {
            return false;
        }
        return EntityUtils.intersectsWithEntity((class_238)supportBox, entity -> {
            class_1309 living;
            if (entity.method_5628() == idToIgnore) {
                return false;
            }
            if (entity.method_31481()) {
                return false;
            }
            if (!entity.method_5863()) {
                return false;
            }
            if (entity instanceof class_1657 && entity != this.mc.field_1724) {
                return false;
            }
            if (entity instanceof class_1309 && (living = (class_1309)entity).method_6032() <= 0.0f) {
                return false;
            }
            if (entity.method_7325()) {
                return false;
            }
            return !this.crystalsToRemove.containsKey(entity.method_5628());
        });
    }

    private int getPing() {
        return (Boolean)PingUtils.enabled.get() != false ? (int)((double)PingUtils.getPing() * 1.1) : 100;
    }

    @EventHandler
    private void onPacketSent(PacketEvent.Sent event) {
        if (event.packet instanceof class_2868) {
            this.switchTimer.reset();
            this.ticksSinceLastBreak = 0;
        } else {
            class_2596 class_25962 = event.packet;
            if (class_25962 instanceof class_2886) {
                class_2886 packet = (class_2886)class_25962;
                if (packet.method_12551() == class_1268.field_5810) {
                    return;
                }
                if (!((Type)this.pauseMode.get()).placeTrue()) {
                    return;
                }
                if (!PlayerUtils.shouldPause((boolean)false, (boolean)((Boolean)this.pauseOnEat.get()), (boolean)((Boolean)this.pauseOnEat.get()))) {
                    return;
                }
                this.mc.field_1724.field_3944.method_2883((class_2596)new class_2868(this.mc.field_1724.method_31548().field_7545));
            } else if (event.packet instanceof class_2824) {
                this.ticksSinceLastBreak = 0;
            } else {
                class_25962 = event.packet;
                if (class_25962 instanceof class_2828) {
                    class_2828 packet = (class_2828)class_25962;
                    this.serverYaw = packet.method_12271(this.serverYaw);
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void onActivate() {
        this.executor = Executors.newSingleThreadExecutor();
        this.playerPos = null;
        this.weak = false;
        this.breaks = 0;
        this.places = 0;
        this.ticksSinceLastBreak = 0;
        this.lastBlock = null;
        this.breakTimer.reset();
        this.sinceLastActionTimer.reset();
        this.switchTimer.setMs((long)((Integer)this.afterSwitchBreakPause.get()).intValue());
        this.placeDelayLeft = 0;
        this.breakDelayLeft = 0;
        this.supportDelayLeft = 0;
        this.retryDelayLeft = 0;
        this.lastId = 0;
        this.lastPredictedId = 0;
        this.lastPlaceTarget = null;
        this.friends.clear();
        this.attemptedBreaks.clear();
        this.lastTakenDamages.clear();
        this.targets.clear();
        this.crystalsToRemove.clear();
        this.crystalAliveMap.clear();
        this.pendingPlacements.clear();
        this.serverYaw = this.mc.field_1724.method_36454();
        this.rotationTarget = null;
        List<RenderBlock> list = this.renderBlocks;
        synchronized (list) {
            this.renderBlocks.clear();
        }
    }

    public void onDeactivate() {
        this.mc.field_1724.field_3944.method_2883((class_2596)new class_2868(this.mc.field_1724.method_31548().field_7545));
        if (this.executor != null && !this.executor.isShutdown()) {
            this.executor.shutdownNow();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!((Boolean)this.render.get()).booleanValue()) {
            return;
        }
        List<RenderBlock> list = this.renderBlocks;
        synchronized (list) {
            if (((Boolean)this.slide.get()).booleanValue() && this.renderBlocks.size() > 1) {
                RenderBlock block0 = this.renderBlocks.get(0);
                double xPos = (float)(this.renderBlocks.get((int)1).pos.method_10263() - block0.pos.method_10263()) * this.slideProgress + (float)block0.pos.method_10263();
                double yPos = (float)(this.renderBlocks.get((int)1).pos.method_10264() - block0.pos.method_10264()) * this.slideProgress + (float)block0.pos.method_10264();
                double zPos = (float)(this.renderBlocks.get((int)1).pos.method_10260() - block0.pos.method_10260()) * this.slideProgress + (float)block0.pos.method_10260();
                RenderBlock.complexRender((Render3DEvent)event, (double)xPos, (double)yPos, (double)zPos, null, (SettingColor)((SettingColor)this.sideColor.get()), (SettingColor)((SettingColor)this.lineColor.get()), (ShapeMode)((ShapeMode)this.shapeMode.get()), (boolean)((Boolean)this.fade.get()), (float)block0.ticks, (int)((Integer)this.renderTime.get()), (int)((Integer)this.beforeFadeDelay.get()), (boolean)false, (RenderShape)((RenderShape)this.renderShape.get()), (double)((Double)this.width.get()), (double)((Double)this.height.get()), (double)((Double)this.yOffset.get()), (double)((Double)this.weirdOffset.get()), (boolean)((Boolean)this.shrink.get()));
                this.slideProgress = (float)((double)this.slideProgress + (double)((Integer)this.slideSpeed.get()).intValue() / 100.0);
                if (this.slideProgress > 1.0f) {
                    this.slideProgress = 1.0f;
                    this.renderBlocks.set(0, this.renderBlocks.remove(1));
                }
            } else {
                for (RenderBlock block : this.renderBlocks) {
                    block.complexRender(event, (SettingColor)this.sideColor.get(), (SettingColor)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), ((Boolean)this.fade.get()).booleanValue(), ((Integer)this.beforeFadeDelay.get()).intValue(), false, (RenderShape)this.renderShape.get(), ((Double)this.width.get()).doubleValue(), ((Double)this.height.get()).doubleValue(), ((Double)this.yOffset.get()).doubleValue(), ((Double)this.weirdOffset.get()).doubleValue(), ((Boolean)this.shrink.get()).booleanValue());
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (!((Boolean)this.render.get()).booleanValue() || !((Boolean)this.renderDamage.get()).booleanValue()) {
            return;
        }
        int preA = ((SettingColor)this.damageColor.get()).a;
        int preSelfA = ((SettingColor)this.selfDamageColor.get()).a;
        List<RenderBlock> list = this.renderBlocks;
        synchronized (list) {
            if (((Boolean)this.slide.get()).booleanValue() && this.renderBlocks.size() > 1) {
                float factor;
                RenderBlock damage0 = this.renderBlocks.get(0);
                double xPos = (float)(this.renderBlocks.get((int)1).pos.method_10263() - damage0.pos.method_10263()) * this.slideProgress + (float)damage0.pos.method_10263();
                double yPos = (float)(this.renderBlocks.get((int)1).pos.method_10264() - damage0.pos.method_10264()) * this.slideProgress + (float)damage0.pos.method_10264();
                double zPos = (float)(this.renderBlocks.get((int)1).pos.method_10260() - damage0.pos.method_10260()) * this.slideProgress + (float)damage0.pos.method_10260();
                Vec3 pos = new Vec3(xPos + 0.5, yPos + (Double)this.yOffset.get() + ((Boolean)this.renderSelfDamage.get() != false ? 0.6667 : 0.5), zPos + 0.5);
                float f = factor = (Boolean)this.shrink.get() == false || damage0.ticks > (float)((Integer)this.damageRenderTime.get() - (Integer)this.beforeFadeDelay.get()) ? 1.0f : damage0.ticks / (float)((Integer)this.damageRenderTime.get()).intValue();
                if (!NametagUtils.to2D((Vec3)pos, (double)((Double)this.damageScale.get() * (double)factor))) {
                    return;
                }
                TextRenderer renderer = TextRenderer.get();
                NametagUtils.begin((Vec3)pos);
                renderer.begin((double)factor, false, true);
                if (((Boolean)this.fade.get()).booleanValue()) {
                    ((SettingColor)this.damageColor.get()).a = (int)((float)((SettingColor)this.damageColor.get()).a * (damage0.ticks > (float)((Integer)this.damageRenderTime.get() - (Integer)this.beforeFadeDelay.get()) ? 1.0f : damage0.ticks / (float)((Integer)this.damageRenderTime.get()).intValue()));
                    ((SettingColor)this.selfDamageColor.get()).a = (int)((float)((SettingColor)this.selfDamageColor.get()).a * (damage0.ticks > (float)((Integer)this.damageRenderTime.get() - (Integer)this.beforeFadeDelay.get()) ? 1.0f : damage0.ticks / (float)((Integer)this.damageRenderTime.get()).intValue()));
                }
                String damageText = String.valueOf(TextUtils.round((float)damage0.damage, (int)((Integer)this.roundDamage.get())));
                renderer.render(damageText, -renderer.getWidth(damageText) * 0.5, -renderer.getHeight(true) * 0.5, (Color)this.damageColor.get(), true);
                if (((Boolean)this.renderSelfDamage.get()).booleanValue()) {
                    String selfDamageText = String.valueOf(TextUtils.round((float)damage0.selfDamage, (int)((Integer)this.roundDamage.get())));
                    renderer.render(selfDamageText, -renderer.getWidth(selfDamageText) * 0.5, renderer.getHeight(true) * 0.5, (Color)this.selfDamageColor.get(), true);
                }
                renderer.end();
                NametagUtils.end();
                ((SettingColor)this.damageColor.get()).a = preA;
                ((SettingColor)this.selfDamageColor.get()).a = preSelfA;
                return;
            }
            for (RenderBlock damage : this.renderBlocks) {
                if (damage.ticks < (float)((Integer)this.renderTime.get() - (Integer)this.damageRenderTime.get())) continue;
                float factor = (Boolean)this.shrink.get() == false || damage.ticks > (float)((Integer)this.damageRenderTime.get() - (Integer)this.beforeFadeDelay.get()) ? 1.0f : damage.ticks / (float)((Integer)this.damageRenderTime.get()).intValue();
                Vec3 pos = new Vec3((double)damage.pos.method_10263() + 0.5, (double)damage.pos.method_10264() + (Double)this.yOffset.get() + ((Boolean)this.renderSelfDamage.get() != false ? 0.6667 : 0.5), (double)damage.pos.method_10260() + 0.5);
                if (!NametagUtils.to2D((Vec3)pos, (double)((Double)this.damageScale.get() * (double)factor))) continue;
                TextRenderer renderer = TextRenderer.get();
                NametagUtils.begin((Vec3)pos);
                renderer.begin((double)factor, false, true);
                if (((Boolean)this.fade.get()).booleanValue()) {
                    ((SettingColor)this.damageColor.get()).a = (int)((float)((SettingColor)this.damageColor.get()).a * (damage.ticks > (float)((Integer)this.damageRenderTime.get() - (Integer)this.beforeFadeDelay.get()) ? 1.0f : damage.ticks / (float)((Integer)this.damageRenderTime.get()).intValue()));
                    ((SettingColor)this.selfDamageColor.get()).a = (int)((float)((SettingColor)this.selfDamageColor.get()).a * (damage.ticks > (float)((Integer)this.damageRenderTime.get() - (Integer)this.beforeFadeDelay.get()) ? 1.0f : damage.ticks / (float)((Integer)this.damageRenderTime.get()).intValue()));
                }
                String damageText = String.valueOf(TextUtils.round((float)damage.damage, (int)((Integer)this.roundDamage.get())));
                renderer.render(damageText, -renderer.getWidth(damageText) * 0.5, -renderer.getHeight(true) * 0.5, (Color)this.damageColor.get(), true);
                if (((Boolean)this.renderSelfDamage.get()).booleanValue()) {
                    String selfDamageText = String.valueOf(TextUtils.round((float)damage.selfDamage, (int)((Integer)this.roundDamage.get())));
                    renderer.render(selfDamageText, -renderer.getWidth(selfDamageText) * 0.5, renderer.getHeight(true) * 0.5, (Color)this.selfDamageColor.get(), true);
                }
                renderer.end();
                NametagUtils.end();
                ((SettingColor)this.damageColor.get()).a = preA;
                ((SettingColor)this.selfDamageColor.get()).a = preSelfA;
            }
        }
    }

    public class_1657 getTarget() {
        if (this.sinceLastActionTimer.passedMillis(5000L)) {
            return null;
        }
        for (class_1309 target : this.targets) {
            if (!(target instanceof class_1657)) continue;
            class_1657 player = (class_1657)target;
            return player;
        }
        return null;
    }

    public String getInfoString() {
        if (this.targets.isEmpty()) {
            return null;
        }
        return this.targets.get(0).method_5820();
    }
}

