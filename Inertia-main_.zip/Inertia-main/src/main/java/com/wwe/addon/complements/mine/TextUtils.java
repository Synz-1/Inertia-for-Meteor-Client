package com.wwe.addon.complements.mine; public final class TextUtils { private TextUtils(){} public static double round(float v,int d){ double p=Math.pow(10,d); return Math.round(v*p)/p; } }
