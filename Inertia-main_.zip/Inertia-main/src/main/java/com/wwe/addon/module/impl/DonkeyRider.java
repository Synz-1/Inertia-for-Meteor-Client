/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.KeybindSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.utils.misc.Keybind
 *  meteordevelopment.meteorclient.utils.misc.input.Input
 *  meteordevelopment.meteorclient.utils.player.ChatUtils
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1495
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_304
 *  net.minecraft.class_3446
 *  net.minecraft.class_746
 *  org.apache.commons.lang3.RandomStringUtils
 */
package com.wwe.addon.module.impl;

import com.wwe.addon.inertia;
import com.wwe.addon.module.AddonModule;
import java.util.List;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.KeybindSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.input.Input;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1495;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3446;
import net.minecraft.class_746;
import org.apache.commons.lang3.RandomStringUtils;

public class DonkeyRider
extends AddonModule {
    private static boolean pressed = false;
    private static class_243 firstPos;
    private static class_243 finalPos;
    private final Setting<Double> yaw;
    private final Setting<Integer> distance;
    private final Setting<Integer> waitBeforeMoving;
    private final Setting<Boolean> remount;
    private final Setting<Integer> RemountTime;
    private final Setting<Keybind> pause;
    Thread runThread;
    private class_243 currentPos;
    private boolean dismounted;
    private boolean remounted;
    private boolean yawChanged1;
    private boolean yawChanged2;
    private double YAW;
    private boolean running;

    public DonkeyRider() {
        super(inertia.inertia, "DonkeyRider", "Riding the Donkey");
        this.yaw = this.settings.getDefaultGroup().add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("Yaw")).description("Yaw of the player")).defaultValue(0.0).min(-180.0).max(180.0).sliderMin(-180.0).sliderMax(180.0).build());
        this.distance = this.settings.getDefaultGroup().add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("Distance")).description("Distance for the donkey to travel back and forth")).defaultValue((Object)1001)).min(500).max(2000).sliderMin(500).sliderMax(2000).build());
        this.waitBeforeMoving = this.settings.getDefaultGroup().add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("Delay")).description("Wait Before Moving the donkey again after reaching the distance ")).defaultValue((Object)1000)).min(500).max(10000).sliderMin(500).sliderMax(10000).build());
        this.remount = this.settings.getDefaultGroup().add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("Remount")).description("Remounts on the nearby donkey entity")).defaultValue((Object)false)).build());
        this.RemountTime = this.settings.getDefaultGroup().add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("Remount Delay")).description("Delay Before remounting again")).defaultValue((Object)1000)).min(500).max(10000).sliderMin(500).sliderMax(10000).build());
        this.pause = this.settings.getDefaultGroup().add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)new KeybindSetting.Builder().name("Pause ")).description("Pauses or resumes when pressed")).defaultValue((Object)Keybind.none())).build());
        this.dismounted = false;
        this.remounted = false;
        this.yawChanged1 = false;
        this.yawChanged2 = false;
        this.running = true;
    }

    public static String getFirstPos() {
        return firstPos == null ? "" : firstPos.toString();
    }

    public static class_243 getFirstPosVec() {
        return firstPos == null ? null : firstPos;
    }

    public static String getFinalPos() {
        return finalPos == null ? "" : finalPos.toString();
    }

    public void onActivate() {
        super.onActivate();
        if (this.mc.field_1724 != null) {
            firstPos = this.mc.field_1724.method_19538();
        }
        this.start();
    }

    public boolean shouldPause() {
        if (((Keybind)this.pause.get()).isPressed()) {
            pressed = !pressed;
        }
        return pressed;
    }

    public void onDeactivate() {
        super.onDeactivate();
        this.stop();
        this.setPressed(this.mc.field_1690.field_1894, false);
    }

    public void run() {
        if (this.runThread == null) {
            this.runThread = new Thread(() -> {
                while (this.running) {
                    List donkeys;
                    double timeLeft;
                    long endTime;
                    long startTime;
                    if (this.mc.field_1724 == null && this.isActive()) {
                        this.toggle();
                    }
                    this.YAW = (Double)this.yaw.get();
                    class_746 player = this.mc.field_1724;
                    if (player == null || player.method_19538() == null) {
                        return;
                    }
                    if (player.method_5765() && player.method_5854() instanceof class_1495) {
                        double pos;
                        this.currentPos = player.method_19538();
                        if (this.currentPos == null || firstPos == null) continue;
                        if (this.currentPos != null && this.currentPos.method_1022(firstPos) >= (double)((Integer)this.distance.get() + 1) && !this.yawChanged1) {
                            this.setPressed(this.mc.field_1690.field_1894, false);
                            String AntiSpamText = "Reached!!! " + RandomStringUtils.randomAlphanumeric((int)11);
                            try {
                                ChatUtils.sendPlayerMsg((String)AntiSpamText);
                                startTime = System.currentTimeMillis();
                                endTime = startTime + (long)((Integer)this.waitBeforeMoving.get()).intValue();
                                while (System.currentTimeMillis() < endTime) {
                                    timeLeft = (double)(endTime - System.currentTimeMillis()) / 1000.0;
                                    this.mc.field_1724.method_7353(class_2561.method_30163((String)("Stopping for " + String.format("%.2f", timeLeft) + "s because reached " + String.valueOf(this.distance.get()) + " blocks")), true);
                                    Thread.sleep(10L);
                                }
                            }
                            catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            if ((Double)this.yaw.get() >= 0.0) {
                                this.yaw.set((Object)((Double)this.yaw.get() - 180.0));
                            } else {
                                this.yaw.set((Object)((Double)this.yaw.get() + 180.0));
                            }
                            this.YAW = (Double)this.yaw.get();
                            finalPos = firstPos;
                            firstPos = player.method_19538();
                            this.yaw.set((Object)this.YAW);
                            this.yawChanged1 = true;
                            this.yawChanged2 = false;
                            this.dismounted = false;
                        }
                        player.method_36456((float)this.YAW);
                        if (this.running) {
                            if (this.shouldPause()) {
                                this.setPressed(this.mc.field_1690.field_1894, false);
                            } else {
                                this.setPressed(this.mc.field_1690.field_1894, this.isActive());
                            }
                        }
                        if (finalPos == null || !((pos = this.currentPos.method_1022(finalPos)) <= 1.5) || this.dismounted) continue;
                        this.setPressed(this.mc.field_1690.field_1894, false);
                        player.method_29239();
                        ChatUtils.sendPlayerMsg((String)".dismount");
                        this.mc.field_1724.method_7353(class_2561.method_30163((String)"Dismounted Succesfully"), false);
                        this.setPressed(this.mc.field_1690.field_1894, true);
                        this.dismounted = true;
                        this.remounted = false;
                        this.yawChanged1 = false;
                        this.yawChanged2 = false;
                        for (int i = 0; i < 200; ++i) {
                        }
                        this.setPressed(this.mc.field_1690.field_1894, false);
                        continue;
                    }
                    this.setPressed(this.mc.field_1690.field_1894, false);
                    if (!this.dismounted || !((Boolean)this.remount.get()).booleanValue() || (donkeys = player.method_37908().method_8390(class_1495.class, player.method_5829().method_1014(5.0), Entity -> !Entity.method_42148())).isEmpty() || player.method_5765() || this.remounted || this.yawChanged2) continue;
                    this.mc.field_1724.method_7353(class_2561.method_30163((String)"Attempting to remount"), false);
                    try {
                        startTime = System.currentTimeMillis();
                        endTime = startTime + (long)((Integer)this.RemountTime.get() * 2);
                        while (System.currentTimeMillis() < endTime) {
                            timeLeft = (double)(endTime - System.currentTimeMillis()) / 1000.0;
                            this.mc.field_1724.method_7353(class_2561.method_30163((String)("Stopping for " + String.format("%.2f", timeLeft) + "s because dismounted")), true);
                            Thread.sleep(10L);
                        }
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if (player.method_5739((class_1297)donkeys.get(0)) > 4.0f) {
                        double xPos = Double.parseDouble(class_3446.field_16976.format(((class_1495)donkeys.get(0)).method_24515().method_10263()));
                        double zPos = Double.parseDouble(class_3446.field_16976.format(((class_1495)donkeys.get(0)).method_24515().method_10260()));
                        double yPos = Double.parseDouble(class_3446.field_16976.format(((class_1495)donkeys.get(0)).method_24515().method_10264()));
                        ChatUtils.sendPlayerMsg((String)("#goto " + (xPos - 1.0) + " " + yPos + " " + (zPos - 1.0)));
                        try {
                            Thread.sleep(3000L);
                        }
                        catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        ChatUtils.sendPlayerMsg((String)"#stop");
                    }
                    this.mc.field_1761.method_2905((class_1657)player, (class_1297)donkeys.get(0), class_1268.field_5808);
                    this.dismounted = false;
                    finalPos = null;
                    if ((Double)this.yaw.get() >= 0.0) {
                        this.yaw.set((Object)((Double)this.yaw.get() - 180.0));
                    } else {
                        this.yaw.set((Object)((Double)this.yaw.get() + 180.0));
                    }
                    this.YAW = (Double)this.yaw.get();
                    this.yawChanged2 = true;
                    this.remounted = true;
                    this.yawChanged1 = false;
                    firstPos = player.method_19538();
                    this.mc.field_1724.method_7353(class_2561.method_30163((String)"Remount Successfull"), false);
                }
            });
            this.runThread.setName("Donkey Rider Thread");
            this.runThread.start();
        }
    }

    public void stop() {
        if (this.runThread != null && this.runThread.isAlive()) {
            this.runThread.interrupt();
        }
        this.resetVariables();
    }

    public void start() {
        this.running = true;
        this.runThread = null;
        this.run();
    }

    public void resetVariables() {
        firstPos = null;
        finalPos = null;
        this.currentPos = null;
        this.running = false;
        this.runThread = null;
        this.dismounted = false;
        this.remounted = false;
        this.yawChanged1 = false;
        this.yawChanged2 = false;
        pressed = false;
    }

    private void setPressed(class_304 key, boolean pressed) {
        key.method_23481(pressed);
        Input.setKeyState((class_304)key, (boolean)pressed);
    }
}

