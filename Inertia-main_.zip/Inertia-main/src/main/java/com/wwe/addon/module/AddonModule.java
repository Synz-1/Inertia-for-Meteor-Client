/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.StringReader
 *  meteordevelopment.meteorclient.mixininterface.IChatHud
 *  meteordevelopment.meteorclient.systems.config.Config
 *  meteordevelopment.meteorclient.systems.modules.Category
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.utils.player.ChatUtils
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_3532
 *  net.minecraft.class_5250
 */
package com.wwe.addon.module;

import com.mojang.brigadier.StringReader;
import java.awt.Color;
import meteordevelopment.meteorclient.mixininterface.IChatHud;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3532;
import net.minecraft.class_5250;

public class AddonModule
extends Module {
    private final String prefix = "\u00a7f\u00a7l[\u00a74\u00a7lW\u00a7f\u00a7l]";

    public AddonModule(Category category, String string, String string2) {
        super(category, string, string2);
    }

    public void sendToggledMsg() {
        if (((Boolean)Config.get().chatFeedback.get()).booleanValue() && this.chatFeedback && this.mc.field_1687 != null) {
            ChatUtils.forceNextPrefixClass(((Object)((Object)this)).getClass());
            String string = "\u00a7f\u00a7l[\u00a74\u00a7lW\u00a7f\u00a7l] \u00a7f\u00a7l" + this.name + (this.isActive() ? " \u00a7a\u00a7lon" : " \u00a7c\u00a7loff");
            this.sendMessage(class_2561.method_30163((String)string), this.hashCode());
        }
    }

    public void info(String string, Object ... objectArray) {
        ChatUtils.forceNextPrefixClass(((Object)((Object)this)).getClass());
        class_5250 class_52502 = this.formatMsg(String.format(string, objectArray), class_124.field_1080);
        class_5250 class_52503 = class_2561.method_43473();
        class_52503.method_27693("\u00a7f\u00a7l[\u00a74\u00a7lW\u00a7f\u00a7l] \u00a7f[\u00a7d" + this.title + "\u00a7f] ");
        class_52503.method_10852((class_2561)class_52502);
        ((IChatHud)this.mc.field_1705.method_1743()).meteor$add((class_2561)class_52503, (Boolean)Config.get().deleteChatFeedback.get() != false ? 0 : 1);
    }

    public void sendMessage(class_2561 class_25612, int n) {
        ((IChatHud)this.mc.field_1705.method_1743()).meteor$add(class_25612, n);
    }

    public Color getClampColor(SettingColor settingColor, int n) {
        return new Color(settingColor.r, settingColor.g, settingColor.b, class_3532.method_15340((int)n, (int)0, (int)255));
    }

    public Color getSettingColor(SettingColor settingColor) {
        return new Color(settingColor.r, settingColor.g, settingColor.b, settingColor.a);
    }

    public float toFloat(double d) {
        return (float)d;
    }

    public double getValueSq(double d) {
        return d * d;
    }

    public double getValueSq(float f) {
        return f * f;
    }

    private class_5250 formatMsg(String string, class_124 class_1242) {
        StringReader stringReader = new StringReader(string);
        class_5250 class_52502 = class_2561.method_43473();
        class_2583 class_25832 = class_2583.field_24360.method_27706(class_1242);
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = false;
        while (stringReader.canRead()) {
            char c = stringReader.read();
            if (c == '(') {
                class_52502.method_10852((class_2561)class_2561.method_43470((String)stringBuilder.toString()).method_10862(class_25832));
                stringBuilder.setLength(0);
                stringBuilder.append(c);
                bl = true;
                continue;
            }
            stringBuilder.append(c);
            if (!bl || c != ')') continue;
            switch (stringBuilder.toString()) {
                case "(default)": {
                    class_25832 = class_25832.method_27706(class_1242);
                    stringBuilder.setLength(0);
                    break;
                }
                case "(highlight)": {
                    class_25832 = class_25832.method_27706(class_124.field_1068);
                    stringBuilder.setLength(0);
                    break;
                }
                case "(underline)": {
                    class_25832 = class_25832.method_27706(class_124.field_1073);
                    stringBuilder.setLength(0);
                    break;
                }
                case "(bold)": {
                    class_25832 = class_25832.method_27706(class_124.field_1067);
                    stringBuilder.setLength(0);
                }
            }
            bl = false;
        }
        if (!stringBuilder.isEmpty()) {
            class_52502.method_10852((class_2561)class_2561.method_43470((String)stringBuilder.toString()).method_10862(class_25832));
        }
        return class_52502;
    }
}

