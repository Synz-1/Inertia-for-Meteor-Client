/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2735
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package com.wwe.addon.mixin.accessor;

import net.minecraft.class_2735;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_2735.class})
public interface UpdateSelectedSlotS2CPacketAccessor {
    @Accessor(value="comp_3325")
    public int getSlot();
}

