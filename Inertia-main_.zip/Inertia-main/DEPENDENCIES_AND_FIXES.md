# Inertia compatibility patch

## Corrected
- Minecraft target: 1.21.5
- Yarn mappings: 1.21.5+build.1 (the same mapping line used by the Meteor addon template 1.21.5 update)
- Fabric Loom: 1.10-SNAPSHOT
- Java: 21
- Fabric Loader: 0.16.12 for the 1.21.5 template baseline
- Meteor dependency: 1.21.5-SNAPSHOT
- Fixed the invalid trailing comma in `wwe-addon.mixins.json`.
- Removed the nonexistent `AnchorTPRewrite` registration.
- Replaced missing Venomhack/Mio-owned helper types with local compatibility implementations where their usage was directly reconstructable from this source tree.
- Replaced the mutable Vec3d interface assumptions in `MineHelper` with ordinary vector reassignment.

## Important
The compatibility helpers are source-level reconstructions, not byte-for-byte copies of the original Venomhack/Mio implementations. The addon should therefore be treated as a repair/build baseline, not as proof that every original algorithm is identical.

## Optional original dependencies
`libs/venomhack.jar` and `libs/mio-addon.jar` are still accepted by Gradle when present, but they are no longer mandatory for the source-level helper symbols that were reconstructed.
