pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
        maven("https://maven.fabricmc.net/")
    }
}

dependencyResolutionManagement {
    repositories {
        mavenCentral()
        maven("https://maven.meteordev.org/releases")
        maven("https://maven.meteordev.org/snapshots")
        maven("https://maven.fabricmc.net/")
    }
}

rootProject.name = "Inertia"
