# Inertia

Repaired source baseline for Minecraft 1.21.5 / Java 21 / Fabric.

Gradle now uses Yarn intermediary mappings (`1.21.5+build.1`) because the source contains intermediary names such as `class_1297`.
