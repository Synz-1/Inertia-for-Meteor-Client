plugins {
    id("fabric-loom") version providers.gradleProperty("loom_version").get()
}

group = providers.gradleProperty("maven_group").get()
version = "1.0"

repositories {
    mavenCentral()
    maven("https://maven.meteordev.org/releases")
    maven("https://maven.meteordev.org/snapshots")
}

dependencies {
    minecraft("com.mojang:minecraft:${property("minecraft_version")}")
    mappings("net.fabricmc:yarn:${property("yarn_mappings")}:v2")
    modImplementation("net.fabricmc:fabric-loader:${property("loader_version")}")

    // Meteor Client snapshot matching Minecraft 1.21.5.
    modImplementation("meteordevelopment:meteor-client:${property("meteor_version")}")

    // Optional source compatibility jars. These are only needed if you keep the
    // original Venomhack/Mio integrations instead of the local compatibility code.
    val venomhack = file("libs/venomhack.jar")
    val mio = file("libs/mio-addon.jar")
    if (venomhack.exists()) compileOnly(files(venomhack))
    if (mio.exists()) compileOnly(files(mio))
}

java {
    toolchain.languageVersion.set(
        JavaLanguageVersion.of(property("java_version").toString().toInt())
    )
}

loom {
    splitEnvironmentSourceSets()
}

tasks.processResources {
    inputs.properties(
        mapOf(
            "version" to project.version,
            "minecraft_version" to property("minecraft_version"),
            "loader_version" to property("loader_version"),
            "java_version" to property("java_version")
        )
    )
    filesMatching("fabric.mod.json") {
        expand(
            mapOf(
                "version" to project.version,
                "minecraft_version" to property("minecraft_version"),
                "loader_version" to property("loader_version"),
                "java_version" to property("java_version")
            )
        )
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
}
